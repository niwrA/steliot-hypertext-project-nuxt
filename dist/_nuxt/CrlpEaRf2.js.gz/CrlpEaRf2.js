var e=`waste-notes-windunde-n`,t=`windunde`,n=`annotation`,r=`Wind under`,i=`Waste_notes/windunde_N.htm`,a=`windows-1252`,o=`
<div><center>
<table>
<tr>
<td><font><img src="../images/R.gif"/> <strong>The wind
        under ... </strong></font><hr noshade=""/>
<p>Cf. Webster: 'Is the wind in that door still?'
        [Eliot's note] The line cited in the note is from John
        Webster, The Devil's Law Case 3.2.162. (NA)</p>
<p><font><em>reference topics</em></font></p>
<table>
<tr>
<td>The Hollow Men</td>
<td><a href="title_A.htm"><img src="../images/arrowry.gif"/></a></td>
</tr>
<tr>
<td><a href="Waste_A.htm"><font>back to "The Waste Land" </font></a></td>
<td><a href="Burbank_A.htm"><img src="../images/arrowry.gif"/></a></td>
</tr>
</table>
</td>
</tr>
</table>
</center></div>
`,s=`The wind under ... Cf. Webster: 'Is the wind in that door still?' [Eliot's note] The line cited in the note is from John Webster, The Devil's Law Case 3.2.162. (NA) reference topics The Hollow Men back to "The Waste Land"`,c=[{kind:`internal`,path:`Waste_notes/title_A.htm`,fragment:null,label:``,resolvedPath:`Burbank_notes/title_A.htm`,pageId:`burbank-notes-title-a`},{kind:`internal`,path:`Waste_notes/Waste_A.htm`,fragment:null,label:`back to "The Waste Land"`,resolvedPath:`Waste_notes/Waste_A.htm`,pageId:`waste-notes-waste-a`},{kind:`internal`,path:`Waste_notes/Burbank_A.htm`,fragment:null,label:``,resolvedPath:`Burbank_notes/Burbank_A.htm`,pageId:`burbank-notes-burbank-a`}],l=[{kind:`internal`,path:`images/R.gif`,fragment:null,alt:``},{kind:`internal`,path:`images/arrowry.gif`,fragment:null,alt:``},{kind:`internal`,path:`images/arrowry.gif`,fragment:null,alt:``}],u={edition:`preserved`,sourceFile:`Waste_notes/windunde_N.htm`},d=[`waste-notes-waste-a`],f={id:e,slug:t,type:n,title:r,sourceFile:i,encoding:a,html:o,text:s,links:c,images:l,provenance:u,backlinks:d};export{d as backlinks,f as default,a as encoding,o as html,e as id,l as images,c as links,u as provenance,t as slug,i as sourceFile,s as text,r as title,n as type};