var e=`essays-swpoeticdr`,t=`swpoeticdr`,n=`source-page`,r=`Eliot, T. S. 1920. The Sacred Wood: The Possibility of a Poetic Drama.`,i=`Essays/swpoeticdr.htm`,a=`windows-1252`,o=`
<p><font><b>The Possibility of a Poetic
Drama</b></font></p>
<div><center>
<table>
<tr>
<td>T<font>HE</font> questions—why there is
        no poetic drama to-day, how the stage has lost all hold
        on literary art, why so many poetic plays are written
        which can only be read, and read, if at all, without
        pleasure—have become insipid, almost academic. The
        usual conclusion is either that "conditions"
        are too much for us, or that we really prefer other types
        of literature, or simply that we are uninspired. As for
        the last alternative, it is not to be entertained; as for
        the second, what type do we prefer?; and as for the
        first, no one has ever shown me "conditions,"
        except of the most superficial. The reasons for raising
        the question again are first that the majority, perhaps,
        certainly a large number, of poets hanker for the stage;
        and second, that a not negligible public appears to want
        verse plays. Surely there is some legitimate craving, not
        restricted to a few persons, which only the verse play
        can satisfy. And surely the critical attitude is to
        attempt to analyse the conditions and the other data. If
        there comes to light some conclusive obstacle, the
        investigation should at least help us to turn our
        thoughts to more profitable pursuits; and if there is
        not, we may hope to arrive eventually at some statement
        of conditions which might be altered. Possibly we shall
        find that our incapacity has a deeper source: the arts
        have at times flourished when there was no drama;
        possibly we are incompetent altogether; in that case the
        stage will be, not the seat, but at all events a symptom,
        of the malady.<p>From the point of view of literature,
        the drama is only one among several poetic forms. The
        epic, the ballad, the chanson de geste, the forms of
        Provence and of Tuscany, all found their perfection by
        serving particular societies. The forms of Ovid,
        Catullus, Propertius, served a society different, and in
        some respects more civilized, than any of these; and in
        the society of Ovid the drama as a form of art was
        comparatively insignificant. Nevertheless, the drama is
        perhaps the most permanent, is capable of greater
        variation and of expressing more varied types of society,
        than any other. It varied considerably in England alone;
        but when one day it was discovered lifeless, subsequent
        forms which had enjoyed a transitory life were dead too.
        I am not prepared to undertake the historical survey; but
        I should say that the poetic drama's autopsy was
        performed as much by Charles Lamb as by anyone else. For
        a form is not wholly dead until it is known to be; and
        Lamb, by exhuming the remains of dramatic life at its
        fullest, brought a consciousness of the immense gap
        between present and past. It was impossible to believe,
        after that, in a dramatic "tradition." The
        relation of Byron's <i>English Bards</i> and the poems of
        Crabbe to the work of Pope was a continuous tradition;
        but the relation of <i>The Cenci</i> to the great English
        drama is almost that of a reconstruction to an original.
        By losing tradition, we lose our hold on the present; but
        so far as there was any dramatic tradition in Shelley's
        day there was nothing worth the keeping. There is all the
        difference between preservation and restoration.</p>
<p>\xA0The Elizabethan Age in England was able to
        absorb a great quantity of new thoughts and new images,
        almost dispensing with tradition, because it had this
        great form of its own which imposed itself on everything
        that came to it. Consequently, the blank verse of their
        plays accomplished a subtlety and consciousness, even an
        intellectual power, that no blank verse since has
        developed or even repeated; elsewhere this age is crude,
        pedantic, or loutish in comparison with its contemporary
        France or Italy. The nineteenth century had a good many
        fresh impressions; but it had no form in which to confine
        them. Two men, Wordsworth and Browning, hammered out
        forms for themselves—personal forms, <i>The
        Excursion, Sordello, The Ring and the Book, Dramatic
        Monologues;</i> but no man can invent a form, create a
        taste for it, and perfect it too. Tennyson, who might
        unquestionably have been a consummate master of minor
        forms, took to turning out large patterns on a machine.
        As for Keats and Shelley, they were too young to be
        judged, and they were trying one form after another.</p>
<p>These poets were certainly obliged to consume vast
        energy in this pursuit of form, which could never lead to
        a wholly satisfying result. There has only been one
        Dante; and, after all, Dante had the benefit of years of
        practice in forms employed and altered by numbers of
        contemporaries and predecessors; he did not waste the
        years of youth in metric invention; and when he came to
        the <i>Commedia</i> he knew how to pillage right and
        left. To have, given into one's hands, a crude form,
        capable of indefinite refinement, and to be the person to
        see the possibilities—Shakespeare was very
        fortunate. And it is perhaps the craving for some such <i>donnée</i>
        which draws us on toward the present mirage of poetic
        drama.</p>
<p>But it is now very questionable whether there are more
        than two or three in the present generation who are <i>capable,</i>
        the least little bit, of benefiting by such advantages
        were they given. At most two or three actually devote
        themselves to this pursuit of form for which they have
        little or no public recognition. To create a form is not
        merely to invent a shape, a rhyme or rhythm. It is also
        the realization of the whole appropriate content of this
        rhyme or rhythm. The sonnet of Shakespeare is not merely
        such and such a pattern, but a precise way of thinking
        and feeling. The <i>framework</i> which was provided for
        the Elizabethan dramatist was not merely blank verse and
        the five-act play and the Elizabethan playhouse; it was
        not merely the plot—for the poets incorporated,
        remodelled, adapted or invented, as occasion suggested.
        It was also the half-formed <img src="greek2.gif"/>, the
        "temper of the age" (an unsatisfactory phrase),
        a preparedness, a habit on the part of the public, to
        respond to particular stimuli. There is a book to be
        written on the commonplaces of any great dramatic period,
        the handling of Fate or Death, the recurrence of mood,
        tone, situation. We should see then just how <i>little</i>
        each poet had to do; only so much as would make a play
        his, only what was really essential to make it different
        from anyone else's. When there is this economy of effort
        it is possible to have several, even many, good poets at
        once. The great ages did not perhaps <i>produce</i> much
        more talent than ours; but less talent was wasted.</p>
<p>Now in a formless age there is very little hope for
        the minor poet to do anything worth doing; and when I say
        minor I mean very good poets indeed: such as filled the
        Greek anthology and the Elizabethan song-books; even a
        Herrick; but not merely second-rate poets, for Denham and
        Waller have quite another importance, occupying points in
        the development of a major form. When everything is set
        out for the minor poet to do, he may quite frequently
        come upon some <i>trouvaille,</i> even in the drama:
        Peele and Brome are examples. Under the present
        conditions, the minor poet has too much to do. And this
        leads to another reason for the incompetence of our time
        in poetic drama.</p>
<p>\xA0\xA0Permanent literature is always a
        presentation: either a presentation of thought, or a
        presentation of feeling by a statement of events in human
        action or objects in the external world. In earlier
        literature—to avoid the word
        "classic"—we find both kinds, and
        sometimes, as in some of the dialogues of Plato,
        exquisite combinations of both. Aristotle presents
        thought, stripped to the essential structure, and he is a
        great <i>writer.</i> The <i>Agamemnon</i> or <i>Macbeth</i>
        is equally a statement, but of events. They are as much
        works of the "intellect" as the writings of
        Aristotle. There are more recent works of art which have
        the same quality of intellect in common with those of
        Æschylus and Shakespeare and Aristotle: <i>Education
        Sentimentale</i> is one of them. Compare it with such a
        book as <i>Vanity Fair</i> and you will see that the
        labour of the intellect consisted largely in a
        purification, in keeping out a great deal that Thackeray
        allowed to remain in; in refraining from reflection, in
        putting into the statement enough to make reflection
        unnecessary. The case of Plato is still more
        illuminating. Take the <i>Theætetus.</i> In a few
        opening words Plato gives a scene, a personality, a
        feeling, which colour the subsequent discourse but do not
        interfere with it: the particular setting, and the
        abstruse theory of knowledge afterwards developed,
        co-operate without confusion. Could any contemporary
        author exhibit such control?</p>
<p>In the nineteenth century another mentality manifested
        itself. It is evident in a very able and brilliant poem,
        Goethe's <i>Faust.</i> Marlowe's Mephistopheles is a
        simpler creature than Goethe's. But at least Marlowe has,
        in a few words, concentrated him into a statement. He is
        there, and (incidentally) he renders Milton's Satan
        superfluous. Goethe's demon inevitably sends us back to
        Goethe. He embodies a philosophy. A creation of art
        should not do that: he should <i>replace</i> the
        philosophy. Goethe has not, that is to say, sacrificed or
        consecrated his thought to make the drama; the drama is
        still a means. And this type of mixed art has been
        repeated by men incomparably smaller than Goethe. We have
        had one other remarkable work of this type: <i>Peer Gynt.</i>
        And we have had the plays of M. Maeterlinck and M. <a name="txt1">Claudel</a>. <a href="#note1">1</a></p>
<p>In the works of Maeterlinck and Claudel on the one
        hand, and those of M. Bergson on the other, we have the
        mixture of the genres in which our age delights. Every
        work of imagination must have a philosophy; and every
        philosophy must be a work of art—how often have we
        heard that M. Bergson is an artist! It is a boast of his
        disciples. It is what the word "art" means to
        them that is the disputable point. Certain works of
        philosophy can be called works of art: much of Aristotle
        and Plato, Spinoza, parts of Hume, Mr. Bradley's <i>Principles
        of Logic,</i> Mr. Russell's essay on
        "Denoting": clear and beautifully formed
        thought. But this is not what the admirers of Bergson,
        Claudel, or Maeterlinck (the philosophy of the latter is
        a little out of date) mean. They mean precisely what is
        not clear, but what is an emotional stimulus. And as a
        mixture of thought and of vision provides more stimulus,
        by suggesting both, both clear thinking and clear
        statement of particular objects must disappear.</p>
<p>The undigested "idea" or philosophy, the
        idea-emotion, is to be found also in poetic dramas which
        are conscientious attempts to adapt a true structure,
        Athenian or Elizabethan, to contemporary feeling. It
        appears sometimes as the attempt to supply the defect of
        structure by an internal structure. "But most
        important of all is the structure of the incidents. For
        Tragedy is an imitation, not of men, but of an action and
        of life, and life consists in action, and its end is a
        mode of action, not a <a name="txt2">quality</a>." <a href="#note2">2</a></p>
<p>We have on the one hand the "poetic" drama,
        imitation Greek, imitation Elizabethan, or
        modern-philosophical, on the other the comedy of
        "ideas," from Shaw to Galsworthy, down to the
        ordinary social comedy. The most ramshackle Guitry farce
        has some paltry idea or comment upon life put into the
        mouth of one of the characters at the end. It is said
        that the stage can be used for a variety of purposes,
        that in only one of them perhaps is it united with
        literary art. A mute theatre is a possibility (I do not
        mean the cinema); the ballet is an actuality (though
        under-nourished); opera is an institution; but where you
        have "imitations of life" on the stage, with
        speech, the only standard that we can allow is the
        standard of the work of art, aiming at the same intensity
        at which poetry and the other forms of art aim. From that
        point of view the Shavian drama is a hybrid as the
        Maeterlinckian drama is, and we need express no surprise
        at their belonging to the same epoch. Both philosophies
        are popularizations: the moment an idea has been
        transferred from its pure state in order that it may
        become comprehensible to the inferior intelligence it has
        lost contact with art. It can remain pure only by being
        stated simply in the form of general truth, or by being
        transmuted, as the attitude of Flaubert toward the small
        bourgeois is transformed in <i>Education Sentimentale.</i>
        It has there become so identified with the reality that
        you can no longer say what the idea is.</p>
<p>The essential is not, of course, that drama should be
        written in verse, or that we should be able to extenuate
        our appreciation of broad farce by occasionally attending
        a performance of a play of Euripides where Professor
        Murray's translation is sold at the door. The essential
        is to get upon the stage this precise statement of life
        which is at the same time a point of view, a world—a
        world which the author's mind has subjected to a complete
        process of simplification. I do not find that any drama
        which "embodies a philosophy" of the author's
        (like <i>Faust</i>) or which illustrates any social
        theory (like Shaw's) can possibly fulfil the
        requirements—though a place might be left for Shaw
        if not for Goethe. And the world of Ibsen and the world
        of Tchehov are not enough simplified, universal.</p>
<p>Finally, we must take into account the instability of
        any art—the drama, music, dancing—which depends
        upon representation by performers. The intervention of
        performers introduces a complication of economic
        conditions which is in itself likely to be injurious. A
        struggle, more or less unconscious, between the creator
        and the interpreter is almost inevitable. The interest of
        a performer is almost certain to be centred in himself: a
        very slight acquaintance with actors and musicians will
        testify. The performer is interested not in form but in
        opportunities for virtuosity or in the communication of
        his "personality"; the formlessness, the lack
        of intellectual clarity and distinction in modern music,
        the great physical stamina and physical training which it
        often requires, are perhaps signs of the triumph of the
        performer. The consummation of the triumph of the actor
        over the play is perhaps the productions of the Guitry.</p>
<p>\xA0The conflict is one which certainly cannot be
        terminated by the utter rout of the actor profession. For
        one thing, the stage appeals to too many demands besides
        the demand for art for that to be possible; and also we
        need, unfortunately, something more than refined
        automatons. Occasionally attempts have been made to
        "get around" the actor, to envelop him in
        masks, to set up a few "conventions" for him to
        stumble over, or even to develop little breeds of actors
        for some special Art drama. This meddling with nature
        seldom succeeds; nature usually overcomes these
        obstacles. Possibly the majority of attempts to confect a
        poetic drama have begun at the wrong end; they have aimed
        at the small public which wants "poetry."
        ("Novices," says Aristotle, "in the art
        attain to finish of diction and precision of portraiture
        before they can construct the plot.") The
        Elizabethan drama was aimed at a public which wanted <i>entertainment</i>
        of a crude sort, but would <i>stand</i> a good deal of
        poetry; our problem should be to take a form of
        entertainment, and subject it to the process which would
        leave it a form of art. Perhaps the music-hall comedian
        is the best material. I am aware that this is a dangerous
        suggestion to make. For every person who is likely to
        consider it seriously there are a dozen toymakers who
        would leap to tickle æsthetic society into one more
        quiver and giggle of art debauch. Very few treat art
        seriously. There are those who treat it solemnly, and
        will continue to write poetic pastiches of Euripides and
        Shakespeare; and there are others who treat it as a joke.</p>
</td>
</tr>
</table>
</center></div>
<dl>
<dt><a name="note1"><b>Note 1</b></a> </dt>
<dd>I should except <i>The Dynasts.</i> This gigantic
        panorama is hardly to be called a success, but it is
        essentially an attempt to present a vision, and
        "sacrifices" the philosophy to the vision, as
        all great dramas do. Mr. Hardy has apprehended his matter
        as a poet and an artist.</dd>
<dt><a name="note2"><b>Note 2</b></a> </dt>
<dd><i>Poetics,</i> vi. 9. Butcher's translation.</dd>
</dl>
`,s=`The Possibility of a Poetic Drama T HE questions—why there is no poetic drama to-day, how the stage has lost all hold on literary art, why so many poetic plays are written which can only be read, and read, if at all, without pleasure—have become insipid, almost academic. The usual conclusion is either that "conditions" are too much for us, or that we really prefer other types of literature, or simply that we are uninspired. As for the last alternative, it is not to be entertained; as for the second, what type do we prefer?; and as for the first, no one has ever shown me "conditions," except of the most superficial. The reasons for raising the question again are first that the majority, perhaps, certainly a large number, of poets hanker for the stage; and second, that a not negligible public appears to want verse plays. Surely there is some legitimate craving, not restricted to a few persons, which only the verse play can satisfy. And surely the critical attitude is to attempt to analyse the conditions and the other data. If there comes to light some conclusive obstacle, the investigation should at least help us to turn our thoughts to more profitable pursuits; and if there is not, we may hope to arrive eventually at some statement of conditions which might be altered. Possibly we shall find that our incapacity has a deeper source: the arts have at times flourished when there was no drama; possibly we are incompetent altogether; in that case the stage will be, not the seat, but at all events a symptom, of the malady. From the point of view of literature, the drama is only one among several poetic forms. The epic, the ballad, the chanson de geste, the forms of Provence and of Tuscany, all found their perfection by serving particular societies. The forms of Ovid, Catullus, Propertius, served a society different, and in some respects more civilized, than any of these; and in the society of Ovid the drama as a form of art was comparatively insignificant. Nevertheless, the drama is perhaps the most permanent, is capable of greater variation and of expressing more varied types of society, than any other. It varied considerably in England alone; but when one day it was discovered lifeless, subsequent forms which had enjoyed a transitory life were dead too. I am not prepared to undertake the historical survey; but I should say that the poetic drama's autopsy was performed as much by Charles Lamb as by anyone else. For a form is not wholly dead until it is known to be; and Lamb, by exhuming the remains of dramatic life at its fullest, brought a consciousness of the immense gap between present and past. It was impossible to believe, after that, in a dramatic "tradition." The relation of Byron's English Bards and the poems of Crabbe to the work of Pope was a continuous tradition; but the relation of The Cenci to the great English drama is almost that of a reconstruction to an original. By losing tradition, we lose our hold on the present; but so far as there was any dramatic tradition in Shelley's day there was nothing worth the keeping. There is all the difference between preservation and restoration. The Elizabethan Age in England was able to absorb a great quantity of new thoughts and new images, almost dispensing with tradition, because it had this great form of its own which imposed itself on everything that came to it. Consequently, the blank verse of their plays accomplished a subtlety and consciousness, even an intellectual power, that no blank verse since has developed or even repeated; elsewhere this age is crude, pedantic, or loutish in comparison with its contemporary France or Italy. The nineteenth century had a good many fresh impressions; but it had no form in which to confine them. Two men, Wordsworth and Browning, hammered out forms for themselves—personal forms, The Excursion, Sordello, The Ring and the Book, Dramatic Monologues; but no man can invent a form, create a taste for it, and perfect it too. Tennyson, who might unquestionably have been a consummate master of minor forms, took to turning out large patterns on a machine. As for Keats and Shelley, they were too young to be judged, and they were trying one form after another. These poets were certainly obliged to consume vast energy in this pursuit of form, which could never lead to a wholly satisfying result. There has only been one Dante; and, after all, Dante had the benefit of years of practice in forms employed and altered by numbers of contemporaries and predecessors; he did not waste the years of youth in metric invention; and when he came to the Commedia he knew how to pillage right and left. To have, given into one's hands, a crude form, capable of indefinite refinement, and to be the person to see the possibilities—Shakespeare was very fortunate. And it is perhaps the craving for some such donnée which draws us on toward the present mirage of poetic drama. But it is now very questionable whether there are more than two or three in the present generation who are capable, the least little bit, of benefiting by such advantages were they given. At most two or three actually devote themselves to this pursuit of form for which they have little or no public recognition. To create a form is not merely to invent a shape, a rhyme or rhythm. It is also the realization of the whole appropriate content of this rhyme or rhythm. The sonnet of Shakespeare is not merely such and such a pattern, but a precise way of thinking and feeling. The framework which was provided for the Elizabethan dramatist was not merely blank verse and the five-act play and the Elizabethan playhouse; it was not merely the plot—for the poets incorporated, remodelled, adapted or invented, as occasion suggested. It was also the half-formed , the "temper of the age" (an unsatisfactory phrase), a preparedness, a habit on the part of the public, to respond to particular stimuli. There is a book to be written on the commonplaces of any great dramatic period, the handling of Fate or Death, the recurrence of mood, tone, situation. We should see then just how little each poet had to do; only so much as would make a play his, only what was really essential to make it different from anyone else's. When there is this economy of effort it is possible to have several, even many, good poets at once. The great ages did not perhaps produce much more talent than ours; but less talent was wasted. Now in a formless age there is very little hope for the minor poet to do anything worth doing; and when I say minor I mean very good poets indeed: such as filled the Greek anthology and the Elizabethan song-books; even a Herrick; but not merely second-rate poets, for Denham and Waller have quite another importance, occupying points in the development of a major form. When everything is set out for the minor poet to do, he may quite frequently come upon some trouvaille, even in the drama: Peele and Brome are examples. Under the present conditions, the minor poet has too much to do. And this leads to another reason for the incompetence of our time in poetic drama. Permanent literature is always a presentation: either a presentation of thought, or a presentation of feeling by a statement of events in human action or objects in the external world. In earlier literature—to avoid the word "classic"—we find both kinds, and sometimes, as in some of the dialogues of Plato, exquisite combinations of both. Aristotle presents thought, stripped to the essential structure, and he is a great writer. The Agamemnon or Macbeth is equally a statement, but of events. They are as much works of the "intellect" as the writings of Aristotle. There are more recent works of art which have the same quality of intellect in common with those of Æschylus and Shakespeare and Aristotle: Education Sentimentale is one of them. Compare it with such a book as Vanity Fair and you will see that the labour of the intellect consisted largely in a purification, in keeping out a great deal that Thackeray allowed to remain in; in refraining from reflection, in putting into the statement enough to make reflection unnecessary. The case of Plato is still more illuminating. Take the Theætetus. In a few opening words Plato gives a scene, a personality, a feeling, which colour the subsequent discourse but do not interfere with it: the particular setting, and the abstruse theory of knowledge afterwards developed, co-operate without confusion. Could any contemporary author exhibit such control? In the nineteenth century another mentality manifested itself. It is evident in a very able and brilliant poem, Goethe's Faust. Marlowe's Mephistopheles is a simpler creature than Goethe's. But at least Marlowe has, in a few words, concentrated him into a statement. He is there, and (incidentally) he renders Milton's Satan superfluous. Goethe's demon inevitably sends us back to Goethe. He embodies a philosophy. A creation of art should not do that: he should replace the philosophy. Goethe has not, that is to say, sacrificed or consecrated his thought to make the drama; the drama is still a means. And this type of mixed art has been repeated by men incomparably smaller than Goethe. We have had one other remarkable work of this type: Peer Gynt. And we have had the plays of M. Maeterlinck and M. Claudel . 1 In the works of Maeterlinck and Claudel on the one hand, and those of M. Bergson on the other, we have the mixture of the genres in which our age delights. Every work of imagination must have a philosophy; and every philosophy must be a work of art—how often have we heard that M. Bergson is an artist! It is a boast of his disciples. It is what the word "art" means to them that is the disputable point. Certain works of philosophy can be called works of art: much of Aristotle and Plato, Spinoza, parts of Hume, Mr. Bradley's Principles of Logic, Mr. Russell's essay on "Denoting": clear and beautifully formed thought. But this is not what the admirers of Bergson, Claudel, or Maeterlinck (the philosophy of the latter is a little out of date) mean. They mean precisely what is not clear, but what is an emotional stimulus. And as a mixture of thought and of vision provides more stimulus, by suggesting both, both clear thinking and clear statement of particular objects must disappear. The undigested "idea" or philosophy, the idea-emotion, is to be found also in poetic dramas which are conscientious attempts to adapt a true structure, Athenian or Elizabethan, to contemporary feeling. It appears sometimes as the attempt to supply the defect of structure by an internal structure. "But most important of all is the structure of the incidents. For Tragedy is an imitation, not of men, but of an action and of life, and life consists in action, and its end is a mode of action, not a quality ." 2 We have on the one hand the "poetic" drama, imitation Greek, imitation Elizabethan, or modern-philosophical, on the other the comedy of "ideas," from Shaw to Galsworthy, down to the ordinary social comedy. The most ramshackle Guitry farce has some paltry idea or comment upon life put into the mouth of one of the characters at the end. It is said that the stage can be used for a variety of purposes, that in only one of them perhaps is it united with literary art. A mute theatre is a possibility (I do not mean the cinema); the ballet is an actuality (though under-nourished); opera is an institution; but where you have "imitations of life" on the stage, with speech, the only standard that we can allow is the standard of the work of art, aiming at the same intensity at which poetry and the other forms of art aim. From that point of view the Shavian drama is a hybrid as the Maeterlinckian drama is, and we need express no surprise at their belonging to the same epoch. Both philosophies are popularizations: the moment an idea has been transferred from its pure state in order that it may become comprehensible to the inferior intelligence it has lost contact with art. It can remain pure only by being stated simply in the form of general truth, or by being transmuted, as the attitude of Flaubert toward the small bourgeois is transformed in Education Sentimentale. It has there become so identified with the reality that you can no longer say what the idea is. The essential is not, of course, that drama should be written in verse, or that we should be able to extenuate our appreciation of broad farce by occasionally attending a performance of a play of Euripides where Professor Murray's translation is sold at the door. The essential is to get upon the stage this precise statement of life which is at the same time a point of view, a world—a world which the author's mind has subjected to a complete process of simplification. I do not find that any drama which "embodies a philosophy" of the author's (like Faust ) or which illustrates any social theory (like Shaw's) can possibly fulfil the requirements—though a place might be left for Shaw if not for Goethe. And the world of Ibsen and the world of Tchehov are not enough simplified, universal. Finally, we must take into account the instability of any art—the drama, music, dancing—which depends upon representation by performers. The intervention of performers introduces a complication of economic conditions which is in itself likely to be injurious. A struggle, more or less unconscious, between the creator and the interpreter is almost inevitable. The interest of a performer is almost certain to be centred in himself: a very slight acquaintance with actors and musicians will testify. The performer is interested not in form but in opportunities for virtuosity or in the communication of his "personality"; the formlessness, the lack of intellectual clarity and distinction in modern music, the great physical stamina and physical training which it often requires, are perhaps signs of the triumph of the performer. The consummation of the triumph of the actor over the play is perhaps the productions of the Guitry. The conflict is one which certainly cannot be terminated by the utter rout of the actor profession. For one thing, the stage appeals to too many demands besides the demand for art for that to be possible; and also we need, unfortunately, something more than refined automatons. Occasionally attempts have been made to "get around" the actor, to envelop him in masks, to set up a few "conventions" for him to stumble over, or even to develop little breeds of actors for some special Art drama. This meddling with nature seldom succeeds; nature usually overcomes these obstacles. Possibly the majority of attempts to confect a poetic drama have begun at the wrong end; they have aimed at the small public which wants "poetry." ("Novices," says Aristotle, "in the art attain to finish of diction and precision of portraiture before they can construct the plot.") The Elizabethan drama was aimed at a public which wanted entertainment of a crude sort, but would stand a good deal of poetry; our problem should be to take a form of entertainment, and subject it to the process which would leave it a form of art. Perhaps the music-hall comedian is the best material. I am aware that this is a dangerous suggestion to make. For every person who is likely to consider it seriously there are a dozen toymakers who would leap to tickle æsthetic society into one more quiver and giggle of art debauch. Very few treat art seriously. There are those who treat it solemnly, and will continue to write poetic pastiches of Euripides and Shakespeare; and there are others who treat it as a joke. Note 1 I should except The Dynasts. This gigantic panorama is hardly to be called a success, but it is essentially an attempt to present a vision, and "sacrifices" the philosophy to the vision, as all great dramas do. Mr. Hardy has apprehended his matter as a poet and an artist. Note 2 Poetics, vi. 9. Butcher's translation.`,c=[],l=[{kind:`internal`,path:`Essays/greek2.gif`,fragment:null,alt:``}],u={edition:`preserved`,sourceFile:`Essays/swpoeticdr.htm`},d=[`thesacredwood`],f={id:e,slug:t,type:n,title:r,sourceFile:i,encoding:a,html:o,text:s,links:c,images:l,provenance:u,backlinks:d};export{d as backlinks,f as default,a as encoding,o as html,e as id,l as images,c as links,u as provenance,t as slug,i as sourceFile,s as text,r as title,n as type};