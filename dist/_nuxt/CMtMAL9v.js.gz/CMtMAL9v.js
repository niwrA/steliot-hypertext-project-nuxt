var e=`burbank-notes-education-ha`,t=`education-ha`,n=`source-page`,r=`The Education of Henry Adams`,i=`Burbank_notes/Education_HA.htm`,a=`windows-1252`,o=`
<p><font><strong>The Education of Henry
Adams</strong></font></p>
<p>Henry Adams</p>
<table>
<tr>
<td><em>Henry Adams </em>(1838-1918),
        historian/philosopher and cultural critic. In the
        autobiographical <em>Education</em> (1906), Henry Adams
        discusses how and what life has taught him. In the
        section following, he discusses the influence Rome had on
        him, summarized well in the following lines:<p>"To a
        young Bostonian, fresh from Germany, Rome seemed a pure
        emotion, quite free from economic or actual values, and
        he could not in reason or common sense foresee that it
        was mechanically piling up conundrum after conundrum in
        his educational path, which seemed unconnected but that
        he had got to connect; that seemed insoluble but had got
        to be somehow solved. Rome was not a beetle to be
        dissected and dropped; not a bad French novel to be read
        in a railway train and thrown out of the window after
        other bad French novels, the morals of which could never
        approach the immorality of Roman history. Rome was
        actual; it was England; it was going to be America."</p>
<p>The Education of Henry Adams was his best known work
        and earned him a posthumous Pullitzer prize in 1919.<br/>
<br/>
</p>
</td>
</tr>
</table>
<div><center>
<table>
<tr>
<td>....<p>Meanwhile his father had quite enough
        perplexities of his own, without seeking more in his
        son's errors. His Quincy district had sent him to
        Congress, and in the spring of 1860 he was in the full
        confusion of nominating candidates for the Presidential
        election in November. He supported Mr. Seward. The
        Republican Party was an unknown force, and the Democratic
        Party was torn to pieces. No one could see far into the
        future. Fathers could blunder as well as sons, and, in
        1860, every one was conscious of being dragged along
        paths much less secure than those of the European
        tourist. For the time, the young man was safe from
        interference, and went on his way with a light heart to
        take whatever chance fragments of education God or the
        devil was pleased to give him, for he knew no longer the
        good from the bad. </p>
<p>He had of both sorts more than he knew how to use.
        Perhaps the most useful purpose he set himself to serve
        was that of his pen, for he wrote long letters, during
        the next three months, to his brother Charles, which his
        brother caused to be printed in the Boston Courier; and
        the exercise was good for him. He had little to say, and
        said it not very well, but that mattered less. The habit
        of expression leads to the search for something to
        express. Something remains as a residuum of the
        commonplace itself, if one strikes out every commonplace
        in the expression. Young men as a rule saw little in
        Italy, or anywhere else, and in after life, when Adams
        began to learn what some men could see, he shrank into
        corners of shame at the thought that he should have
        betrayed his own inferiority as though it were his pride,
        while he invited his neighbors to measure and admire; but
        it was still the nearest approach he had yet made to an
        intelligent act.</p>
<p>For the rest, Italy was mostly an emotion and the
        emotion naturally centred in Rome. The American parent,
        curiously enough, while bitterly hostile to Paris, seemed
        rather disposed to accept Rome as legitimate education,
        though abused; but to young men seeking education in a
        serious spirit, taking for granted that everything had a
        cause, and that nature tended to an end, Rome was
        altogether the most violent vice in the world, and Rome
        before 1870 was seductive beyond resistance. The month of
        May, 1860, was divine. No doubt other young men, and
        occasionally young women, have passed the month of May in
        Rome since then, and conceive that the charm continues to
        exist. Possibly it does- in them- but in 1860 the lights
        and shadows were still mediaeval, and mediaeval Rome was
        alive; the shadows breathed and glowed, full of soft
        forms felt by lost senses. No sand-blast of science had
        yet skinned off the epidermis of history, thought, and
        feeling. The pictures were uncleaned, the churches
        unrestored, the ruins unexcavated. Mediaeval Rome was
        sorcery. Rome was the worst spot on earth to teach
        nineteenth-century youth what to do with a
        twentieth-century world. One's emotions in Rome were
        one's private affair, like one's glass of absinthe before
        dinner in the Palais Royal; they must be hurtful, else
        they could not have been so intense; and they were surely
        immoral, for no one, priest or politician, could honestly
        read in the ruins of Rome any other certain lesson than
        that they were evidence of the just judgments of an
        outraged God against all the doings of man. This moral
        unfitted young men for every sort of useful activity; it
        made Rome a gospel of anarchy and vice; the last place
        under the sun for educating the young; yet it was, by
        common consent, the only spot that the young- of either
        sex and every race- passionately, perversely, wickedly
        loved.</p>
<p>Boys never see a conclusion; only on the edge of the
        grave can man conclude anything; but the first impulse
        given to the boy is apt to lead or drive him for the rest
        of his life into conclusion after conclusion that he
        never dreamed of reaching. One looked idly enough at the
        Forum or at St. Peter's, but one never forgot the look,
        and it never ceased reacting. To a young Bostonian, fresh
        from Germany, Rome seemed a pure emotion, quite free from
        economic or actual values, and he could not in reason or
        common sense foresee that it was mechanically piling up
        conundrum after conundrum in his educational path, which
        seemed unconnected but that he had got to connect; that
        seemed insoluble but had got to be somehow solved. Rome
        was not a beetle to be dissected and dropped; not a bad
        French novel to be read in a railway train and thrown out
        of the window after other bad French novels, the morals
        of which could never approach the immorality of Roman
        history. Rome was actual; it was England; it was going to
        be America. Rome could not be fitted into an orderly,
        middle-class, Bostonian, systematic scheme of evolution.
        No law of progress applied to it. Not even
        time-sequences- the last refuge of helpless historians-
        had value for it. The Forum no more led to the Vatican
        than the Vatican to the Forum. Rienzi, Garibaldi,
        Tiberius Gracchus, Aurelian might be mixed up in any
        relation of time, along with a thousand more, and never
        lead to a sequence. The great word Evolution had not yet,
        in 1860, made a new religion of history, but the old
        religion had preached the same doctrine for a thousand
        years without finding in the entire history of Rome
        anything but flat contradiction.</p>
<p>Of course both priests and evolutionists bitterly
        denied this heresy, but what they affirmed or denied in
        1860 had very little importance indeed for 1960. Anarchy
        lost no ground meanwhile. The problem became only the
        more fascinating. Probably it was more vital in May,
        1860, than it had been in October, 1764, when the idea of
        writing the Decline and Fall of the city first started to
        the mind of Gibbon, "in the close of the evening, as
        I sat musing in the Church of the Zoccolanti or
        Franciscan Friars, while they were singing Vespers in the
        Temple of Jupiter, on the ruins of the Capitol."
        Murray's Handbook had the grace to quote this passage
        from Gibbon's "Autobiography," which led Adams
        more than once to sit at sunset on the steps of the
        Church of Santa Maria di Ara Coeli, curiously wondering
        that not an inch had been gained by Gibbon- orall the
        historians since- towards explaining the Fall. The
        mystery remained unsolved; the charm remained intact. Two
        great experiments of Western civilization had left there
        the chief monuments of their failure, and nothing proved
        that the city might not still survive to express the
        failure of a third. The young man had no idea what he was
        doing. The thought of posing for a Gibbon never entered
        his mind. He was a tourist, even to the depths of his
        sub-consciousness, and it was well for him that he should
        be nothing else, for even the greatest of men cannot sit
        with dignity, "in the close of evening, among the
        ruins of the Capitol," unless they have something
        quite original to say about it. Tacitus could do it; so
        could Michael Angelo; and so, at a pinch, could Gibbon,
        though in figure hardly heroic; but, in sum, none of them
        could say very much more than the tourist, who went on
        repeating to himself the eternal question:- Why! Why!!
        Why!!!- as his neighbor, the blind beggar, might do,
        sitting next him, on the church steps. No one ever had
        answered the question to the satisfaction of any one
        else; yet every one who had either head or heart, felt
        that sooner or later he must make up his mind what answer
        to accept. Substitute the word America for the word Rome,
        and the question became personal. Perhaps Henry learned
        something in Rome, though he never knew it, and never
        sought it. Rome dwarfs teachers. The greatest men of the
        age scarcely bore the test of posing with Rome for a
        background. Perhaps Garibaldi- possibly even Cavour-
        could have sat "in the close of the evening, among
        the ruins of the Capitol," but one hardly saw
        Napoleon III there, or Palmerston or Tennyson or
        Longfellow. One morning, Adams happened to be chatting in
        the studio of Hamilton Wilde, when a middle-aged
        Englishman came in, evidently excited, and told of the
        shock he had just received, when riding near the Circus
        Maximus, at coming unexpectedly on the guillotine, where
        some criminal had been put to death an hour or two
        before. The sudden surprise had quite overcome him; and
        Adams, who seldom saw the point of a story till time had
        blunted it, listened sympathetically to learn what new
        form of grim horror had for the moment wiped out the
        memory of two thousand years of Roman bloodshed, or the
        consolation, derived from history and statistics, that
        most citizens of Rome seemed to be the better for
        guillotining. Only by slow degrees, he grappled the
        conviction that the victim of the shock was Robert
        Browning; and, on the background of the Circus Maximus,
        the Christian martyrs flaming as torches, and the
        morning's murderer on the block, Browning seemed rather
        in place, as a middle-aged gentlemanly English Pippa
        Passes; while afterwards, in the light of Belgravia
        dinner-tables, he never made part of his background
        except by effacement. Browning might have sat with
        Gibbon, among the ruins, and few Romans would have
        smiled. </p>
<p>Yet Browning never revealed the poetic depths of Saint
        Francis; William Story could not touch the secret of
        Michael Angelo; and Mommsen hardly said all that one felt
        by instinct in the lives of Cicero and Caesar. They
        taught what, as a rule, needed no teaching, the lessons
        of a rather cheap imagination and cheaper politics. Rome
        was a bewildering complex of ideas, experiments,
        ambitions, energies; without her, the Western world was
        pointless and fragmentary; she gave heart and unity to it
        all; yet Gibbon might have gone on for the whole century,
        sitting among the ruins of the Capitol, and no one would
        have passed, capable of telling him what it meant.
        Perhaps it meant nothing. So it ended; the happiest month
        of May that life had yet offered, fading behind the
        present, and probably beyond the past, somewhere into
        abstract time, grotesquely out of place with the Berlin
        scheme or a Boston future. Adams explained to himself
        that he was absorbing knowledge. He would have put it
        better had he said that knowledge was absorbing him. He
        was passive. In spite of swarming impressions he knew no
        more when he left Rome than he did when he entered it. As
        a marketable object, his value was less. </p>
<p>His next step went far to convince him that accidental
        education, whatever its economical return might be, was
        prodigiously successful as an object in itself.
        Everything conspired to ruin his sound scheme of life,
        and to make him a vagrant as well as pauper. He went on
        to Naples, and there, in the hot June, heard rumors that
        Garibaldi and his thousand were about to attack Palermo.
        Calling on the American Minister, Chandler of
        Pennsylvania, he was kindly treated, not for his merit,
        but for his name, and Mr. Chandler amiably consented to
        send him to the seat of war as bearer of despatches to
        Captain Palmer of the American sloop of war Iroquois.
        Young Adams seized the chance, and went to Palermo in a
        government transport filled with fleas, commanded by a
        charming Prince Caracciolo.</p>
</td>
</tr>
</table>
</center></div>
`,s=`The Education of Henry Adams Henry Adams Henry Adams (1838-1918), historian/philosopher and cultural critic. In the autobiographical Education (1906), Henry Adams discusses how and what life has taught him. In the section following, he discusses the influence Rome had on him, summarized well in the following lines: "To a young Bostonian, fresh from Germany, Rome seemed a pure emotion, quite free from economic or actual values, and he could not in reason or common sense foresee that it was mechanically piling up conundrum after conundrum in his educational path, which seemed unconnected but that he had got to connect; that seemed insoluble but had got to be somehow solved. Rome was not a beetle to be dissected and dropped; not a bad French novel to be read in a railway train and thrown out of the window after other bad French novels, the morals of which could never approach the immorality of Roman history. Rome was actual; it was England; it was going to be America." The Education of Henry Adams was his best known work and earned him a posthumous Pullitzer prize in 1919. .... Meanwhile his father had quite enough perplexities of his own, without seeking more in his son's errors. His Quincy district had sent him to Congress, and in the spring of 1860 he was in the full confusion of nominating candidates for the Presidential election in November. He supported Mr. Seward. The Republican Party was an unknown force, and the Democratic Party was torn to pieces. No one could see far into the future. Fathers could blunder as well as sons, and, in 1860, every one was conscious of being dragged along paths much less secure than those of the European tourist. For the time, the young man was safe from interference, and went on his way with a light heart to take whatever chance fragments of education God or the devil was pleased to give him, for he knew no longer the good from the bad. He had of both sorts more than he knew how to use. Perhaps the most useful purpose he set himself to serve was that of his pen, for he wrote long letters, during the next three months, to his brother Charles, which his brother caused to be printed in the Boston Courier; and the exercise was good for him. He had little to say, and said it not very well, but that mattered less. The habit of expression leads to the search for something to express. Something remains as a residuum of the commonplace itself, if one strikes out every commonplace in the expression. Young men as a rule saw little in Italy, or anywhere else, and in after life, when Adams began to learn what some men could see, he shrank into corners of shame at the thought that he should have betrayed his own inferiority as though it were his pride, while he invited his neighbors to measure and admire; but it was still the nearest approach he had yet made to an intelligent act. For the rest, Italy was mostly an emotion and the emotion naturally centred in Rome. The American parent, curiously enough, while bitterly hostile to Paris, seemed rather disposed to accept Rome as legitimate education, though abused; but to young men seeking education in a serious spirit, taking for granted that everything had a cause, and that nature tended to an end, Rome was altogether the most violent vice in the world, and Rome before 1870 was seductive beyond resistance. The month of May, 1860, was divine. No doubt other young men, and occasionally young women, have passed the month of May in Rome since then, and conceive that the charm continues to exist. Possibly it does- in them- but in 1860 the lights and shadows were still mediaeval, and mediaeval Rome was alive; the shadows breathed and glowed, full of soft forms felt by lost senses. No sand-blast of science had yet skinned off the epidermis of history, thought, and feeling. The pictures were uncleaned, the churches unrestored, the ruins unexcavated. Mediaeval Rome was sorcery. Rome was the worst spot on earth to teach nineteenth-century youth what to do with a twentieth-century world. One's emotions in Rome were one's private affair, like one's glass of absinthe before dinner in the Palais Royal; they must be hurtful, else they could not have been so intense; and they were surely immoral, for no one, priest or politician, could honestly read in the ruins of Rome any other certain lesson than that they were evidence of the just judgments of an outraged God against all the doings of man. This moral unfitted young men for every sort of useful activity; it made Rome a gospel of anarchy and vice; the last place under the sun for educating the young; yet it was, by common consent, the only spot that the young- of either sex and every race- passionately, perversely, wickedly loved. Boys never see a conclusion; only on the edge of the grave can man conclude anything; but the first impulse given to the boy is apt to lead or drive him for the rest of his life into conclusion after conclusion that he never dreamed of reaching. One looked idly enough at the Forum or at St. Peter's, but one never forgot the look, and it never ceased reacting. To a young Bostonian, fresh from Germany, Rome seemed a pure emotion, quite free from economic or actual values, and he could not in reason or common sense foresee that it was mechanically piling up conundrum after conundrum in his educational path, which seemed unconnected but that he had got to connect; that seemed insoluble but had got to be somehow solved. Rome was not a beetle to be dissected and dropped; not a bad French novel to be read in a railway train and thrown out of the window after other bad French novels, the morals of which could never approach the immorality of Roman history. Rome was actual; it was England; it was going to be America. Rome could not be fitted into an orderly, middle-class, Bostonian, systematic scheme of evolution. No law of progress applied to it. Not even time-sequences- the last refuge of helpless historians- had value for it. The Forum no more led to the Vatican than the Vatican to the Forum. Rienzi, Garibaldi, Tiberius Gracchus, Aurelian might be mixed up in any relation of time, along with a thousand more, and never lead to a sequence. The great word Evolution had not yet, in 1860, made a new religion of history, but the old religion had preached the same doctrine for a thousand years without finding in the entire history of Rome anything but flat contradiction. Of course both priests and evolutionists bitterly denied this heresy, but what they affirmed or denied in 1860 had very little importance indeed for 1960. Anarchy lost no ground meanwhile. The problem became only the more fascinating. Probably it was more vital in May, 1860, than it had been in October, 1764, when the idea of writing the Decline and Fall of the city first started to the mind of Gibbon, "in the close of the evening, as I sat musing in the Church of the Zoccolanti or Franciscan Friars, while they were singing Vespers in the Temple of Jupiter, on the ruins of the Capitol." Murray's Handbook had the grace to quote this passage from Gibbon's "Autobiography," which led Adams more than once to sit at sunset on the steps of the Church of Santa Maria di Ara Coeli, curiously wondering that not an inch had been gained by Gibbon- orall the historians since- towards explaining the Fall. The mystery remained unsolved; the charm remained intact. Two great experiments of Western civilization had left there the chief monuments of their failure, and nothing proved that the city might not still survive to express the failure of a third. The young man had no idea what he was doing. The thought of posing for a Gibbon never entered his mind. He was a tourist, even to the depths of his sub-consciousness, and it was well for him that he should be nothing else, for even the greatest of men cannot sit with dignity, "in the close of evening, among the ruins of the Capitol," unless they have something quite original to say about it. Tacitus could do it; so could Michael Angelo; and so, at a pinch, could Gibbon, though in figure hardly heroic; but, in sum, none of them could say very much more than the tourist, who went on repeating to himself the eternal question:- Why! Why!! Why!!!- as his neighbor, the blind beggar, might do, sitting next him, on the church steps. No one ever had answered the question to the satisfaction of any one else; yet every one who had either head or heart, felt that sooner or later he must make up his mind what answer to accept. Substitute the word America for the word Rome, and the question became personal. Perhaps Henry learned something in Rome, though he never knew it, and never sought it. Rome dwarfs teachers. The greatest men of the age scarcely bore the test of posing with Rome for a background. Perhaps Garibaldi- possibly even Cavour- could have sat "in the close of the evening, among the ruins of the Capitol," but one hardly saw Napoleon III there, or Palmerston or Tennyson or Longfellow. One morning, Adams happened to be chatting in the studio of Hamilton Wilde, when a middle-aged Englishman came in, evidently excited, and told of the shock he had just received, when riding near the Circus Maximus, at coming unexpectedly on the guillotine, where some criminal had been put to death an hour or two before. The sudden surprise had quite overcome him; and Adams, who seldom saw the point of a story till time had blunted it, listened sympathetically to learn what new form of grim horror had for the moment wiped out the memory of two thousand years of Roman bloodshed, or the consolation, derived from history and statistics, that most citizens of Rome seemed to be the better for guillotining. Only by slow degrees, he grappled the conviction that the victim of the shock was Robert Browning; and, on the background of the Circus Maximus, the Christian martyrs flaming as torches, and the morning's murderer on the block, Browning seemed rather in place, as a middle-aged gentlemanly English Pippa Passes; while afterwards, in the light of Belgravia dinner-tables, he never made part of his background except by effacement. Browning might have sat with Gibbon, among the ruins, and few Romans would have smiled. Yet Browning never revealed the poetic depths of Saint Francis; William Story could not touch the secret of Michael Angelo; and Mommsen hardly said all that one felt by instinct in the lives of Cicero and Caesar. They taught what, as a rule, needed no teaching, the lessons of a rather cheap imagination and cheaper politics. Rome was a bewildering complex of ideas, experiments, ambitions, energies; without her, the Western world was pointless and fragmentary; she gave heart and unity to it all; yet Gibbon might have gone on for the whole century, sitting among the ruins of the Capitol, and no one would have passed, capable of telling him what it meant. Perhaps it meant nothing. So it ended; the happiest month of May that life had yet offered, fading behind the present, and probably beyond the past, somewhere into abstract time, grotesquely out of place with the Berlin scheme or a Boston future. Adams explained to himself that he was absorbing knowledge. He would have put it better had he said that knowledge was absorbing him. He was passive. In spite of swarming impressions he knew no more when he left Rome than he did when he entered it. As a marketable object, his value was less. His next step went far to convince him that accidental education, whatever its economical return might be, was prodigiously successful as an object in itself. Everything conspired to ruin his sound scheme of life, and to make him a vagrant as well as pauper. He went on to Naples, and there, in the hot June, heard rumors that Garibaldi and his thousand were about to attack Palermo. Calling on the American Minister, Chandler of Pennsylvania, he was kindly treated, not for his merit, but for his name, and Mr. Chandler amiably consented to send him to the seat of war as bearer of despatches to Captain Palmer of the American sloop of war Iroquois. Young Adams seized the chance, and went to Palermo in a government transport filled with fleas, commanded by a charming Prince Caracciolo.`,c=[],l=[],u={edition:`preserved`,sourceFile:`Burbank_notes/Education_HA.htm`},d=[`burbank-notes-perspective-n`,`burbank-notes-protozoic-n`,`burbank-notes-times-n`],f={id:e,slug:t,type:n,title:r,sourceFile:i,encoding:a,html:o,text:s,links:c,images:l,provenance:u,backlinks:d};export{d as backlinks,f as default,a as encoding,o as html,e as id,l as images,c as links,u as provenance,t as slug,i as sourceFile,s as text,r as title,n as type};