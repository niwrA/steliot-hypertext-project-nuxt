var e=`waste-notes-unreal-n`,t=`unreal`,n=`annotation`,r=`Unreal City`,i=`Waste_notes/unreal_N.htm`,a=`windows-1252`,o=`
<div><center>
<table>
<tr>
<td><font><img src="../images/R.gif"/> </font><b>Unreal
        City</b><hr noshade=""/>
<p>Cf. Baudelaire:<br/>
        'Fourmillante cité, cité pleine de rêves,'<br/>
        'Où le spectre en plein jour raccroche le passant.' <a href="fourmill_T.htm"><img alt="click here for translation" src="../images/T.gif"/></a> [Eliot's note].
        The lines Eliot quotes are from "Les Sept
        Vieillards" ("The Seven Old Men") by
        Charles Baudelaire (1821-67); it is poem 93 of Les Fleurs
        du Mal ("The Flowers of Evil"). (NA) </p>
<p><font><em>reference topics</em></font></p>
<table>
<tr>
<td>link two</td>
<td><a href="title_A.htm"><img src="../images/arrowry.gif"/></a></td>
</tr>
<tr>
<td><a href="Waste_A.htm"><font>back to "The Waste Land" </font></a></td>
<td><a href="Burbank_A.htm"><img src="../images/arrowry.gif"/></a></td>
</tr>
</table>
</td>
</tr>
</table>
</center></div>
`,s=`Unreal City Cf. Baudelaire: 'Fourmillante cité, cité pleine de rêves,' 'Où le spectre en plein jour raccroche le passant.' [Eliot's note]. The lines Eliot quotes are from "Les Sept Vieillards" ("The Seven Old Men") by Charles Baudelaire (1821-67); it is poem 93 of Les Fleurs du Mal ("The Flowers of Evil"). (NA) reference topics link two back to "The Waste Land"`,c=[{kind:`internal`,path:`Waste_notes/fourmill_T.htm`,fragment:null,label:``,resolvedPath:`Waste_notes/fourmill_T.htm`,pageId:`waste-notes-fourmill-t`},{kind:`internal`,path:`Waste_notes/title_A.htm`,fragment:null,label:``,resolvedPath:`Burbank_notes/title_A.htm`,pageId:`burbank-notes-title-a`},{kind:`internal`,path:`Waste_notes/Waste_A.htm`,fragment:null,label:`back to "The Waste Land"`,resolvedPath:`Waste_notes/Waste_A.htm`,pageId:`waste-notes-waste-a`},{kind:`internal`,path:`Waste_notes/Burbank_A.htm`,fragment:null,label:``,resolvedPath:`Burbank_notes/Burbank_A.htm`,pageId:`burbank-notes-burbank-a`}],l=[{kind:`internal`,path:`images/R.gif`,fragment:null,alt:``},{kind:`internal`,path:`images/T.gif`,fragment:null,alt:`click here for translation`},{kind:`internal`,path:`images/arrowry.gif`,fragment:null,alt:``},{kind:`internal`,path:`images/arrowry.gif`,fragment:null,alt:``}],u={edition:`preserved`,sourceFile:`Waste_notes/unreal_N.htm`},d=[`waste-notes-fourmill-t`,`waste-notes-waste-a`],f={id:e,slug:t,type:n,title:r,sourceFile:i,encoding:a,html:o,text:s,links:c,images:l,provenance:u,backlinks:d};export{d as backlinks,f as default,a as encoding,o as html,e as id,l as images,c as links,u as provenance,t as slug,i as sourceFile,s as text,r as title,n as type};