var e=`burbank-notes-publication-data`,t=`publication-data`,n=`source-page`,r=`Publication History of "Burbank"`,i=`Burbank_notes/publication_data.htm`,a=`windows-1252`,o=`
<div><center>
<table>
<tr>
<td><a name="Burbank"></a><strong>full publication
        history<br/>
</strong>"Burbank with a Baedeker: Blestein with a
        Cigar"<p>The poem was first published in <em>Arts
        and Letters </em>(London), June 1919, under the title
        "Bleistein with a Cigar." It had been finished
        too late to be included in <em>Poems</em> 1919 (London),
        but was in time for the American publication of <em>Poems</em>
        (1920) in which it is included, now under the full title
        "Burbank with a Baedeker: Bleistein with a
        Cigar". Subsequently it was released in London in
        the bundle <em>Ara Vos Prec</em>, which contained all
        Eliot's poems so far including the four poems also in the
        American <em>Poems</em> (1920). Besides "Burbank
        with a Baedeker", these four poems included
        "Sweeney Erect", "A Cooking Egg" and
        "Gerontion" which are hence also termed the Ara
        Vos Prec group.</p>
<p>It is uncertain when Eliot started on
        "Burbank" but generally at least the year is
        presumed to be 1918, though I would not exclude the
        possibility of the Bleistein section being written as
        early as 1917, together with the first beginnings of
        "Gerontion." </p>
<p>Like nearly all Eliot's early poetry, Burbank has
        passed through Pound's hands, though a date for when this
        happened has not been given. This first draft contained
        the following variants:</p>
<p>l.2. And Triton blew his wrinkled shell. [instead of
        "Descending at a small hotel;"]<br/>
        l.6. Passed slowly like [instead of "Passed seaward
        with"]<br/>
        l.7. Seaward: [instead of "Slowly:"]<br/>
        l.29. the lion's mane [instead of "the lion's
        wings"]</p>
<p>Two of the alterations have come from suggestions by
        Pound, who suggested "wings" instead of mane,
        thus suggesting the Winged Lion of St Mark, and next to
        "shell" he wrote "If you 'hotel' this
        rhythm shd be weighted a bit, I think." The
        reference to 'hotel' seems to imply to me that Pound and
        Eliot had discussed the poem together on a previous
        occasion. </p>
<p>The first title and its subsequent change point to a
        shift in Eliot's own perspective on the poem - in that he
        presumably at least initially considered Bleistein the
        most important character. This would correspond with the
        evidence in the Notebook which shows that Eliot wrote the
        three stanzas on Bleistein first, and later added the
        other five stanzas and the epigram [# check!
        unfortunately I've lost the source for this, which
        substantially weakens my point. I'd be forever grateful
        to anyone who knows where I may have read this!] My guess
        is that he wrote Bleistein after he first came across
        Leopold Bloom in Joyce's <em>Ulysses</em> and recognised
        what Joyce was doing with that character, remembering the
        section in <em>Portrait of the Artist</em> in which
        Stephan discusses the principles of esthetic perception
        with Lynch. Eliot was a staunch supporter of this work,
        the best and most compact evidence of which we can find
        in his letter to John Quinn of 9 July 1919, in which he
        not only proposes that <em>The Egoist</em> should publish
        <em>Ulysses</em>, which it subsequently did and for which
        Eliot even proof read parts, such as Nestor for the
        January-February 1919 issue, but also praises John
        Quinn's defense of the work, expresses his frustration
        with not being able to "impose Joyce on such
        'intellectual' people, or people whose opinion carries
        weight as I know, in London." Finally, on the
        section from Ulysses for which the May issue of <em>The
        Egoist </em>was banned, "Scylla and Charybdis",
        he remarks that "the part ... struck me as almost
        the finest I have read: I have lived on it ever since I
        read it." We can see Eliot 's support of Joyce's
        work throughout his <em>Letters, </em>where he recommends
        the work to virtually everyone and calls Joyce "the
        greatest living prose writer" (to Scofield Thayer,
        30 June 1918). Influences of Joyce have been pointed at
        elsewhere in "Gerontion" also, and certainly a
        general similarity in, particularly allusionary, style
        between Joyce and Eliot, can be noted. </p>
<p>So, going back to Bleistein, Eliot seems to have made
        a link between Bleistein and the 'poet' character in
        Browning's poem "How it Strikes a Contemporary"
        - reasons for which in particular seem to be the role of
        prejudice of all kinds that Browning presents, including
        some which remind of Lopez-inspired mistrust which could
        have been from Shakespeare's days:</p>
<p>...such a brow<br/>
        His eyes had to live under!-clear as flint<br/>
        On either side the formidable nose<br/>
        Curved, cut, and coloured, like an eagle's claw.<br/>
        Had he to do with A.'s surprising fate?<br/>
        When altogether old B. disappeared<br/>
        And young C. got his mistress,-was't our friend,<br/>
        His letter to the King, that did it all?</p>
<p>The mistrust and suspected extravagance of this poet
        which the narrator presents to us as well as the physical
        description may remind us of a Jew. Although it is at
        least as likely Browning was thinking of Carlyle and his
        'Portraits', among which Tennyson who is described to
        have an 'aquiline nose' and whom as the poet laureate was
        in a position to converse with the King, the context in
        which Eliot uses the reference determines the
        interpretation, just as many of Eliot's allusions are in
        part (re)interpretations of the works cited in their new
        context. The contrast between rumour and what the
        narrator himself observes in Browning's poem suit Joyce's
        depiction of his Bloom character, and through these two
        the link to Shakespeare is inevitable. Particularly <em>Ulysses</em>
        springs to mind again, when Stephen implies that
        Shakespeare identified with Shylock, to whom Eliot
        alludes in the third "Bleistein" stanza, and
        suggests that Shakespeare resembled Shylock closely in
        spirit and business attitude; additionally, Stephen
        supports his argument by stating that Shakespeare was
        "made in Germany ... as the champion French polisher
        of Italian scandals" almost certainly seems to have
        inspired the line in "Gerontion<em>" </em>("Spawned
        in some estaminet of Antwerp,\xA0/ Blistered in
        Brussels, patched and peeled in London."), and
        presumably the line "Chicago Semite Viennese"
        stems from a similar wide-spread international conception
        of the Jew, which Eliot uses to attack the scandal around
        the publication of <em>Ulysses</em>, both in America and
        in England (It is with some irony that the current
        scandal over Eliot's alleged anti-Semitism can be viewed,
        in this respect.)</p>
<p>Having worked these three stanzas out in detail and
        keeping them in his scrapbook, presumably Eliot came to
        the idea of integrating it into a larger poem that
        included a comment on American "tourism" in
        Europe. This idea Eliot must have got from studying such
        eminent American tourists such as Henry Adams, Henry
        James, and George Wyndham, about whom he wrote several
        articles and reviews during 1918 and 1919, and with whom
        he himself must have identified, being himself in the
        same position - an American tourist in Europe. Eliot
        couples this investigation of what these people learned
        in Europe with observations from other, mostly English,
        writers who had a similar relationship to Venice as the
        Americans do with Europe, with Venice (together with
        Rome) as its supreme esthetic symbol, and with Burbank as
        the prototype of the American tourist, who imagines
        himself an Antony in Egypt, like George Wyndham, who is
        awakened from his Romantic musings by a Jew, like Henry
        James in <em>The Italian Hours</em>, and who is inspired
        by Venice to start asking questions, like Adams in Rome.
        Finally, there is perhaps Eliot himself, who goes a step
        further than Adams - who says that he, like everyone
        before him, can do little more than ask "why, why,
        why!" Rome, or in this case Venice, has fallen, and
        recalls John Ruskin who in <em>The Stones of Venice</em>
        gave specific reasons for why and specified when Venice
        had fallen. Ruskin, wielding his seven laws of
        architecture, holds the lot of Venice upwards to his
        English audience and tells them to pay heed, and Eliot
        does the same for his American audience in Chicago.
        London at this time has presumably already fallen for
        Eliot (viz. <em>The Waste Land</em>, where London closes
        the rank of fallen towers, after Vienna, which figures
        also in "Burbank", through "Istria"
        and "Viennese", as well as indirect references
        to Vienna, through <em>Hamlet</em> and perhaps even
        Freud's <em>Interpretation of Dreams</em>). </p>
<p>When Eliot changes the title from "Bleistein with
        a Cigar" to "Burbank with a Baedeker: Bleistein
        with a Cigar," he therefore presumably slightly
        shifts the focus of the poem to the American part, and
        hence his American audience. Like in so many of his poems
        at this time, the Eliot we see in Burbank remains both a
        liberal and a conservative, fighting on the one hand the
        lingering Victorian decadence of his age, expressed in
        his support of Joyce and condemnation of his condemnors,
        and on the other hand the deprecation of tradition, of
        the classics and the old values, the author of the essay
        "Tradition and the Individual Talent." There is
        no real contradiction - as the latter essay says, an
        artist needs to be aware of his predecessors to be able
        to see what he must add. </p>
<div><table>
<tr>
<td><font><strong>sources</strong></font></td>
</tr>
<tr>
<td>\xA0</td>
</tr>
</table>
</div></td>
</tr>
</table>
</center></div>
`,s=`full publication history "Burbank with a Baedeker: Blestein with a Cigar" The poem was first published in Arts and Letters (London), June 1919, under the title "Bleistein with a Cigar." It had been finished too late to be included in Poems 1919 (London), but was in time for the American publication of Poems (1920) in which it is included, now under the full title "Burbank with a Baedeker: Bleistein with a Cigar". Subsequently it was released in London in the bundle Ara Vos Prec , which contained all Eliot's poems so far including the four poems also in the American Poems (1920). Besides "Burbank with a Baedeker", these four poems included "Sweeney Erect", "A Cooking Egg" and "Gerontion" which are hence also termed the Ara Vos Prec group. It is uncertain when Eliot started on "Burbank" but generally at least the year is presumed to be 1918, though I would not exclude the possibility of the Bleistein section being written as early as 1917, together with the first beginnings of "Gerontion." Like nearly all Eliot's early poetry, Burbank has passed through Pound's hands, though a date for when this happened has not been given. This first draft contained the following variants: l.2. And Triton blew his wrinkled shell. [instead of "Descending at a small hotel;"] l.6. Passed slowly like [instead of "Passed seaward with"] l.7. Seaward: [instead of "Slowly:"] l.29. the lion's mane [instead of "the lion's wings"] Two of the alterations have come from suggestions by Pound, who suggested "wings" instead of mane, thus suggesting the Winged Lion of St Mark, and next to "shell" he wrote "If you 'hotel' this rhythm shd be weighted a bit, I think." The reference to 'hotel' seems to imply to me that Pound and Eliot had discussed the poem together on a previous occasion. The first title and its subsequent change point to a shift in Eliot's own perspective on the poem - in that he presumably at least initially considered Bleistein the most important character. This would correspond with the evidence in the Notebook which shows that Eliot wrote the three stanzas on Bleistein first, and later added the other five stanzas and the epigram [# check! unfortunately I've lost the source for this, which substantially weakens my point. I'd be forever grateful to anyone who knows where I may have read this!] My guess is that he wrote Bleistein after he first came across Leopold Bloom in Joyce's Ulysses and recognised what Joyce was doing with that character, remembering the section in Portrait of the Artist in which Stephan discusses the principles of esthetic perception with Lynch. Eliot was a staunch supporter of this work, the best and most compact evidence of which we can find in his letter to John Quinn of 9 July 1919, in which he not only proposes that The Egoist should publish Ulysses , which it subsequently did and for which Eliot even proof read parts, such as Nestor for the January-February 1919 issue, but also praises John Quinn's defense of the work, expresses his frustration with not being able to "impose Joyce on such 'intellectual' people, or people whose opinion carries weight as I know, in London." Finally, on the section from Ulysses for which the May issue of The Egoist was banned, "Scylla and Charybdis", he remarks that "the part ... struck me as almost the finest I have read: I have lived on it ever since I read it." We can see Eliot 's support of Joyce's work throughout his Letters, where he recommends the work to virtually everyone and calls Joyce "the greatest living prose writer" (to Scofield Thayer, 30 June 1918). Influences of Joyce have been pointed at elsewhere in "Gerontion" also, and certainly a general similarity in, particularly allusionary, style between Joyce and Eliot, can be noted. So, going back to Bleistein, Eliot seems to have made a link between Bleistein and the 'poet' character in Browning's poem "How it Strikes a Contemporary" - reasons for which in particular seem to be the role of prejudice of all kinds that Browning presents, including some which remind of Lopez-inspired mistrust which could have been from Shakespeare's days: ...such a brow His eyes had to live under!-clear as flint On either side the formidable nose Curved, cut, and coloured, like an eagle's claw. Had he to do with A.'s surprising fate? When altogether old B. disappeared And young C. got his mistress,-was't our friend, His letter to the King, that did it all? The mistrust and suspected extravagance of this poet which the narrator presents to us as well as the physical description may remind us of a Jew. Although it is at least as likely Browning was thinking of Carlyle and his 'Portraits', among which Tennyson who is described to have an 'aquiline nose' and whom as the poet laureate was in a position to converse with the King, the context in which Eliot uses the reference determines the interpretation, just as many of Eliot's allusions are in part (re)interpretations of the works cited in their new context. The contrast between rumour and what the narrator himself observes in Browning's poem suit Joyce's depiction of his Bloom character, and through these two the link to Shakespeare is inevitable. Particularly Ulysses springs to mind again, when Stephen implies that Shakespeare identified with Shylock, to whom Eliot alludes in the third "Bleistein" stanza, and suggests that Shakespeare resembled Shylock closely in spirit and business attitude; additionally, Stephen supports his argument by stating that Shakespeare was "made in Germany ... as the champion French polisher of Italian scandals" almost certainly seems to have inspired the line in "Gerontion " ("Spawned in some estaminet of Antwerp, / Blistered in Brussels, patched and peeled in London."), and presumably the line "Chicago Semite Viennese" stems from a similar wide-spread international conception of the Jew, which Eliot uses to attack the scandal around the publication of Ulysses , both in America and in England (It is with some irony that the current scandal over Eliot's alleged anti-Semitism can be viewed, in this respect.) Having worked these three stanzas out in detail and keeping them in his scrapbook, presumably Eliot came to the idea of integrating it into a larger poem that included a comment on American "tourism" in Europe. This idea Eliot must have got from studying such eminent American tourists such as Henry Adams, Henry James, and George Wyndham, about whom he wrote several articles and reviews during 1918 and 1919, and with whom he himself must have identified, being himself in the same position - an American tourist in Europe. Eliot couples this investigation of what these people learned in Europe with observations from other, mostly English, writers who had a similar relationship to Venice as the Americans do with Europe, with Venice (together with Rome) as its supreme esthetic symbol, and with Burbank as the prototype of the American tourist, who imagines himself an Antony in Egypt, like George Wyndham, who is awakened from his Romantic musings by a Jew, like Henry James in The Italian Hours , and who is inspired by Venice to start asking questions, like Adams in Rome. Finally, there is perhaps Eliot himself, who goes a step further than Adams - who says that he, like everyone before him, can do little more than ask "why, why, why!" Rome, or in this case Venice, has fallen, and recalls John Ruskin who in The Stones of Venice gave specific reasons for why and specified when Venice had fallen. Ruskin, wielding his seven laws of architecture, holds the lot of Venice upwards to his English audience and tells them to pay heed, and Eliot does the same for his American audience in Chicago. London at this time has presumably already fallen for Eliot (viz. The Waste Land , where London closes the rank of fallen towers, after Vienna, which figures also in "Burbank", through "Istria" and "Viennese", as well as indirect references to Vienna, through Hamlet and perhaps even Freud's Interpretation of Dreams ). When Eliot changes the title from "Bleistein with a Cigar" to "Burbank with a Baedeker: Bleistein with a Cigar," he therefore presumably slightly shifts the focus of the poem to the American part, and hence his American audience. Like in so many of his poems at this time, the Eliot we see in Burbank remains both a liberal and a conservative, fighting on the one hand the lingering Victorian decadence of his age, expressed in his support of Joyce and condemnation of his condemnors, and on the other hand the deprecation of tradition, of the classics and the old values, the author of the essay "Tradition and the Individual Talent." There is no real contradiction - as the latter essay says, an artist needs to be aware of his predecessors to be able to see what he must add. sources`,c=[],l=[],u={edition:`preserved`,sourceFile:`Burbank_notes/publication_data.htm`},d=`among-notes-title-n.burbank-notes-title-n.waste-notes-alatour-t.waste-notes-belladonna-n.waste-notes-brings-n.waste-notes-deadtree-n.waste-notes-ediosent-t.waste-notes-etoces-t.waste-notes-fabbro-n.waste-notes-ladyofro-n.waste-notes-packof-n.waste-notes-phoenici-n.waste-notes-poisasco-t.waste-notes-pound-n.waste-notes-quandofi-t.waste-notes-ricordit-t.waste-notes-schonist-t.waste-notes-sonofman-n.waste-notes-sosostri-n.waste-notes-sybil-n.waste-notes-sybil-t.waste-notes-tempest1-2-487-n.waste-notes-thereisshad-n.waste-notes-title-n.waste-notes-wagner-3.waste-notes-wagner3-24-t.waste-notes-wagner5-8-t`.split(`.`),f={id:e,slug:t,type:n,title:r,sourceFile:i,encoding:a,html:o,text:s,links:c,images:l,provenance:u,backlinks:d};export{d as backlinks,f as default,a as encoding,o as html,e as id,l as images,c as links,u as provenance,t as slug,i as sourceFile,s as text,r as title,n as type};