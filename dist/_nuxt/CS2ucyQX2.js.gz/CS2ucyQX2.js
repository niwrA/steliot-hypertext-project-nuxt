var e=`essays-swhamlet`,t=`swhamlet`,n=`source-page`,r=`Eliot, T. S. 1920. The Sacred Wood: Hamlet and His Problems.`,i=`Essays/swhamlet.htm`,a=`windows-1252`,o=`
<dl>
<div><center>
<dt><font><b>Hamlet and His Problems</b></font></dt>
</center></div>
</dl>
<div><center>
<table>
<tr>
<td><p>F<font>EW</font> critics
        have even admitted that <i>Hamlet</i> the play is the
        primary problem, and Hamlet the character only secondary.
        And Hamlet the character has had an especial temptation
        for that most dangerous type of critic: the critic with a
        mind which is naturally of the creative order, but which
        through some weakness in creative power exercises itself
        in criticism instead. These minds often find in Hamlet a
        vicarious existence for their own artistic realization.
        Such a mind had Goethe, who made of Hamlet a Werther; and
        such had Coleridge, who made of Hamlet a Coleridge; and
        probably neither of these men in writing about Hamlet
        remembered that his first business was to study a work of
        art. The kind of criticism that Goethe and Coleridge
        produced, in writing of Hamlet, is the most misleading
        kind possible. For they both possessed unquestionable
        critical insight, and both make their critical
        aberrations the more plausible by the
        substitution—of their own Hamlet for
        Shakespeare's—which their creative gift effects. We
        should be thankful that Walter Pater did not fix his
        attention on this play.</p>
<p>Two recent writers, Mr. J. M. Robertson and Professor
        Stoll of the University of Minnesota, have issued small
        books which can be praised for moving in the other
        direction. Mr. Stoll performs a service in recalling to
        our attention the labours of the critics of the
        seventeenth and eighteenth <a name="txt1">centuries</a>, <a href="#note1">1</a> observing that </p>
<blockquote>
<p>they knew less about psychology than more recent
            Hamlet critics, but they were nearer in spirit to
            Shakespeare's art; and as they insisted on the
            importance of the effect of the whole rather than on
            the importance of the leading character, they were
            nearer, in their old-fashioned way, to the secret of
            dramatic art in general.</p>
</blockquote>
<p><i>Qua</i> work of art, the work of art cannot be
        interpreted; there is nothing to interpret; we can only
        criticize it according to standards, in comparison to
        other works of art; and for "interpretation"
        the chief task is the presentation of relevant historical
        facts which the reader is not assumed to know. Mr.
        Robertson points out, very pertinently, how critics have
        failed in their "interpretation" of <i>Hamlet</i>
        by ignoring what ought to be very obvious: that <i>Hamlet</i>
        is a stratification, that it represents the efforts of a
        series of men, each making what he could out of the work
        of his predecessors. The <i>Hamlet</i> of Shakespeare
        will appear to us very differently if, instead of
        treating the whole action of the play as due to
        Shakespeare's design, we perceive his <i>Hamlet</i> to be
        superposed upon much cruder material which persists even
        in the final form.</p>
<p>We know that there was an older play by Thomas Kyd,
        that extraordinary dramatic (if not poetic) genius who
        was in all probability the author of two plays so
        dissimilar as the <i>Spanish Tragedy</i> and <i>Arden of
        Feversham;</i> and what this play was like we can guess
        from three clues: from the <i>Spanish Tragedy</i> itself,
        from the tale of Belleforest upon which Kyd's <i>Hamlet</i>
        must have been based, and from a version acted in Germany
        in Shakespeare's lifetime which bears strong evidence of
        having been adapted from the earlier, not from the later,
        play. From these three sources it is clear that in the
        earlier play the motive was a revenge-motive simply; that
        the action or delay is caused, as in the <i>Spanish
        Tragedy,</i> solely by the difficulty of assassinating a
        monarch surrounded by guards; and that the
        "madness" of Hamlet was feigned in order to
        escape suspicion, and successfully. In the final play of
        Shakespeare, on the other hand, there is a motive which
        is more important than that of revenge, and which
        explicitly "blunts" the latter; the delay in
        revenge is unexplained on grounds of necessity or
        expediency; and the effect of the "madness" is
        not to lull but to arouse the king's suspicion. The
        alteration is not complete enough, however, to be
        convincing. Furthermore, there are verbal parallels so
        close to the <i>Spanish Tragedy</i> as to leave no doubt
        that in places Shakespeare was merely <i>revising</i> the
        text of Kyd. And finally there are unexplained
        scenes—the Polonius-Laertes and the
        Polonius-Reynaldo scenes—for which there is little
        excuse; these scenes are not in the verse style of Kyd,
        and not beyond doubt in the style of Shakespeare. These
        Mr. Robertson believes to be scenes in the original play
        of Kyd reworked by a third hand, perhaps Chapman, before
        Shakespeare touched the play. And he concludes, with very
        strong show of reason, that the original play of Kyd was,
        like certain other revenge plays, in two parts of five
        acts each. The upshot of Mr. Robertson's examination is,
        we believe, irrefragable: that Shakespeare's <i>Hamlet,</i>
        so far as it is Shakespeare's, is a play dealing with the
        effect of a mother's guilt upon her son, and that
        Shakespeare was unable to impose this motive successfully
        upon the "intractable" material of the old
        play.</p>
<p>Of the intractability there can be no doubt. So far
        from being Shakespeare's masterpiece, the play is most
        certainly an artistic failure. In several ways the play
        is puzzling, and disquieting as is none of the others. Of
        all the plays it is the longest and is possibly the one
        on which Shakespeare spent most pains; and yet he has
        left in it superfluous and inconsistent scenes which even
        hasty revision should have noticed. The versification is
        variable. Lines like </p>
<blockquote>
<p>\xA0\xA0Look, the morn, in russet mantle clad,
            <br/>
            Walks o'er the dew of yon high eastern hill,</p>
</blockquote>
<p>are of the Shakespeare of <i>Romeo and Juliet.</i> The
        lines in Act v. sc. ii., </p>
<blockquote>
<p>Sir, in my heart there was a kind of fighting <br/>
            That would not let me sleep... <br/>
            Up from my cabin, <br/>
            My sea-gown scarf'd about me, in the dark <br/>
            Grop'd I to find out them: had my desire; <br/>
            Finger'd their packet;</p>
</blockquote>
<p>are of his quite mature. Both workmanship and thought
        are in an unstable condition. We are surely justified in
        attributing the play, with that other profoundly
        interesting play of "intractable" material and
        astonishing versification, <i>Measure for Measure,</i> to
        a period of crisis, after which follow the tragic
        successes which culminate in <i>Coriolanus. Coriolanus</i>
        may be not as "interesting" as <i>Hamlet,</i>
        but it is, with <i>Antony and Cleopatra,</i>
        Shakespeare's most assured artistic success. And probably
        more people have thought <i>Hamlet</i> a work of art
        because they found it interesting, than have found it
        interesting because it is a work of art. It is the
        "Mona Lisa" of literature.</p>
<p>The grounds of <i>Hamlet's</i> failure are not
        immediately obvious. Mr. Robertson is undoubtedly correct
        in concluding that the essential emotion of the play is
        the feeling of a son towards a guilty mother: </p>
<blockquote>
<p>\xA0\xA0[Hamlet's] tone is that of one who has
            suffered tortures on the score of his mother's
            degradation.... The guilt of a mother is an almost
            intolerable motive for drama, but it had to be
            maintained and emphasized to supply a psychological
            solution, or rather a hint of one.</p>
</blockquote>
<p>This, however, is by no means the whole story. It is
        not merely the "guilt of a mother" that cannot
        be handled as Shakespeare handled the suspicion of
        Othello, the infatuation of Antony, or the pride of
        Coriolanus. The subject might conceivably have expanded
        into a tragedy like these, intelligible, self-complete,
        in the sunlight. <i>Hamlet,</i> like the sonnets, is full
        of some stuff that the writer could not drag to light,
        contemplate, or manipulate into art. And when we search
        for this feeling, we find it, as in the sonnets, very
        difficult to localize. You cannot point to it in the
        speeches; indeed, if you examine the two famous
        soliloquies you see the versification of Shakespeare, but
        a content which might be claimed by another, perhaps by
        the author of the <i>Revenge of Bussy d' Ambois,</i> Act
        v. sc. i. We find Shakespeare's <i>Hamlet</i> not in the
        action, not in any quotations that we might select, so
        much as in an unmistakable tone which is unmistakably not
        in the earlier play.</p>
<p>\xA0The only way of expressing emotion in the form
        of art is by finding an "objective
        correlative"; in other words, a set of objects, a
        situation, a chain of events which shall be the formula
        of that <i>particular</i> emotion; such that when the
        external facts, which must terminate in sensory
        experience, are given, the emotion is immediately evoked.
        If you examine any of Shakespeare's more successful
        tragedies, you will find this exact equivalence; you will
        find that the state of mind of Lady Macbeth walking in
        her sleep has been communicated to you by a skilful
        accumulation of imagined sensory impressions; the words
        of Macbeth on hearing of his wife's death strike us as
        if, given the sequence of events, these words were
        automatically released by the last event in the series.
        The artistic "inevitability" lies in this
        complete adequacy of the external to the emotion; and
        this is precisely what is deficient in <i>Hamlet.</i>
        Hamlet (the man) is dominated by an emotion which is
        inexpressible, because it is in <i>excess</i> of the
        facts as they appear. And the supposed identity of Hamlet
        with his author is genuine to this point: that Hamlet's
        bafflement at the absence of objective equivalent to his
        feelings is a prolongation of the bafflement of his
        creator in the face of his artistic problem. Hamlet is up
        against the difficulty that his disgust is occasioned by
        his mother, but that his mother is not an adequate
        equivalent for it; his disgust envelops and exceeds her.
        It is thus a feeling which he cannot understand; he
        cannot objectify it, and it therefore remains to poison
        life and obstruct action. None of the possible actions
        can satisfy it; and nothing that Shakespeare can do with
        the plot can express Hamlet for him. And it must be
        noticed that the very nature of the <i>données</i> of
        the problem precludes objective equivalence. To have
        heightened the criminality of Gertrude would have been to
        provide the formula for a totally different emotion in
        Hamlet; it is just <i>because</i> her character is so
        negative and insignificant that she arouses in Hamlet the
        feeling which she is incapable of representing.</p>
<p>The "madness" of Hamlet lay to Shakespeare's
        hand; in the earlier play a simple ruse, and to the end,
        we may presume, understood as a ruse by the audience. For
        Shakespeare it is less than madness and more than
        feigned. The levity of Hamlet, his repetition of phrase,
        his puns, are not part of a deliberate plan of
        dissimulation, but a form of emotional relief. In the
        character Hamlet it is the buffoonery of an emotion which
        can find no outlet in action; in the dramatist it is the
        buffoonery of an emotion which he cannot express in art.
        The intense feeling, ecstatic or terrible, without an
        object or exceeding its object, is something which every
        person of sensibility has known; it is doubtless a study
        to pathologists. It often occurs in adolescence: the
        ordinary person puts these feelings to sleep, or trims
        down his feeling to fit the business world; the artist
        keeps it alive by his ability to intensify the world to
        his emotions. The Hamlet of Laforgue is an adolescent;
        the Hamlet of Shakespeare is not, he has not that
        explanation and excuse. We must simply admit that here
        Shakespeare tackled a problem which proved too much for
        him. Why he attempted it at all is an insoluble puzzle;
        under compulsion of what experience he attempted to
        express the inexpressibly horrible, we cannot ever know.
        We need a great many facts in his biography; and we
        should like to know whether, and when, and after or at
        the same time as what personal experience, he read
        Montaigne, II. xii., <i>Apologie de Raimond Sebond.</i>
        We should have, finally, to know something which is by
        hypothesis unknowable, for we assume it to be an
        experience which, in the manner indicated, exceeded the
        facts. We should have to understand things which
        Shakespeare did not understand himself. </p>
</td>
</tr>
</table>
</center></div>
<dl>
<dt><b></b>\xA0</dt>
<dt><a name="note1"><b>Note 1</b></a> </dt>
<dd>I have never, by the way, seen a cogent refutation of
        Thomas Rymer's objections to <i>Othello.</i> </dd>
</dl>
`,s=`Hamlet and His Problems F EW critics have even admitted that Hamlet the play is the primary problem, and Hamlet the character only secondary. And Hamlet the character has had an especial temptation for that most dangerous type of critic: the critic with a mind which is naturally of the creative order, but which through some weakness in creative power exercises itself in criticism instead. These minds often find in Hamlet a vicarious existence for their own artistic realization. Such a mind had Goethe, who made of Hamlet a Werther; and such had Coleridge, who made of Hamlet a Coleridge; and probably neither of these men in writing about Hamlet remembered that his first business was to study a work of art. The kind of criticism that Goethe and Coleridge produced, in writing of Hamlet, is the most misleading kind possible. For they both possessed unquestionable critical insight, and both make their critical aberrations the more plausible by the substitution—of their own Hamlet for Shakespeare's—which their creative gift effects. We should be thankful that Walter Pater did not fix his attention on this play. Two recent writers, Mr. J. M. Robertson and Professor Stoll of the University of Minnesota, have issued small books which can be praised for moving in the other direction. Mr. Stoll performs a service in recalling to our attention the labours of the critics of the seventeenth and eighteenth centuries , 1 observing that they knew less about psychology than more recent Hamlet critics, but they were nearer in spirit to Shakespeare's art; and as they insisted on the importance of the effect of the whole rather than on the importance of the leading character, they were nearer, in their old-fashioned way, to the secret of dramatic art in general. Qua work of art, the work of art cannot be interpreted; there is nothing to interpret; we can only criticize it according to standards, in comparison to other works of art; and for "interpretation" the chief task is the presentation of relevant historical facts which the reader is not assumed to know. Mr. Robertson points out, very pertinently, how critics have failed in their "interpretation" of Hamlet by ignoring what ought to be very obvious: that Hamlet is a stratification, that it represents the efforts of a series of men, each making what he could out of the work of his predecessors. The Hamlet of Shakespeare will appear to us very differently if, instead of treating the whole action of the play as due to Shakespeare's design, we perceive his Hamlet to be superposed upon much cruder material which persists even in the final form. We know that there was an older play by Thomas Kyd, that extraordinary dramatic (if not poetic) genius who was in all probability the author of two plays so dissimilar as the Spanish Tragedy and Arden of Feversham; and what this play was like we can guess from three clues: from the Spanish Tragedy itself, from the tale of Belleforest upon which Kyd's Hamlet must have been based, and from a version acted in Germany in Shakespeare's lifetime which bears strong evidence of having been adapted from the earlier, not from the later, play. From these three sources it is clear that in the earlier play the motive was a revenge-motive simply; that the action or delay is caused, as in the Spanish Tragedy, solely by the difficulty of assassinating a monarch surrounded by guards; and that the "madness" of Hamlet was feigned in order to escape suspicion, and successfully. In the final play of Shakespeare, on the other hand, there is a motive which is more important than that of revenge, and which explicitly "blunts" the latter; the delay in revenge is unexplained on grounds of necessity or expediency; and the effect of the "madness" is not to lull but to arouse the king's suspicion. The alteration is not complete enough, however, to be convincing. Furthermore, there are verbal parallels so close to the Spanish Tragedy as to leave no doubt that in places Shakespeare was merely revising the text of Kyd. And finally there are unexplained scenes—the Polonius-Laertes and the Polonius-Reynaldo scenes—for which there is little excuse; these scenes are not in the verse style of Kyd, and not beyond doubt in the style of Shakespeare. These Mr. Robertson believes to be scenes in the original play of Kyd reworked by a third hand, perhaps Chapman, before Shakespeare touched the play. And he concludes, with very strong show of reason, that the original play of Kyd was, like certain other revenge plays, in two parts of five acts each. The upshot of Mr. Robertson's examination is, we believe, irrefragable: that Shakespeare's Hamlet, so far as it is Shakespeare's, is a play dealing with the effect of a mother's guilt upon her son, and that Shakespeare was unable to impose this motive successfully upon the "intractable" material of the old play. Of the intractability there can be no doubt. So far from being Shakespeare's masterpiece, the play is most certainly an artistic failure. In several ways the play is puzzling, and disquieting as is none of the others. Of all the plays it is the longest and is possibly the one on which Shakespeare spent most pains; and yet he has left in it superfluous and inconsistent scenes which even hasty revision should have noticed. The versification is variable. Lines like Look, the morn, in russet mantle clad, Walks o'er the dew of yon high eastern hill, are of the Shakespeare of Romeo and Juliet. The lines in Act v. sc. ii., Sir, in my heart there was a kind of fighting That would not let me sleep... Up from my cabin, My sea-gown scarf'd about me, in the dark Grop'd I to find out them: had my desire; Finger'd their packet; are of his quite mature. Both workmanship and thought are in an unstable condition. We are surely justified in attributing the play, with that other profoundly interesting play of "intractable" material and astonishing versification, Measure for Measure, to a period of crisis, after which follow the tragic successes which culminate in Coriolanus. Coriolanus may be not as "interesting" as Hamlet, but it is, with Antony and Cleopatra, Shakespeare's most assured artistic success. And probably more people have thought Hamlet a work of art because they found it interesting, than have found it interesting because it is a work of art. It is the "Mona Lisa" of literature. The grounds of Hamlet's failure are not immediately obvious. Mr. Robertson is undoubtedly correct in concluding that the essential emotion of the play is the feeling of a son towards a guilty mother: [Hamlet's] tone is that of one who has suffered tortures on the score of his mother's degradation.... The guilt of a mother is an almost intolerable motive for drama, but it had to be maintained and emphasized to supply a psychological solution, or rather a hint of one. This, however, is by no means the whole story. It is not merely the "guilt of a mother" that cannot be handled as Shakespeare handled the suspicion of Othello, the infatuation of Antony, or the pride of Coriolanus. The subject might conceivably have expanded into a tragedy like these, intelligible, self-complete, in the sunlight. Hamlet, like the sonnets, is full of some stuff that the writer could not drag to light, contemplate, or manipulate into art. And when we search for this feeling, we find it, as in the sonnets, very difficult to localize. You cannot point to it in the speeches; indeed, if you examine the two famous soliloquies you see the versification of Shakespeare, but a content which might be claimed by another, perhaps by the author of the Revenge of Bussy d' Ambois, Act v. sc. i. We find Shakespeare's Hamlet not in the action, not in any quotations that we might select, so much as in an unmistakable tone which is unmistakably not in the earlier play. The only way of expressing emotion in the form of art is by finding an "objective correlative"; in other words, a set of objects, a situation, a chain of events which shall be the formula of that particular emotion; such that when the external facts, which must terminate in sensory experience, are given, the emotion is immediately evoked. If you examine any of Shakespeare's more successful tragedies, you will find this exact equivalence; you will find that the state of mind of Lady Macbeth walking in her sleep has been communicated to you by a skilful accumulation of imagined sensory impressions; the words of Macbeth on hearing of his wife's death strike us as if, given the sequence of events, these words were automatically released by the last event in the series. The artistic "inevitability" lies in this complete adequacy of the external to the emotion; and this is precisely what is deficient in Hamlet. Hamlet (the man) is dominated by an emotion which is inexpressible, because it is in excess of the facts as they appear. And the supposed identity of Hamlet with his author is genuine to this point: that Hamlet's bafflement at the absence of objective equivalent to his feelings is a prolongation of the bafflement of his creator in the face of his artistic problem. Hamlet is up against the difficulty that his disgust is occasioned by his mother, but that his mother is not an adequate equivalent for it; his disgust envelops and exceeds her. It is thus a feeling which he cannot understand; he cannot objectify it, and it therefore remains to poison life and obstruct action. None of the possible actions can satisfy it; and nothing that Shakespeare can do with the plot can express Hamlet for him. And it must be noticed that the very nature of the données of the problem precludes objective equivalence. To have heightened the criminality of Gertrude would have been to provide the formula for a totally different emotion in Hamlet; it is just because her character is so negative and insignificant that she arouses in Hamlet the feeling which she is incapable of representing. The "madness" of Hamlet lay to Shakespeare's hand; in the earlier play a simple ruse, and to the end, we may presume, understood as a ruse by the audience. For Shakespeare it is less than madness and more than feigned. The levity of Hamlet, his repetition of phrase, his puns, are not part of a deliberate plan of dissimulation, but a form of emotional relief. In the character Hamlet it is the buffoonery of an emotion which can find no outlet in action; in the dramatist it is the buffoonery of an emotion which he cannot express in art. The intense feeling, ecstatic or terrible, without an object or exceeding its object, is something which every person of sensibility has known; it is doubtless a study to pathologists. It often occurs in adolescence: the ordinary person puts these feelings to sleep, or trims down his feeling to fit the business world; the artist keeps it alive by his ability to intensify the world to his emotions. The Hamlet of Laforgue is an adolescent; the Hamlet of Shakespeare is not, he has not that explanation and excuse. We must simply admit that here Shakespeare tackled a problem which proved too much for him. Why he attempted it at all is an insoluble puzzle; under compulsion of what experience he attempted to express the inexpressibly horrible, we cannot ever know. We need a great many facts in his biography; and we should like to know whether, and when, and after or at the same time as what personal experience, he read Montaigne, II. xii., Apologie de Raimond Sebond. We should have, finally, to know something which is by hypothesis unknowable, for we assume it to be an experience which, in the manner indicated, exceeded the facts. We should have to understand things which Shakespeare did not understand himself. Note 1 I have never, by the way, seen a cogent refutation of Thomas Rymer's objections to Othello.`,c=[],l=[],u={edition:`preserved`,sourceFile:`Essays/swhamlet.htm`},d=[`thesacredwood`],f={id:e,slug:t,type:n,title:r,sourceFile:i,encoding:a,html:o,text:s,links:c,images:l,provenance:u,backlinks:d};export{d as backlinks,f as default,a as encoding,o as html,e as id,l as images,c as links,u as provenance,t as slug,i as sourceFile,s as text,r as title,n as type};