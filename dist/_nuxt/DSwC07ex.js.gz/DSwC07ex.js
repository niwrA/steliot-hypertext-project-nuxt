var e=`waste-notes-stanbergersee-n`,t=`stanbergersee`,n=`annotation`,r=`Stanbergersee`,i=`Waste_notes/Stanbergersee_N.htm`,a=`windows-1252`,o=`
<div><center>
<table>
<tr>
<td><font><img src="../images/R.gif"/> <strong>Starnbergersee</strong></font><hr noshade=""/>
<p>Lake a few miles south of Munich, where the
        "mad" King Ludwig II of Bavaria drowned in 1886
        in mysterious circumstances. This romantic, melancholy
        king was a passionate admirer of Richard Wagner and
        especially of Wagner's opera Tristan und Isolde, which
        plays a significant part in The Waste Land. Ludwig's
        suffering of "death by water" in the
        Stanbergersee thus evokes a cluster of themes central to
        the poem. (NA) </p>
<p><font><em>reference topics</em></font></p>
<table>
<tr>
<td><a href="Waste_A.htm"><font>back to "The Waste Land" </font></a></td>
<td><a href="Burbank_A.htm"><img src="../images/arrowry.gif"/></a></td>
</tr>
</table>
</td>
</tr>
</table>
</center></div>
`,s=`Starnbergersee Lake a few miles south of Munich, where the "mad" King Ludwig II of Bavaria drowned in 1886 in mysterious circumstances. This romantic, melancholy king was a passionate admirer of Richard Wagner and especially of Wagner's opera Tristan und Isolde, which plays a significant part in The Waste Land. Ludwig's suffering of "death by water" in the Stanbergersee thus evokes a cluster of themes central to the poem. (NA) reference topics back to "The Waste Land"`,c=[{kind:`internal`,path:`Waste_notes/Waste_A.htm`,fragment:null,label:`back to "The Waste Land"`,resolvedPath:`Waste_notes/Waste_A.htm`,pageId:`waste-notes-waste-a`},{kind:`internal`,path:`Waste_notes/Burbank_A.htm`,fragment:null,label:``,resolvedPath:`Burbank_notes/Burbank_A.htm`,pageId:`burbank-notes-burbank-a`}],l=[{kind:`internal`,path:`images/R.gif`,fragment:null,alt:``},{kind:`internal`,path:`images/arrowry.gif`,fragment:null,alt:``}],u={edition:`preserved`,sourceFile:`Waste_notes/Stanbergersee_N.htm`},d=[`waste-notes-waste-a`],f={id:e,slug:t,type:n,title:r,sourceFile:i,encoding:a,html:o,text:s,links:c,images:l,provenance:u,backlinks:d};export{d as backlinks,f as default,a as encoding,o as html,e as id,l as images,c as links,u as provenance,t as slug,i as sourceFile,s as text,r as title,n as type};