var e=`essays-swjohnson`,t=`swjohnson`,n=`source-page`,r=`Eliot, T. S. 1920. The Sacred Wood: Ben Jonson.`,i=`Essays/swjohnson.htm`,a=`windows-1252`,o=`
<p><font><b>Ben Jonson</b></font></p>
<div><center>
<table>
<tr>
<td><p>T<font>HE</font> reputation
        of Jonson has been of the most deadly kind that can be
        compelled upon the memory of a great poet. To be
        universally accepted; to be damned by the praise that
        quenches all desire to read the book; to be afflicted by
        the imputation of the virtues which excite the least
        pleasure; and to be read only by historians and
        antiquaries—this is the most perfect conspiracy of
        approval. For some generations the reputation of Jonson
        has been carried rather as a liability than as an asset
        in the balance-sheet of English literature. No critic has
        succeeded in making him appear pleasurable or even
        interesting. Swinburne's book on Jonson satisfies no
        curiosity and stimulates no thought. For the critical
        study in the "Men of Letters Series" by Mr.
        Gregory Smith there is a place; it satisfies curiosity,
        it supplies many just observations, it provides valuable
        matter on the neglected masques; it only fails to remodel
        the image of Jonson which is settled in our minds.
        Probably the fault lies with several generations of our
        poets. It is not that the value of poetry is only its
        value to living poets for their own work; but
        appreciation is akin to creation, and true enjoyment of
        poetry is related to the stirring of suggestion, the
        stimulus that a poet feels in his enjoyment of other
        poetry. Jonson has provided no creative stimulus for a
        very long time; consequently we must look back as far as
        Dryden—precisely, a poetic practitioner who learned
        from Jonson—before we find a living criticism of
        Jonson's work.</p>
<p>Yet there are possibilities for Jonson
        even now. We have no difficulty in seeing what brought
        him to this pass; how, in contrast, not with Shakespeare,
        but with Marlowe, Webster, Donne, Beaumont, and Fletcher,
        he has been paid out with reputation instead of
        enjoyment. He is no less a poet than these men, but his
        poetry is of the surface. Poetry of the surface cannot be
        understood without study; for to deal with the surface of
        life, as Jonson dealt with it, is to deal so deliberately
        that we too must be deliberate, in order to understand.
        Shakespeare, and smaller men also, are in the end more
        difficult, but they offer something at the start to
        encourage the student or to satisfy those who want
        nothing more; they are suggestive, evocative, a phrase, a
        voice; they offer poetry in detail as well as in design.
        So does Dante offer something, a phrase everywhere (<i>tu
        se' ombra ed ombra vedi</i>) even to readers who have no
        Italian; and Dante and Shakespeare have poetry of design
        as well as of detail. But the polished veneer of Jonson
        reflects only the lazy reader's fatuity; unconscious does
        not respond to unconscious; no swarms of inarticulate
        feelings are aroused. The immediate appeal of Jonson is
        to the mind; his emotional tone is not in the single
        verse, but in the design of the whole. But not many
        people are capable of discovering for themselves the
        beauty which is only found after labour; and Jonson's
        industrious readers have been those whose interest was
        historical and curious, and those who have thought that
        in discovering the historical and curious interest they
        had discovered the artistic value as well. When we say
        that Jonson requires study, we do not mean study of his
        classical scholarship or of seventeenth-century manners.
        We mean intelligent saturation in his work as a whole; we
        mean that in order to enjoy him at all, we must get to
        the centre of his work and his temperament, and that we
        must see him unbiased by time, as a contemporary. And to
        see him as a contemporary does not so much require the
        power of putting ourselves into seventeenth-century
        London as it requires the power of setting Jonson in our
        London: a more difficult triumph of divination.</p>
<p>\xA0It is generally conceded that
        Jonson failed as a tragic dramatist; and it is usually
        agreed that he failed because his genius was for satiric
        comedy and because of the weight of pedantic learning
        with which he burdened his two tragic failures. The
        second point marks an obvious error of detail; the first
        is too crude a statement to be accepted; to say that he
        failed because his genius was unsuited to tragedy is to
        tell us nothing at all. Jonson did not write a good
        tragedy, but we can see no reason why he should not have
        written one. If two plays so different as <i>The Tempest</i>
        and <i>The Silent Woman</i> are both comedies, surely the
        category of tragedy could be made wide enough to include
        something possible for Jonson to have done. But the
        classification of tragedy and comedy, while it may be
        sufficient to mark the distinction in a dramatic
        literature of more rigid form and treatment—it may
        distinguish Aristophanes from Euripides—is not
        adequate to a drama of such variations as the
        Elizabethans. Tragedy is a crude classification for plays
        so different in their tone as <i>Macbeth, The Jew of
        Malta,</i> and <i>The Witch of Edmonton;</i> and it does
        not help us much to say that <i>The Merchant of Venice</i>
        and <i>The Alchemist</i> are comedies. Jonson had his own
        scale, his own instrument. The merit which <i>Catiline</i>
        possesses is the same merit that is exhibited more
        triumphantly in <i>Volpone; Catiline</i> fails, not
        because it is too laboured and conscious, but because it
        is not conscious enough; because Jonson in this play was
        not alert to his own idiom, not clear in his mind as to
        what his temperament wanted him to do. In <i>Catiline</i>
        Jonson conforms, or attempts to conform, to conventions;
        not to the conventions of antiquity, which he had
        exquisitely under control, but to the conventions of
        tragico-historical drama of his time. It is not the Latin
        erudition that sinks <i>Catiline,</i> but the application
        of that erudition to a form which was not the proper
        vehicle for the mind which had amassed the erudition.</p>
<p>\xA0If you look at <i>Catiline</i>—that dreary
        Pyrrhic victory of tragedy—you find two passages to
        be successful: Act ii. scene I, the dialogue of the
        political ladies, and the Prologue of Sylla's ghost.
        These two passages are genial. The soliloquy of the ghost
        is a characteristic Jonson success in content and in
        versification— </p>
<blockquote>
<p>Dost thou not feel me, Rome? not yet! is night <br/>
            So heavy on thee, and my weight so light? <br/>
            Can Sylla's ghost arise within thy walls, <br/>
            Less threatening than an earthquake, the quick falls <br/>
            Of thee and thine? Shake not the frighted heads <br/>
            Of thy steep towers, or shrink to their first beds? <br/>
            Or as their ruin the large Tyber fills, <br/>
            Make that swell up, and drown thy seven proud
            hills?...</p>
</blockquote>
<p>This is the learned, but also the creative, Jonson.
        Without concerning himself with the character of Sulla,
        and in lines of invective, Jonson makes Sylla's ghost,
        while the words are spoken, a living and terrible force.
        The words fall with as determined beat as if they were
        the will of the morose Dictator himself. You may say:
        merely invective; but mere invective, even if as superior
        to the clumsy fisticuffs of Marston and Hall as Jonson's
        verse is superior to theirs, would not create a living
        figure as Jonson has done in this long tirade. And you
        may say; rhetoric; but if we are to call it
        "rhetoric" we must subject that term to a
        closer dissection than any to which it is accustomed.
        What Jonson has done here is not merely a fine speech. It
        is the careful, precise filling in of a strong and simple
        outline, and at no point does it overflow the outline; it
        is far more careful and precise in its obedience to this
        outline than are many of the speeches in <i>Tamburlaine.</i>
        The outline is not Sulla, for Sulla has nothing to do
        with it, but "Sylla's ghost." The words may not
        be suitable to an historical Sulla, or to anybody in
        history, but they are a perfect expression for
        "Sylla's ghost." You cannot say they are
        rhetorical "because people do not talk like
        that," you cannot call them "verbiage";
        they do not exhibit prolixity or redundancy or the other
        vices in the rhetoric books; there is a definite artistic
        emotion which demands expression at that length. The
        words themselves are mostly simple words, the syntax is
        natural, the language austere rather than adorned.
        Turning then to the induction of <i>The Poetaster,</i> we
        find another success of the same kind— </p>
<blockquote>
<p>Light, I salute thee, but with wounded nerves...</p>
</blockquote>
<p>Men may not talk in that way, but the spirit of envy
        does, and in the words of Jonson envy is a real and
        living person. It is not human life that informs envy and
        Sylla's ghost, but it is energy of which human life is
        only another variety.</p>
<p>Returning to <i>Catiline,</i> we find that the best
        scene in the body of the play is one which cannot be
        squeezed into a tragic frame, and which appears to belong
        to satiric comedy. The scene between Fulvia and Galla and
        Sempronia is a living scene in a wilderness of oratory.
        And as it recalls other scenes—there is a suggestion
        of the college of ladies in <i>The Silent Woman</i>—it
        looks like a comedy scene. And it appears to be satire. </p>
<blockquote>
<p>They shall all give and pay well, that come here, <br/>
            If they will have it; and that, jewels, pearl, <br/>
            Plate, or round sums to buy these. I'm not taken <br/>
            With a cob-swan or a high-mounting bull, <br/>
            As foolish Leda and Europa were; <br/>
            But the bright gold, with Danaë. For such price <br/>
            I would endure a rough, harsh Jupiter, <br/>
            Or ten such thundering gamesters, and refrain <br/>
            To laugh at 'em, till they are gone, with my much
            suffering.</p>
</blockquote>
<p>This scene is no more comedy than it is tragedy, and
        the "satire" is merely a medium for the
        essential emotion. Jonson's drama is only incidentally
        satire, because it is only incidentally a criticism upon
        the actual world. It is not satire in the way in which
        the work of Swift or the work of Molière may be called
        satire: that is, it does not find its source in any
        precise emotional attitude or precise intellectual
        criticism of the actual world. It is satire perhaps as
        the work of Rabelais is satire; certainly not more so.
        The important thing is that if fiction can be divided
        into creative fiction and critical fiction, Jonson's is
        creative. That he was a great critic, our first great
        critic, does not affect this assertion. Every creator is
        also a critic; Jonson was a conscious critic, but he was
        also conscious in his creations. Certainly, one sense in
        which the term "critical" may be applied to
        fiction is a sense in which the term might be used of a
        method antithetical to Jonson's. It is the method of <i>Education
        Sentimentale.</i> The characters of Jonson, of
        Shakespeare, perhaps of all the greatest drama, are drawn
        in positive and simple outlines. They may be filled in,
        and by Shakespeare they are filled in, by much detail or
        many shifting aspects; but a clear and sharp and simple
        form remains through these—though it would be hard
        to say in what the clarity and sharpness and simplicity
        of Hamlet consists. But Frédéric Moreau is not made in
        that way. He is constructed partly by negative
        definition, built up by a great number of observations.
        We cannot isolate him from the environment in which we
        find him; it may be an environment which is or can be
        much universalized; nevertheless it, and the figure in
        it, consist of very many observed particular facts, the
        actual world. Without this world the figure dissolves.
        The ruling faculty is a critical perception, a commentary
        upon experienced feeling and sensation. If this is true
        of Flaubert, it is true in a higher degree of Molière
        than of Jonson. The broad farcical lines of Molière may
        seem to be the same drawing as Jonson's. But
        Molière—say in Alceste or Monsieur Jourdain—is
        criticizing the actual; the reference to the actual world
        is more direct. And having a more tenuous reference, the
        work of Jonson is much less directly satirical.</p>
<p>\xA0This leads us to the question of Humours.
        Largely on the evidence of the two Humour plays, it is
        sometimes assumed that Jonson is occupied with types;
        typical exaggerations, or exaggerations of type. The
        Humour definition, the expressed intention of Jonson, may
        be satisfactory for these two plays. <i>Every Man in his
        Humour</i> is the first mature work of Jonson, and the
        student of Jonson must study it; but it is not the play
        in which Jonson found his genius: it is the last of his
        plays to read first. If one reads <i>Volpone,</i> and
        after that re-reads the <i>Jew of Malta;</i> then returns
        to Jonson and reads <i>Bartholomew Fair, The Alchemist,
        Epicoene</i> and <i>The Devil is an Ass,</i> and finally <i>Catiline,</i>
        it is possible to arrive at a fair opinion of the poet
        and the dramatist.</p>
<p>The Humour, even at the beginning, is not a type, as
        in Marston's satire, but a simplified and somewhat
        distorted individual with a typical mania. In the later
        work, the Humour definition quite fails to account for
        the total effect produced. The characters of Shakespeare
        are such as might exist in different circumstances than
        those in which Shakespeare sets them. The latter appear
        to be those which extract from the characters the most
        intense and interesting realization; but that realization
        has not exhausted their possibilities. Volpone's life, on
        the other hand, is bounded by the scene in which it is
        played; in fact, the life is the life of the scene and is
        derivatively the life of Volpone; the life of the
        character is inseparable from the life of the drama. This
        is not dependence upon a background, or upon a substratum
        of fact. The emotional effect is single and simple.
        Whereas in Shakespeare the effect is due to the way in
        which the characters <i>act upon</i> one another, in
        Jonson it is given by the way in which the characters <i>fit
        in</i> with each other. The artistic result of <i>Volpone</i>
        is not due to any effect that Volpone, Mosca, Corvino,
        Corbaccio, Voltore have upon each other, but simply to
        their combination into a whole. And these figures are not
        personifications of passions; separately, they have not
        even that reality, they are constituents. It is a similar
        indication of Jonson's method that you can hardly pick
        out a line of Jonson's and say confidently that it is
        great poetry; but there are many extended passages to
        which you cannot deny that honour. </p>
<blockquote>
<p>I will have all my beds blown up, not stuft; <br/>
            Down is too hard; and then, mine oval room <br/>
            Fill'd with such pictures as Tiberius took <br/>
            From Elephantis, and dull Aretine <br/>
            But coldly imitated. Then, my glasses <br/>
            Cut in more subtle angles, to disperse <br/>
            And multiply the figures, as I walk....</p>
</blockquote>
<p>\xA0Jonson is the legitimate heir of Marlowe. The
        man who wrote, in <i>Volpone:</i> </p>
<blockquote>
<p>\xA0\xA0\xA0\xA0\xA0\xA0\xA0\xA0\xA0\xA0\xA0\xA0\xA0\xA0\xA0\xA0\xA0\xA0\xA0\xA0for
            thy love, <br/>
            In varying figures, I would have contended <br/>
            With the blue Proteus, or the hornèd flood....</p>
</blockquote>
<p>and </p>
<blockquote>
<p>\xA0\xA0\xA0\xA0\xA0\xA0\xA0\xA0\xA0\xA0\xA0\xA0\xA0\xA0\xA0\xA0\xA0\xA0\xA0\xA0See,
            a carbuncle <br/>
            May put out both the eyes of our Saint Mark; <br/>
            A diamond would have bought Lollia Paulina, <br/>
            When she came in like star-light, hid with jewels....</p>
</blockquote>
<p>is related to Marlowe as a poet; and if Marlowe is a
        poet, Jonson is also. And, if Jonson's comedy is a comedy
        of humours, then Marlowe's tragedy, a large part of it,
        is a tragedy of humours. But Jonson has too exclusively
        been considered as the typical representative of a point
        of view toward comedy. He has suffered from his great
        reputation as a critic and theorist, from the effects of
        his intelligence. We have been taught to think of him as
        the man, the dictator (confusedly in our minds with his
        later namesake), as the literary politician impressing
        his views upon a generation; we are offended by the
        constant reminder of his scholarship. We forget the
        comedy in the humours, and the serious artist in the
        scholar. Jonson has suffered in public opinion, as anyone
        must suffer who is forced to talk about his art.</p>
<p>If you examine the first hundred lines or more of <i>Volpone</i>
        the verse appears to be in the manner of Marlowe, more
        deliberate, more mature, but without Marlowe's
        inspiration. It looks like mere "rhetoric,"
        certainly not "deeds and language such as men do
        use"! It appears to us, in fact, forced and
        flagitious bombast. That it is not "rhetoric,"
        or at least not vicious rhetoric, we do not know until we
        are able to review the whole play. For the consistent
        maintenance of this manner conveys in the end an effect
        not of verbosity, but of bold, even shocking and
        terrifying directness. We have difficulty in saying
        exactly what produces this simple and single effect. It
        is not in any ordinary way due to management of intrigue.
        Jonson employs immense dramatic constructive skill: it is
        not so much skill in plot as skill in doing without a
        plot. He never manipulates as complicated a plot as that
        of <i>The Merchant of Venice;</i> he has in his best
        plays nothing like the intrigue of Restoration comedy. In
        <i>Bartholomew Fair</i> it is hardly a plot at all; the
        marvel of the play is the bewildering rapid chaotic
        action of the fair; it is the fair itself, not anything
        that happens to take place in the fair. In <i>Volpone,</i>
        or <i>The Alchemist,</i> or <i>The Silent Woman,</i> the
        plot is enough to keep the players in motion; it is
        rather an "action" than a plot. The plot does
        not hold the play together; what holds the play together
        is a unity of inspiration that radiates into plot and
        personages alike.</p>
<p>We have attempted to make more precise the sense in
        which it was said that Jonson's work is "of the
        surface"; carefully avoiding the word
        "superficial." For there is work contemporary
        with Jonson's which is superficial in a pejorative sense
        in which the word cannot be applied to Jonson—the
        work of Beaumont and Fletcher. If we look at the work of
        Jonson's great contemporaries, Shakespeare, and also
        Donne and Webster and Tourneur (and sometimes Middleton),
        have a depth, a third dimension, as Mr. Gregory Smith
        rightly calls it, which Jonson's work has not. Their
        words have often a network of tentacular roots reaching
        down to the deepest terrors and desires. Jonson's most
        certainly have not; but in Beaumont and Fletcher we may
        think that at times we find it. Looking closer, we
        discover that the blossoms of Beaumont and Fletcher's
        imagination draw no sustenance from the soil, but are cut
        and slightly withered flowers stuck into sand. </p>
<blockquote>
<p>Wilt thou, hereafter, when they talk of me, <br/>
            As thou shalt hear nothing but infamy, <br/>
            Remember some of these things?... <br/>
            I pray thee, do; for thou shalt never see me so
            again. </p>
<p>Hair woven in many a curious warp, <br/>
            Able in endless error to enfold <br/>
            The wandering soul;...</p>
</blockquote>
<p>Detached from its context, this looks like the verse
        of the greater poets; just as lines of Jonson, detached
        from their context, look like inflated or empty fustian.
        But the evocative quality of the verse of Beaumont and
        Fletcher depends upon a clever appeal to emotions and
        associations which they have not themselves grasped; it
        is hollow. It is superficial with a vacuum behind it; the
        superficies of Jonson is solid. It is what it is; it does
        not pretend to be another thing. But it is so very
        conscious and deliberate that we must look with eyes
        alert to the whole before we apprehend the significance
        of any part. We cannot call a man's work superficial when
        it is the creation of a world; a man cannot be accused of
        dealing superficially with the world which he himself has
        created; the superficies <i>is</i> the world. Jonson's
        characters conform to the logic of the emotions of their
        world. It is a world like Lobatchevsky's; the worlds
        created by artists like Jonson are like systems of
        non-Euclidean geometry. They are not fancy, because they
        have a logic of their own; and this logic illuminates the
        actual world, because it gives us a new point of view
        from which to inspect it.</p>
<p>A writer of power and intelligence, Jonson endeavoured
        to promulgate, as a formula and programme of reform, what
        he chose to do himself; and he not unnaturally laid down
        in abstract theory what is in reality a personal point of
        view. And it is in the end of no value to discuss
        Jonson's theory and practice unless we recognize and
        seize this point of view, which escapes the formulæ, and
        which is what makes his plays worth reading. Jonson
        behaved as the great creative mind that he was: he
        created his own world, a world from which his followers,
        as well as the dramatists who were trying to do something
        wholly different, are excluded. Remembering this, we turn
        to Mr. Gregory Smith's objection—that Jonson's
        characters lack the third dimension, have no life out of
        the theatrical existence in which they appear—and
        demand an inquest. The objection implies that the
        characters are purely the work of intellect, or the
        result of superficial observation of a world which is
        faded or mildewed. It implies that the characters are
        lifeless. But if we dig beneath the theory, beneath the
        observation, beneath the deliberate drawing and the
        theatrical and dramatic elaboration, there is discovered
        a kind of power, animating Volpone, Busy, Fitzdottrel,
        the literary ladies of <i>Epicoene,</i> even Bobadil,
        which comes from below the intellect, and for which no
        theory of humours will account. And it is the same kind
        of power which vivifies Trimalchio, and Panurge, and some
        but not all of the "comic" characters of
        Dickens. The fictive life of this kind is not to be
        circumscribed by a reference to "comedy" or to
        "farce"; it is not exactly the kind of life
        which informs the characters of Molière or that which
        informs those of Marivaux—two writers who were,
        besides, doing something quite different the one from the
        other. But it is something which distinguishes Barabas
        from Shylock, Epicure Mammon from Falstaff, Faustus
        from—if you will—Macbeth; Marlowe and Jonson
        from Shakespeare and the Shakespearians, Webster, and
        Tourneur. It is not merely Humours: for neither Volpone
        nor Mosca is a humour. No theory of humours could account
        for Jonson's best plays or the best characters in them.
        We want to know at what point the comedy of humours
        passes into a work of art, and why Jonson is not Brome.</p>
<p>The creation of a work of art, we will say the
        creation of a character in a drama, consists in the
        process of transfusion of the personality, or, in a
        deeper sense, the life, of the author into the character.
        This is a very different matter from the orthodox
        creation in one's own image. The ways in which the
        passions and desires of the creator may be satisfied in
        the work of art are complex and devious. In a painter
        they may take the form of a predilection for certain
        colours, tones, or lightings; in a writer the original
        impulse may be even more strangely transmuted. Now, we
        may say with Mr. Gregory Smith that Falstaff or a score
        of Shakespeare's characters have a "third
        dimension" that Jonson's have not. This will mean,
        not that Shakespeare's spring from the feelings or
        imagination and Jonson's from the intellect or invention;
        they have equally an emotional source; but that
        Shakespeare's represent a more complex tissue of feelings
        and desires, as well as a more supple, a more susceptible
        temperament. Falstaff is not only the roast Malmesbury ox
        with the pudding in his belly; he also "grows
        old," and, finally, his nose is as sharp as a pen.
        He was perhaps the <i>satisfaction</i> of more, and of
        more complicated feelings; and perhaps he was, as the
        great tragic characters must have been, the offspring of
        deeper, less apprehensible feelings: deeper, but not
        necessarily stronger or more intense, than those of
        Jonson. It is obvious that the spring of the difference
        is not the difference between feeling and thought, or
        superior insight, superior perception, on the part of
        Shakespeare, but his susceptibility to a greater range of
        emotion, and emotion deeper and more obscure. But his
        characters are no more "alive" than are the
        characters of Jonson.</p>
<p>The world they live in is a larger one. But small
        worlds—the worlds which artists create—do not
        differ only in magnitude; if they are complete worlds,
        drawn to scale in every part, they differ in kind also.
        And Jonson's world has this scale. His type of
        personality found its relief in something falling under
        the category of burlesque or farce—though when you
        are dealing with a <i>unique</i> world, like his, these
        terms fail to appease the desire for definition. It is
        not, at all events, the farce of Molière: the latter is
        more analytic, more an intellectual redistribution. It is
        not defined by the word "satire." Jonson poses
        as a satirist. But satire like Jonson's is great in the
        end not by hitting off its object, but by creating it;
        the satire is merely the means which leads to the
        æsthetic result, the impulse which projects a new world
        into a new orbit. In <i>Every Man in his Humour</i> there
        is a neat, a very neat, comedy of humours. In discovering
        and proclaiming in this play the new genre Jonson was
        simply recognizing, unconsciously, the route which opened
        out in the proper direction for his instincts. His
        characters are and remain, like Marlowe's, simplified
        characters; but the simplification does not consist in
        the dominance of a particular humour or monomania. That
        is a very superficial account of it. The simplification
        consists largely in reduction of detail, in the seizing
        of aspects relevant to the relief of an emotional impulse
        which remains the same for that character, in making the
        character conform to a particular setting. This stripping
        is essential to the art, to which is also essential a
        flat distortion in the drawing; it is an art of
        caricature, of great caricature, like Marlowe's. It is a
        great caricature, which is beautiful; and a great humour,
        which is serious. The "world" of Jonson is
        sufficiently large; it is a world of poetic imagination;
        it is sombre. He did not get the third dimension, but he
        was not trying to get it.</p>
<p>If we approach Jonson with less frozen awe of his
        learning, with a clearer understanding of his
        "rhetoric" and its applications, if we grasp
        the fact that the knowledge required of the reader is not
        archæology but knowledge of Jonson, we can derive not
        only instruction in non-Euclidean humanity—but
        enjoyment. We can even apply him, be aware of him as a
        part of our literary inheritance craving further
        expression. Of all the dramatists of his time, Jonson is
        probably the one whom the present age would find the most
        sympathetic, if it knew him. There is a brutality, a lack
        of sentiment, a polished surface, a handling of large
        bold designs in brilliant colours, which ought to attract
        about three thousand people in London and elsewhere. At
        least, if we had a contemporary Shakespeare and a
        contemporary Jonson, it would be the Jonson who would
        arouse the enthusiasm of the intelligentsia! Though he is
        saturated in literature, he never sacrifices the
        theatrical qualities—theatrical in the most
        favourable sense—to literature or to the study of
        character. His work is a titanic show. But Jonson's
        masques, an important part of his work, are neglected;
        our flaccid culture lets shows and literature fade, but
        prefers faded literature to faded shows. There are
        hundreds of people who have read <i>Comus</i> to ten who
        have read the <i>Masque of Blackness. Comus</i> contains
        fine poetry, and poetry exemplifying some merits to which
        Jonson's masque poetry cannot pretend. Nevertheless, <i>Comus</i>
        is the death of the masque; it is the transition of a
        form of art—even of a form which existed for but a
        short generation—into "literature,"
        literature cast in a form which has lost its application.
        Even though <i>Comus</i> was a masque at Ludlow Castle,
        Jonson had, what Milton came perhaps too late to have, a
        sense for living art; his art was applied. The masques
        can still be read, and with pleasure, by anyone who will
        take the trouble—a trouble which in this part of
        Jonson is, indeed, a study of antiquities—to imagine
        them in action, displayed with the music, costumes,
        dances, and the scenery of Inigo Jones. They are
        additional evidence that Jonson had a fine sense of form,
        of the purpose for which a particular form is intended;
        evidence that he was a literary artist even more than he
        was a man of letters.</p>
</td>
</tr>
</table>
</center></div>
`,s=`Ben Jonson T HE reputation of Jonson has been of the most deadly kind that can be compelled upon the memory of a great poet. To be universally accepted; to be damned by the praise that quenches all desire to read the book; to be afflicted by the imputation of the virtues which excite the least pleasure; and to be read only by historians and antiquaries—this is the most perfect conspiracy of approval. For some generations the reputation of Jonson has been carried rather as a liability than as an asset in the balance-sheet of English literature. No critic has succeeded in making him appear pleasurable or even interesting. Swinburne's book on Jonson satisfies no curiosity and stimulates no thought. For the critical study in the "Men of Letters Series" by Mr. Gregory Smith there is a place; it satisfies curiosity, it supplies many just observations, it provides valuable matter on the neglected masques; it only fails to remodel the image of Jonson which is settled in our minds. Probably the fault lies with several generations of our poets. It is not that the value of poetry is only its value to living poets for their own work; but appreciation is akin to creation, and true enjoyment of poetry is related to the stirring of suggestion, the stimulus that a poet feels in his enjoyment of other poetry. Jonson has provided no creative stimulus for a very long time; consequently we must look back as far as Dryden—precisely, a poetic practitioner who learned from Jonson—before we find a living criticism of Jonson's work. Yet there are possibilities for Jonson even now. We have no difficulty in seeing what brought him to this pass; how, in contrast, not with Shakespeare, but with Marlowe, Webster, Donne, Beaumont, and Fletcher, he has been paid out with reputation instead of enjoyment. He is no less a poet than these men, but his poetry is of the surface. Poetry of the surface cannot be understood without study; for to deal with the surface of life, as Jonson dealt with it, is to deal so deliberately that we too must be deliberate, in order to understand. Shakespeare, and smaller men also, are in the end more difficult, but they offer something at the start to encourage the student or to satisfy those who want nothing more; they are suggestive, evocative, a phrase, a voice; they offer poetry in detail as well as in design. So does Dante offer something, a phrase everywhere ( tu se' ombra ed ombra vedi ) even to readers who have no Italian; and Dante and Shakespeare have poetry of design as well as of detail. But the polished veneer of Jonson reflects only the lazy reader's fatuity; unconscious does not respond to unconscious; no swarms of inarticulate feelings are aroused. The immediate appeal of Jonson is to the mind; his emotional tone is not in the single verse, but in the design of the whole. But not many people are capable of discovering for themselves the beauty which is only found after labour; and Jonson's industrious readers have been those whose interest was historical and curious, and those who have thought that in discovering the historical and curious interest they had discovered the artistic value as well. When we say that Jonson requires study, we do not mean study of his classical scholarship or of seventeenth-century manners. We mean intelligent saturation in his work as a whole; we mean that in order to enjoy him at all, we must get to the centre of his work and his temperament, and that we must see him unbiased by time, as a contemporary. And to see him as a contemporary does not so much require the power of putting ourselves into seventeenth-century London as it requires the power of setting Jonson in our London: a more difficult triumph of divination. It is generally conceded that Jonson failed as a tragic dramatist; and it is usually agreed that he failed because his genius was for satiric comedy and because of the weight of pedantic learning with which he burdened his two tragic failures. The second point marks an obvious error of detail; the first is too crude a statement to be accepted; to say that he failed because his genius was unsuited to tragedy is to tell us nothing at all. Jonson did not write a good tragedy, but we can see no reason why he should not have written one. If two plays so different as The Tempest and The Silent Woman are both comedies, surely the category of tragedy could be made wide enough to include something possible for Jonson to have done. But the classification of tragedy and comedy, while it may be sufficient to mark the distinction in a dramatic literature of more rigid form and treatment—it may distinguish Aristophanes from Euripides—is not adequate to a drama of such variations as the Elizabethans. Tragedy is a crude classification for plays so different in their tone as Macbeth, The Jew of Malta, and The Witch of Edmonton; and it does not help us much to say that The Merchant of Venice and The Alchemist are comedies. Jonson had his own scale, his own instrument. The merit which Catiline possesses is the same merit that is exhibited more triumphantly in Volpone; Catiline fails, not because it is too laboured and conscious, but because it is not conscious enough; because Jonson in this play was not alert to his own idiom, not clear in his mind as to what his temperament wanted him to do. In Catiline Jonson conforms, or attempts to conform, to conventions; not to the conventions of antiquity, which he had exquisitely under control, but to the conventions of tragico-historical drama of his time. It is not the Latin erudition that sinks Catiline, but the application of that erudition to a form which was not the proper vehicle for the mind which had amassed the erudition. If you look at Catiline —that dreary Pyrrhic victory of tragedy—you find two passages to be successful: Act ii. scene I, the dialogue of the political ladies, and the Prologue of Sylla's ghost. These two passages are genial. The soliloquy of the ghost is a characteristic Jonson success in content and in versification— Dost thou not feel me, Rome? not yet! is night So heavy on thee, and my weight so light? Can Sylla's ghost arise within thy walls, Less threatening than an earthquake, the quick falls Of thee and thine? Shake not the frighted heads Of thy steep towers, or shrink to their first beds? Or as their ruin the large Tyber fills, Make that swell up, and drown thy seven proud hills?... This is the learned, but also the creative, Jonson. Without concerning himself with the character of Sulla, and in lines of invective, Jonson makes Sylla's ghost, while the words are spoken, a living and terrible force. The words fall with as determined beat as if they were the will of the morose Dictator himself. You may say: merely invective; but mere invective, even if as superior to the clumsy fisticuffs of Marston and Hall as Jonson's verse is superior to theirs, would not create a living figure as Jonson has done in this long tirade. And you may say; rhetoric; but if we are to call it "rhetoric" we must subject that term to a closer dissection than any to which it is accustomed. What Jonson has done here is not merely a fine speech. It is the careful, precise filling in of a strong and simple outline, and at no point does it overflow the outline; it is far more careful and precise in its obedience to this outline than are many of the speeches in Tamburlaine. The outline is not Sulla, for Sulla has nothing to do with it, but "Sylla's ghost." The words may not be suitable to an historical Sulla, or to anybody in history, but they are a perfect expression for "Sylla's ghost." You cannot say they are rhetorical "because people do not talk like that," you cannot call them "verbiage"; they do not exhibit prolixity or redundancy or the other vices in the rhetoric books; there is a definite artistic emotion which demands expression at that length. The words themselves are mostly simple words, the syntax is natural, the language austere rather than adorned. Turning then to the induction of The Poetaster, we find another success of the same kind— Light, I salute thee, but with wounded nerves... Men may not talk in that way, but the spirit of envy does, and in the words of Jonson envy is a real and living person. It is not human life that informs envy and Sylla's ghost, but it is energy of which human life is only another variety. Returning to Catiline, we find that the best scene in the body of the play is one which cannot be squeezed into a tragic frame, and which appears to belong to satiric comedy. The scene between Fulvia and Galla and Sempronia is a living scene in a wilderness of oratory. And as it recalls other scenes—there is a suggestion of the college of ladies in The Silent Woman —it looks like a comedy scene. And it appears to be satire. They shall all give and pay well, that come here, If they will have it; and that, jewels, pearl, Plate, or round sums to buy these. I'm not taken With a cob-swan or a high-mounting bull, As foolish Leda and Europa were; But the bright gold, with Danaë. For such price I would endure a rough, harsh Jupiter, Or ten such thundering gamesters, and refrain To laugh at 'em, till they are gone, with my much suffering. This scene is no more comedy than it is tragedy, and the "satire" is merely a medium for the essential emotion. Jonson's drama is only incidentally satire, because it is only incidentally a criticism upon the actual world. It is not satire in the way in which the work of Swift or the work of Molière may be called satire: that is, it does not find its source in any precise emotional attitude or precise intellectual criticism of the actual world. It is satire perhaps as the work of Rabelais is satire; certainly not more so. The important thing is that if fiction can be divided into creative fiction and critical fiction, Jonson's is creative. That he was a great critic, our first great critic, does not affect this assertion. Every creator is also a critic; Jonson was a conscious critic, but he was also conscious in his creations. Certainly, one sense in which the term "critical" may be applied to fiction is a sense in which the term might be used of a method antithetical to Jonson's. It is the method of Education Sentimentale. The characters of Jonson, of Shakespeare, perhaps of all the greatest drama, are drawn in positive and simple outlines. They may be filled in, and by Shakespeare they are filled in, by much detail or many shifting aspects; but a clear and sharp and simple form remains through these—though it would be hard to say in what the clarity and sharpness and simplicity of Hamlet consists. But Frédéric Moreau is not made in that way. He is constructed partly by negative definition, built up by a great number of observations. We cannot isolate him from the environment in which we find him; it may be an environment which is or can be much universalized; nevertheless it, and the figure in it, consist of very many observed particular facts, the actual world. Without this world the figure dissolves. The ruling faculty is a critical perception, a commentary upon experienced feeling and sensation. If this is true of Flaubert, it is true in a higher degree of Molière than of Jonson. The broad farcical lines of Molière may seem to be the same drawing as Jonson's. But Molière—say in Alceste or Monsieur Jourdain—is criticizing the actual; the reference to the actual world is more direct. And having a more tenuous reference, the work of Jonson is much less directly satirical. This leads us to the question of Humours. Largely on the evidence of the two Humour plays, it is sometimes assumed that Jonson is occupied with types; typical exaggerations, or exaggerations of type. The Humour definition, the expressed intention of Jonson, may be satisfactory for these two plays. Every Man in his Humour is the first mature work of Jonson, and the student of Jonson must study it; but it is not the play in which Jonson found his genius: it is the last of his plays to read first. If one reads Volpone, and after that re-reads the Jew of Malta; then returns to Jonson and reads Bartholomew Fair, The Alchemist, Epicoene and The Devil is an Ass, and finally Catiline, it is possible to arrive at a fair opinion of the poet and the dramatist. The Humour, even at the beginning, is not a type, as in Marston's satire, but a simplified and somewhat distorted individual with a typical mania. In the later work, the Humour definition quite fails to account for the total effect produced. The characters of Shakespeare are such as might exist in different circumstances than those in which Shakespeare sets them. The latter appear to be those which extract from the characters the most intense and interesting realization; but that realization has not exhausted their possibilities. Volpone's life, on the other hand, is bounded by the scene in which it is played; in fact, the life is the life of the scene and is derivatively the life of Volpone; the life of the character is inseparable from the life of the drama. This is not dependence upon a background, or upon a substratum of fact. The emotional effect is single and simple. Whereas in Shakespeare the effect is due to the way in which the characters act upon one another, in Jonson it is given by the way in which the characters fit in with each other. The artistic result of Volpone is not due to any effect that Volpone, Mosca, Corvino, Corbaccio, Voltore have upon each other, but simply to their combination into a whole. And these figures are not personifications of passions; separately, they have not even that reality, they are constituents. It is a similar indication of Jonson's method that you can hardly pick out a line of Jonson's and say confidently that it is great poetry; but there are many extended passages to which you cannot deny that honour. I will have all my beds blown up, not stuft; Down is too hard; and then, mine oval room Fill'd with such pictures as Tiberius took From Elephantis, and dull Aretine But coldly imitated. Then, my glasses Cut in more subtle angles, to disperse And multiply the figures, as I walk.... Jonson is the legitimate heir of Marlowe. The man who wrote, in Volpone: for thy love, In varying figures, I would have contended With the blue Proteus, or the hornèd flood.... and See, a carbuncle May put out both the eyes of our Saint Mark; A diamond would have bought Lollia Paulina, When she came in like star-light, hid with jewels.... is related to Marlowe as a poet; and if Marlowe is a poet, Jonson is also. And, if Jonson's comedy is a comedy of humours, then Marlowe's tragedy, a large part of it, is a tragedy of humours. But Jonson has too exclusively been considered as the typical representative of a point of view toward comedy. He has suffered from his great reputation as a critic and theorist, from the effects of his intelligence. We have been taught to think of him as the man, the dictator (confusedly in our minds with his later namesake), as the literary politician impressing his views upon a generation; we are offended by the constant reminder of his scholarship. We forget the comedy in the humours, and the serious artist in the scholar. Jonson has suffered in public opinion, as anyone must suffer who is forced to talk about his art. If you examine the first hundred lines or more of Volpone the verse appears to be in the manner of Marlowe, more deliberate, more mature, but without Marlowe's inspiration. It looks like mere "rhetoric," certainly not "deeds and language such as men do use"! It appears to us, in fact, forced and flagitious bombast. That it is not "rhetoric," or at least not vicious rhetoric, we do not know until we are able to review the whole play. For the consistent maintenance of this manner conveys in the end an effect not of verbosity, but of bold, even shocking and terrifying directness. We have difficulty in saying exactly what produces this simple and single effect. It is not in any ordinary way due to management of intrigue. Jonson employs immense dramatic constructive skill: it is not so much skill in plot as skill in doing without a plot. He never manipulates as complicated a plot as that of The Merchant of Venice; he has in his best plays nothing like the intrigue of Restoration comedy. In Bartholomew Fair it is hardly a plot at all; the marvel of the play is the bewildering rapid chaotic action of the fair; it is the fair itself, not anything that happens to take place in the fair. In Volpone, or The Alchemist, or The Silent Woman, the plot is enough to keep the players in motion; it is rather an "action" than a plot. The plot does not hold the play together; what holds the play together is a unity of inspiration that radiates into plot and personages alike. We have attempted to make more precise the sense in which it was said that Jonson's work is "of the surface"; carefully avoiding the word "superficial." For there is work contemporary with Jonson's which is superficial in a pejorative sense in which the word cannot be applied to Jonson—the work of Beaumont and Fletcher. If we look at the work of Jonson's great contemporaries, Shakespeare, and also Donne and Webster and Tourneur (and sometimes Middleton), have a depth, a third dimension, as Mr. Gregory Smith rightly calls it, which Jonson's work has not. Their words have often a network of tentacular roots reaching down to the deepest terrors and desires. Jonson's most certainly have not; but in Beaumont and Fletcher we may think that at times we find it. Looking closer, we discover that the blossoms of Beaumont and Fletcher's imagination draw no sustenance from the soil, but are cut and slightly withered flowers stuck into sand. Wilt thou, hereafter, when they talk of me, As thou shalt hear nothing but infamy, Remember some of these things?... I pray thee, do; for thou shalt never see me so again. Hair woven in many a curious warp, Able in endless error to enfold The wandering soul;... Detached from its context, this looks like the verse of the greater poets; just as lines of Jonson, detached from their context, look like inflated or empty fustian. But the evocative quality of the verse of Beaumont and Fletcher depends upon a clever appeal to emotions and associations which they have not themselves grasped; it is hollow. It is superficial with a vacuum behind it; the superficies of Jonson is solid. It is what it is; it does not pretend to be another thing. But it is so very conscious and deliberate that we must look with eyes alert to the whole before we apprehend the significance of any part. We cannot call a man's work superficial when it is the creation of a world; a man cannot be accused of dealing superficially with the world which he himself has created; the superficies is the world. Jonson's characters conform to the logic of the emotions of their world. It is a world like Lobatchevsky's; the worlds created by artists like Jonson are like systems of non-Euclidean geometry. They are not fancy, because they have a logic of their own; and this logic illuminates the actual world, because it gives us a new point of view from which to inspect it. A writer of power and intelligence, Jonson endeavoured to promulgate, as a formula and programme of reform, what he chose to do himself; and he not unnaturally laid down in abstract theory what is in reality a personal point of view. And it is in the end of no value to discuss Jonson's theory and practice unless we recognize and seize this point of view, which escapes the formulæ, and which is what makes his plays worth reading. Jonson behaved as the great creative mind that he was: he created his own world, a world from which his followers, as well as the dramatists who were trying to do something wholly different, are excluded. Remembering this, we turn to Mr. Gregory Smith's objection—that Jonson's characters lack the third dimension, have no life out of the theatrical existence in which they appear—and demand an inquest. The objection implies that the characters are purely the work of intellect, or the result of superficial observation of a world which is faded or mildewed. It implies that the characters are lifeless. But if we dig beneath the theory, beneath the observation, beneath the deliberate drawing and the theatrical and dramatic elaboration, there is discovered a kind of power, animating Volpone, Busy, Fitzdottrel, the literary ladies of Epicoene, even Bobadil, which comes from below the intellect, and for which no theory of humours will account. And it is the same kind of power which vivifies Trimalchio, and Panurge, and some but not all of the "comic" characters of Dickens. The fictive life of this kind is not to be circumscribed by a reference to "comedy" or to "farce"; it is not exactly the kind of life which informs the characters of Molière or that which informs those of Marivaux—two writers who were, besides, doing something quite different the one from the other. But it is something which distinguishes Barabas from Shylock, Epicure Mammon from Falstaff, Faustus from—if you will—Macbeth; Marlowe and Jonson from Shakespeare and the Shakespearians, Webster, and Tourneur. It is not merely Humours: for neither Volpone nor Mosca is a humour. No theory of humours could account for Jonson's best plays or the best characters in them. We want to know at what point the comedy of humours passes into a work of art, and why Jonson is not Brome. The creation of a work of art, we will say the creation of a character in a drama, consists in the process of transfusion of the personality, or, in a deeper sense, the life, of the author into the character. This is a very different matter from the orthodox creation in one's own image. The ways in which the passions and desires of the creator may be satisfied in the work of art are complex and devious. In a painter they may take the form of a predilection for certain colours, tones, or lightings; in a writer the original impulse may be even more strangely transmuted. Now, we may say with Mr. Gregory Smith that Falstaff or a score of Shakespeare's characters have a "third dimension" that Jonson's have not. This will mean, not that Shakespeare's spring from the feelings or imagination and Jonson's from the intellect or invention; they have equally an emotional source; but that Shakespeare's represent a more complex tissue of feelings and desires, as well as a more supple, a more susceptible temperament. Falstaff is not only the roast Malmesbury ox with the pudding in his belly; he also "grows old," and, finally, his nose is as sharp as a pen. He was perhaps the satisfaction of more, and of more complicated feelings; and perhaps he was, as the great tragic characters must have been, the offspring of deeper, less apprehensible feelings: deeper, but not necessarily stronger or more intense, than those of Jonson. It is obvious that the spring of the difference is not the difference between feeling and thought, or superior insight, superior perception, on the part of Shakespeare, but his susceptibility to a greater range of emotion, and emotion deeper and more obscure. But his characters are no more "alive" than are the characters of Jonson. The world they live in is a larger one. But small worlds—the worlds which artists create—do not differ only in magnitude; if they are complete worlds, drawn to scale in every part, they differ in kind also. And Jonson's world has this scale. His type of personality found its relief in something falling under the category of burlesque or farce—though when you are dealing with a unique world, like his, these terms fail to appease the desire for definition. It is not, at all events, the farce of Molière: the latter is more analytic, more an intellectual redistribution. It is not defined by the word "satire." Jonson poses as a satirist. But satire like Jonson's is great in the end not by hitting off its object, but by creating it; the satire is merely the means which leads to the æsthetic result, the impulse which projects a new world into a new orbit. In Every Man in his Humour there is a neat, a very neat, comedy of humours. In discovering and proclaiming in this play the new genre Jonson was simply recognizing, unconsciously, the route which opened out in the proper direction for his instincts. His characters are and remain, like Marlowe's, simplified characters; but the simplification does not consist in the dominance of a particular humour or monomania. That is a very superficial account of it. The simplification consists largely in reduction of detail, in the seizing of aspects relevant to the relief of an emotional impulse which remains the same for that character, in making the character conform to a particular setting. This stripping is essential to the art, to which is also essential a flat distortion in the drawing; it is an art of caricature, of great caricature, like Marlowe's. It is a great caricature, which is beautiful; and a great humour, which is serious. The "world" of Jonson is sufficiently large; it is a world of poetic imagination; it is sombre. He did not get the third dimension, but he was not trying to get it. If we approach Jonson with less frozen awe of his learning, with a clearer understanding of his "rhetoric" and its applications, if we grasp the fact that the knowledge required of the reader is not archæology but knowledge of Jonson, we can derive not only instruction in non-Euclidean humanity—but enjoyment. We can even apply him, be aware of him as a part of our literary inheritance craving further expression. Of all the dramatists of his time, Jonson is probably the one whom the present age would find the most sympathetic, if it knew him. There is a brutality, a lack of sentiment, a polished surface, a handling of large bold designs in brilliant colours, which ought to attract about three thousand people in London and elsewhere. At least, if we had a contemporary Shakespeare and a contemporary Jonson, it would be the Jonson who would arouse the enthusiasm of the intelligentsia! Though he is saturated in literature, he never sacrifices the theatrical qualities—theatrical in the most favourable sense—to literature or to the study of character. His work is a titanic show. But Jonson's masques, an important part of his work, are neglected; our flaccid culture lets shows and literature fade, but prefers faded literature to faded shows. There are hundreds of people who have read Comus to ten who have read the Masque of Blackness. Comus contains fine poetry, and poetry exemplifying some merits to which Jonson's masque poetry cannot pretend. Nevertheless, Comus is the death of the masque; it is the transition of a form of art—even of a form which existed for but a short generation—into "literature," literature cast in a form which has lost its application. Even though Comus was a masque at Ludlow Castle, Jonson had, what Milton came perhaps too late to have, a sense for living art; his art was applied. The masques can still be read, and with pleasure, by anyone who will take the trouble—a trouble which in this part of Jonson is, indeed, a study of antiquities—to imagine them in action, displayed with the music, costumes, dances, and the scenery of Inigo Jones. They are additional evidence that Jonson had a fine sense of form, of the purpose for which a particular form is intended; evidence that he was a literary artist even more than he was a man of letters.`,c=[],l=[],u={edition:`preserved`,sourceFile:`Essays/swjohnson.htm`},d=[`thesacredwood`],f={id:e,slug:t,type:n,title:r,sourceFile:i,encoding:a,html:o,text:s,links:c,images:l,provenance:u,backlinks:d};export{d as backlinks,f as default,a as encoding,o as html,e as id,l as images,c as links,u as provenance,t as slug,i as sourceFile,s as text,r as title,n as type};