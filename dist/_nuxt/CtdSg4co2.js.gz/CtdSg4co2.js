var e=`burbank-notes-istria-h`,t=`istria-h`,n=`source-page`,r=`History of Herodotus`,i=`Burbank_notes/Istria_H.htm`,a=`windows-1252`,o=`
<p><font><strong>History of Herodotus </strong></font></p>
<p>Herodotus</p>
<div><center>
<table>
<tr>
<td><em>from </em>Second Book<em>, par
        45-7</em>:<p><em>In this section, Herod discusses the
        Nile and speculates about its length and origin, and then
        continues to relate how Etearchus mistook the river Ister
        for the Nile once.</em></p>
</td>
</tr>
</table>
</center></div><div><center>
<table>
<tr>
<td>I did hear, indeed, what I will now relate, from
        certain natives of Cyrene. Once upon a time, they said,
        they were on a visit to the oracular shrine of Ammon,
        when it chanced that in the course of conversation with
        Etearchus, the Ammonian king, the talk fell upon the
        Nile, how that its sources were unknown to all men.
        Etearchus upon this mentioned that some Nasamonians had
        once come to his court, and when asked if they could give
        any information concerning the uninhabited parts of
        Libya, had told the following tale. (The Nasamonians are
        a Libyan race who occupy the Syrtis, and a tract of no
        great size towards the east.) They said there had grown
        up among them some wild young men, the sons of certain
        chiefs, who, when they came to man's estate, indulged in
        all manner of extravagancies, and among other things drew
        lots for five of their number to go and explore the
        desert parts of Libya, and try if they could not
        penetrate further than any had done previously. The coast
        of Libya along the sea which washes it to the north,
        throughout its entire length from Egypt to Cape Soloeis,
        which is its furthest point, is inhabited by Libyans of
        many distinct tribes who possess the whole tract except
        certain portions which belong to the Phoenicians and the
        Greeks. Above the coast-line and the country inhabited by
        the maritime tribes, Libya is full of wild beasts; while
        beyond the wild beast region there is a tract which is
        wholly sand, very scant of water, and utterly and
        entirely a desert. The young men therefore, despatched on
        this errand by their comrades with a plentiful supply of
        water and provisions, travelled at first through the
        inhabited region, passing which they came to the wild
        beast tract, whence they finally entered upon the desert,
        which they proceeded to cross in a direction from east to
        west. After journeying for many days over a wide extent
        of sand, they came at last to a plain where they observed
        trees growing; approaching them, and seeing fruit on
        them, they proceeded to gather it. While they were thus
        engaged, there came upon them some dwarfish men, under
        the middle height, who seized them and carried them off.
        The Nasamonians could not understand a word of their
        language, nor had they any acquaintance with the language
        of the Nasamonians. They were led across extensive
        marshes, and finally came to a town, where all the men
        were of the height of their conductors, and
        black-complexioned. A great river flowed by the town,
        running from west to east, and containing crocodiles.<p>Here
        let me dismiss Etearchus the Ammonian, and his story,
        only adding that (according to the Cyrenaeans) he
        declared that the Nasamonians got safe back to their
        country, and that the men whose city they had reached
        were a nation of sorcerers. With respect to the river
        which ran by their town, Etearchus conjectured it to be
        the Nile; and reason favours that view. For the Nile
        certainly flows out of Libya, dividing it down the
        middle, and as I conceive, judging the unknown from the
        known, rises at the same distance from its mouth as the
        Ister. This latter river has its source in the country of
        the Celts near the city Pyrene, and runs through the
        middle of Europe, dividing it into two portions. The
        Celts live beyond the pillars of Hercules, and border on
        the Cynesians, who dwell at the extreme west of Europe.
        Thus the Ister flows through the whole of Europe before
        it finally empties itself into the Euxine at Istria, one
        of the colonies of the Milesians.</p>
<p>Now as this river flows through regions that are
        inhabited, its course is perfectly well known; but of the
        sources of the Nile no one can give any account, since
        Libya, the country through which it passes, is desert and
        without inhabitants. As far as it was possible to get
        information by inquiry, I have given a description of the
        stream. It enters Egypt from the parts beyond. Egypt lies
        almost exactly opposite the mountainous portion of
        Cilicia, whence a lightly-equipped traveller may reach
        Sinope on the Euxine in five days by the direct route.
        Sinope lies opposite the place where the Ister falls into
        the sea. My opinion therefore is that the Nile, as it
        traverses the whole of Libya, is of equal length with the
        Ister. And here I take my leave of this subject. </p>
</td>
</tr>
</table>
</center></div>
`,s=`History of Herodotus Herodotus from Second Book , par 45-7 : In this section, Herod discusses the Nile and speculates about its length and origin, and then continues to relate how Etearchus mistook the river Ister for the Nile once. I did hear, indeed, what I will now relate, from certain natives of Cyrene. Once upon a time, they said, they were on a visit to the oracular shrine of Ammon, when it chanced that in the course of conversation with Etearchus, the Ammonian king, the talk fell upon the Nile, how that its sources were unknown to all men. Etearchus upon this mentioned that some Nasamonians had once come to his court, and when asked if they could give any information concerning the uninhabited parts of Libya, had told the following tale. (The Nasamonians are a Libyan race who occupy the Syrtis, and a tract of no great size towards the east.) They said there had grown up among them some wild young men, the sons of certain chiefs, who, when they came to man's estate, indulged in all manner of extravagancies, and among other things drew lots for five of their number to go and explore the desert parts of Libya, and try if they could not penetrate further than any had done previously. The coast of Libya along the sea which washes it to the north, throughout its entire length from Egypt to Cape Soloeis, which is its furthest point, is inhabited by Libyans of many distinct tribes who possess the whole tract except certain portions which belong to the Phoenicians and the Greeks. Above the coast-line and the country inhabited by the maritime tribes, Libya is full of wild beasts; while beyond the wild beast region there is a tract which is wholly sand, very scant of water, and utterly and entirely a desert. The young men therefore, despatched on this errand by their comrades with a plentiful supply of water and provisions, travelled at first through the inhabited region, passing which they came to the wild beast tract, whence they finally entered upon the desert, which they proceeded to cross in a direction from east to west. After journeying for many days over a wide extent of sand, they came at last to a plain where they observed trees growing; approaching them, and seeing fruit on them, they proceeded to gather it. While they were thus engaged, there came upon them some dwarfish men, under the middle height, who seized them and carried them off. The Nasamonians could not understand a word of their language, nor had they any acquaintance with the language of the Nasamonians. They were led across extensive marshes, and finally came to a town, where all the men were of the height of their conductors, and black-complexioned. A great river flowed by the town, running from west to east, and containing crocodiles. Here let me dismiss Etearchus the Ammonian, and his story, only adding that (according to the Cyrenaeans) he declared that the Nasamonians got safe back to their country, and that the men whose city they had reached were a nation of sorcerers. With respect to the river which ran by their town, Etearchus conjectured it to be the Nile; and reason favours that view. For the Nile certainly flows out of Libya, dividing it down the middle, and as I conceive, judging the unknown from the known, rises at the same distance from its mouth as the Ister. This latter river has its source in the country of the Celts near the city Pyrene, and runs through the middle of Europe, dividing it into two portions. The Celts live beyond the pillars of Hercules, and border on the Cynesians, who dwell at the extreme west of Europe. Thus the Ister flows through the whole of Europe before it finally empties itself into the Euxine at Istria, one of the colonies of the Milesians. Now as this river flows through regions that are inhabited, its course is perfectly well known; but of the sources of the Nile no one can give any account, since Libya, the country through which it passes, is desert and without inhabitants. As far as it was possible to get information by inquiry, I have given a description of the stream. It enters Egypt from the parts beyond. Egypt lies almost exactly opposite the mountainous portion of Cilicia, whence a lightly-equipped traveller may reach Sinope on the Euxine in five days by the direct route. Sinope lies opposite the place where the Ister falls into the sea. My opinion therefore is that the Nile, as it traverses the whole of Libya, is of equal length with the Ister. And here I take my leave of this subject.`,c=[],l=[],u={edition:`preserved`,sourceFile:`Burbank_notes/Istria_H.htm`},d=[`burbank-notes-axletree-n`,`burbank-notes-beatup-n`,`burbank-notes-horses-n`,`burbank-notes-istria-n`],f={id:e,slug:t,type:n,title:r,sourceFile:i,encoding:a,html:o,text:s,links:c,images:l,provenance:u,backlinks:d};export{d as backlinks,f as default,a as encoding,o as html,e as id,l as images,c as links,u as provenance,t as slug,i as sourceFile,s as text,r as title,n as type};