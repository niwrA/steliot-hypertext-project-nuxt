var e=`eliot-books`,t=`eliot-books`,n=`bibliography`,r=`Books on T.S. Eliot and his Works`,i=`Eliot_Books.htm`,a=`windows-1252`,o=`
<div>
<table>
<tr>
<td><font><strong>Books on</strong></font><hr noshade=""/>
<p><em>"The vast accumulation of knowledge--or at least of
    information--deposited by the nineteenth century have been responsible for an equally vast
    ignorance."</em> - T.S. Eliot</p>
<p>Since the only possible way of preventing the same thing from happening in
    this century and the next is by a careful cataloguing of available knowledge, that is what
    this page sets out to do. If you wish to make any additions, please send a mail to <a href="mailto:A.vanArum@cable.a2000.nl">A.vanArum@cable.a2000.nl</a>, with as a subject title "Books on
    Eliot."</p>
<blockquote>
<p><em>Arwin van Arum</em></p>
</blockquote>
<p><font><a href="Books/IMG_Akroyd.htm"><img src="pic.gif"/></a><a href="Eliot_books.htm">Quick list of books by author<br/>
</a><a href="Books/IMG_Akroyd.htm"><img src="pic.gif"/></a> Quick list of books by title</font></p>
<p><a name="Akroyd"></a><font><strong>Akroyd</strong>, Peter.<br/>
<em>T.S. Eliot.</em><br/>
    Penguin Books. London, 1984</font></p>
<p><a href="Books/IMG_Akroyd.htm"><font><img src="pic.gif"/></font><font> Image of cover</font></a></p>
<p><font>Style: BIOGRAPHICAL</font></p>
<p><font>Akroyd's excellent biography is the current favourite, and
    justly so. Little fault can be found with this work, which achieves almost exactly what it
    sets out to do - to provide the reader with a detailed account of Eliot's life, and
    particularly those years in which Eliot produced his poetry. If there are any holes to be
    punched in this work, they are going to be in the psychological profile, which is a little
    shaky on certain points. </font></p>
<p><a name="Albright"></a><font><strong>Albright</strong>, Daniel.<br/>
<em>Quantum Poetics<br/>
</em>CUP. New York, 1997.</font></p>
<p><font><em>T.S. Eliot Annual No. 1. <br/>
</em>Edited by Shyamal <strong>Bagchee</strong>. <br/>
    Macmillan Press. London, 1990.</font></p>
<p><font>Style: COLLECTION</font></p>
<p><font>Contains interesting article on Eliot and Ulysses.</font></p>
<p><a name="Bergonzi"></a><font><strong>Bergonzi</strong>, Bernard. <br/>
<em>T.S. Eliot. <br/>
</em>The Macmillan Company. New York, 1972. </font></p>
<p><a name="Bush"></a><font><strong>Bush</strong>, Ronald. <br/>
<em>T.S. Eliot. A Study in Character and Style. <br/>
</em>Oxford UP. Oxford, 1983. </font></p>
<p><font><strong>Bush</strong>, Ronald. (Ed.)<br/>
<em>T.S. Eliot.<br/>
</em>Cambridge UP. New York, 1991.</font></p>
<p><a name="Childs"></a><font><strong>Childs</strong>, Donald J.<br/>
<em>T.S. Eliot: Mystic, Son and Lover </em><br/>
    Ethlone Press. London, 1997</font></p>
<p><font>Style: THEMATICAL/BIOGRAPHICAL</font></p>
<p><font>Childs brilliantly combines rigid critical thinking and
    detailed literary background with a detailed examination of the actual poetry. Special
    interest in this book is human relations. Childs is clearly a specialist in his field, is
    detailed and accurate - an example to many of the more 'loose' autobiographical critics
    featured on these pages.</font></p>
<p><a name="Crawford"></a><font><strong>Crawford</strong>, Robert. <br/>
<em>The Savage and the City in the work of T.S. Eliot. <br/>
</em>Clarendon Press. Oxford, 1987. </font></p>
<p><font>Style: THEMATICAL</font></p>
<p><font>Crawford has studied Eliot's study material and writings in
    great detail, which help him shed fresh light on otherwise repetetive discussions of the
    poems. This book does much more than many others and is recommended almost without
    reservation; the almost is due to a few obvious oversights and that Eliot's schoolwork,
    even in combination with Frazer, cannot explain everything.</font></p>
<p><a name="Gardner"></a><strong>Gardner</strong>, Helen.<br/>
<em>Composition of the Four Quartets</em></p>
<p>"It examines various drafts of FQ that were preserved, and
    reconstructs, through Eliot's correspondence (largely with one John Hayward), how many of
    the changes came to be made.\xA0 It also has good discussions of FQ not directly tied to
    the drafts.\xA0 I found it more enlightening re: Eliot's creative process and allusions
    than anything else I've read, including the WL manuscript." <br/>
    - <em>Tom Kissane. </em>on the T.S. Eliot list. </p>
<p><a name="Gish"></a><font><strong>Gish</strong>, Nancy. <br/>
<em>Time in the Poetry of T.S. Eliot. A Study of Structure and Theme.</em> <br/>
    MacMaillan Press. London, 1981.</font></p>
<p><font>A detailed and compact introduction to Eliot's poetry and
    although the title stresses time, Ms Gish's book is a good start for anyone interested in
    the poems. The work covers everything from <em>Prufrock </em>to <em>Four Quartets</em>. </font></p>
<p><a name="Graves"></a><font><strong>Graves</strong>, Robert and
    Riding, Laura. <br/>
<em>A Survey of Modernist Poetry<br/>
</em>Doubleday. New York, 1928.</font></p>
<p><font>Style: SURVEY</font></p>
<p><font>Important historical piece of literary criticism, and the
    first to treat the modernist movement as a historical movement rather than a contemporary
    one. The authors are both poets themselves.</font></p>
<p><a name="Jain"></a><font><strong>Jain</strong>, Manju. <br/>
<em>T.S. Eliot and American Philosophy. The Harvard Years. <br/>
</em>Cambridge UP. Cambridge, 1992</font></p>
<p><a name="Julius"></a><font><strong>Julius</strong>, Anthony. <br/>
<em>T.S. Eliot, anit-Semitism, and literary form.</em><br/>
    Cambridge UP. Cambridge, 1995</font></p>
<p><font>Style: THEMATICAL/BIOGRAPHICAL</font></p>
<p><font>Antony Julius' well-known book deals mainly with the issue
    of anti-semitism in T.S. Eliot's work. His approach is one of 'presumed guilty' and his
    method is of selecting as much evidence 'against' Eliot, which is fairly convincing,
    although doubt has been cast on his method and selection of evidence. The merit of this
    book lies mainly in the detailed and knowledgeable representation of the different forms
    of anti-Semitism that existed in Eliot's time. Like many other critics, Julius fails to
    pay sufficient attention to the works Eliot refers or alludes to.</font></p>
<p><a name="Lobb"></a><font><strong>Lobb</strong>, Edward.<br/>
<em>T.S. Eliot and the Romantic Critical Tradition.</em><br/>
    Routledge &amp; Kegan Paul. London, 1981.</font></p>
<p><font>For what the title proposes to do I believe that the
    Quillian book on Joyce and Eliot (<em>Hamlet and the New Poetic</em>) is a better
    introduction - it discusses in much more detail how Eliot fitted into a literary critical
    tradition, by offering the reader many influential extracts from the critics preceding and
    influencing Eliot. Lobb's book, however, is a good introductory discussion of the social
    and historical cultural context on a more general level (rather than that of Hamlet, for
    instance), and gives a detailed overview of practically <em>all </em>of Eliot's criticism.
    </font></p>
<p><a name="Matthiessen"></a><font><strong>Matthiessen</strong>,
    F.O. <br/>
<em>The Achievement of T.S. Eliot. An Essay on the Nature of Poetry. <br/>
</em>Oxford UP. New York, 1947. </font></p>
<p><a name="Maxwell"></a><font><strong>Maxwell</strong>, D.E.S. <br/>
<em>The Poetry of T.S. Eliot. <br/>
</em>Routledge &amp; Kegan Paul Ltd. London, 1952. </font></p>
<p><font>Style: SURVEY</font></p>
<p><font>Hovers probably a little bit too much over the surface of
    the works for today's critic, but his cultural and social view of Eliot's poetry,
    prominent throughout the book, is closer to Eliot's own life and times and from that
    perspective interesting and informative.</font></p>
<p><a name="Moody"></a><font><strong>Moody</strong>, A. David. (Ed.)<br/>
<em>The Cambridge Companion to T.S. Eliot.<br/>
</em>Cambridge UP. Cambridge, 1994.</font></p>
<p><font>Style: COLLECTION</font></p>
<p><font>A good collection of essays. Particularly James
    Longenbach's very informed discussion of Eliot's allusive practice deserves mention. To
    quote: "it is ultimately more important to understand the nature of Eliot's allusive
    practice - to ask not only <em>what is the source</em>? but <em>why does Eliot allude</em>?
    and <em>how do we experience the allusion</em>?" (p. 176)</font></p>
<p><font><strong>Moody</strong>, A. David. <br/>
<em>Thomas Stearnes Eliot. Poet.<br/>
</em>CUP. Cambridge, 1979 </font></p>
<p><font>Style: SURVEY</font></p>
<p><font>A broad discussion of Eliot as a poet. I find myself often
    surprised how Moody clings to certain points of view despite his own evidence. Whether
    this is due to a lack of insight or a lack of knowledge, I cannot tell. Perhaps it is a
    lack of scientific rigor, which is a more common fault in the field.</font></p>
<p><font><strong>Moody</strong>, A. David<br/>
<em>Tracing T.S. Eliot's Spirit<br/>
</em>CUP. Cambridge, 1996</font></p>
<p><a name="North"></a><font><strong>North</strong>, Michael. <br/>
<em>The Political Aesthetic of Yeats, Eliot, and Pound. <br/>
</em>CUP. New York, 1991.</font></p>
<p><a name="Palmer"></a><font><strong>Palmer</strong>, Marja. <br/>
<em>Men and Women in T.S. Eliot's Early Poetry. <br/>
</em>Lund University Press. Lund, 1996. </font></p>
<p><font>Style: THEMATICAL</font></p>
<p><font>Useful place to start if this is your angle on the poetry,
    but not particulary enlightning otherwise.</font></p>
<p><a name="Quillian"></a><font><strong>Quillian</strong>, William.<br/>
<em>Hamlet and the New Poetic</em>.<br/>
    UMI Research Press. Ann Arbor (MI), 1975.</font></p>
<p><font>Style: THEMATICAL</font></p>
<p><font>Discusses the shift in perception of Shakespeare's play
    during the Modernist age, by closely examining Joyce and Eliot's literary criticism of
    Hamlet and contrasting it mainly with the Victorian perception of the play. Obviously
    essential reading for anyone interested in Eliot's essay on Hamlet, but also very useful
    for anyone interested in Eliot as a critic in general, and for understanding the sections
    in the poetry in which Eliot refers to Hamlet (see influences).</font></p>
<p><a name="Rees"></a><font><strong>Rees</strong>, Thomas R. <br/>
<em>The Technique of T.S. Eliot. <br/>
</em>Mouton. The Hague, 1974.</font></p>
<p><font>Style: TECHNICAL</font></p>
<p><font>A detailed study of Eliot's poetical technique, following
    the development from Prufrock to the Four Quartets. It pays close attention to rhythm and
    the influences, particularly the French, which shaped them. The only one on this page at
    this moment which does so, and as such very valuable.</font></p>
<p><a name="Ricks"></a><font><strong>Ricks</strong>, Christopher. <em><br/>
    T.S. Eliot and Prejudice.</em><br/>
    Faber and Faber. London, 1988.</font></p>
<p><font>Style: THEMATICAL/BIOGRAPHICAL</font></p>
<p><font>Christopher Ricks' book approaches T.S. Eliot's complex
    relation with prejudice in a broader, friendlier and somewhat more scholarly way than
    other books on this subject, and this is probably the book to read first. Nevertheless, it
    has its faults too: written in a rather loosely and Ricks' the biographer is overly
    prominent in this book. </font></p>
<p><a name="Sigg"></a><font><strong>Sigg</strong>, Eric. <br/>
<em>The American T.S. Eliot. A Study of the Early Writings. <br/>
</em>Cambridge UP. New York, 1989. </font></p>
<p><font>Style: SURVEY</font></p>
<p><font>Detailed discussion of the early writings with an eye on
    Eliot's American background. Much better than its counterpart "The English T.S.
    Eliot." (not currently featured on these pages). Many unfortunate faults have been
    made in interpreting the evidence gathered, but the evidence itself is good and helpful.</font></p>
<p><font><b>Sloane</b>, Patricia.<br/>
<i>T.S. Eliot's Bleistein Poems: Uses of Literary Allusion in    "Burbank with a Baedeker: Bleistein with a Cigar" and "Dirge."\xA0<br/>
</i>Introduction by Shyamal Bagchee.<br/>
      International Scholars Publications. New York, 2000.</font></p>
<p><font>Style: SURVEY</font></p>
<p><font>Highly recommended for anyone interested in Eliot's poetic method in
      general, especially of the earlier work, and obviously the Bleistein poems
      in particular. A must read for any academic whose work touches upon (supposed) anti-Semitism, the Bleistein and Sweeney poems, and Eliot's
      method of allusion and satire. Shyamal Bagchee, who wrote the    introduction, is the Vice-President of the T. S. Eliot Society    and the founder of the Yeats-Eliot Review.</font></p>
<p><a name="Smith"></a><font><strong>Smith</strong>, Grover. <br/>
<em>T.S. Eliot's Poetry and Plays. A Study in Sources and Meaning. <br/>
</em>University of Chicago Press. Chicago, 1950. </font></p>
<p><font>Style: SURVEY</font></p>
<p><font>This study is old, but a good place to start. Good about
    this book is that it has collected a lot of the sources for Eliot's allusionary poetry.
    Bad about this book is that Sources and Meaning seem to have been studied wholly
    separately. Fourty-eitght years later, we would still rather like to see a study of the
    meaning of the sources.</font></p>
<p><a name="Southam"></a><font><strong>Southam</strong>, B.C.<br/>
<em>A Student's Guide to the Selected Poems of T.S. Eliot.<br/>
</em>Faber &amp; Faber. London, 1994</font></p>
<p><font>Style: SURVEY</font></p>
<p><font>The most comprehensive selection of annotations and
    introductions to the Selected Poems available. This is <em>the </em>book to start with for
    any student or scholar; it also recommends other books when appropriate. Southam writes
    clear, concise, knowledgeable and uptodate - so that it is also recommended you get the
    latest edition. Strongest weakness is that it does not at this point identify sources very
    well, listing only a number of book at the end.</font></p>
<p><a name="Svarny"></a><font><strong>Svarny</strong>, Erik.<br/>
<em>'The Men of 1914'. T.S. Eliot and early Modernism.<br/>
</em>Open University Press. Stratford, 1988.</font></p>
<p><a name="Tratner"></a><font><strong>Tratner</strong>, Michael. <br/>
<em>Modernism and Mass Politics. Joyce, Woolf, Eliot, Yeats. <br/>
</em>Stanford UP. Stanford, 1995.</font></p>
<p><a name="Wilk"></a><font><strong>Wilk</strong>, Melvin. <em><br/>
    Jewish Presence in T.S. Eliot and Franz Kafka<br/>
</em>1992</font></p>
<p>Style: THEMATICAL</p>
<p>Wilk's conclusion is, like Julius, that Eliot had strong anti-Semitic
    tendencies. The method and approach of this book does not differ significantly from Ricks
    or Julius in that respect, nor do the conclusions. </p>
<p><a name="Williamson"></a><strong>Williamson</strong>, George. <br/>
<em>A Reader's Guide To T.S. Eliot. A poem-by-poem analysis. <br/>
</em>The Noonday Press. New York, 1953. </p>
<p>Style: OVERVIEW</p>
<p>When compared to the the likes of Grover Smith, who published his work
    only three years before, initially this work seems limited and shallow - but upon closer
    inspection, its very concise discussions are detailed and as good as most others and
    provide a good starting point. </p></td>
</tr>
</table>
</div>
`,s=`Books on "The vast accumulation of knowledge--or at least of information--deposited by the nineteenth century have been responsible for an equally vast ignorance." - T.S. Eliot Since the only possible way of preventing the same thing from happening in this century and the next is by a careful cataloguing of available knowledge, that is what this page sets out to do. If you wish to make any additions, please send a mail to A.vanArum@cable.a2000.nl , with as a subject title "Books on Eliot." Arwin van Arum Quick list of books by author Quick list of books by title Akroyd , Peter. T.S. Eliot. Penguin Books. London, 1984 Image of cover Style: BIOGRAPHICAL Akroyd's excellent biography is the current favourite, and justly so. Little fault can be found with this work, which achieves almost exactly what it sets out to do - to provide the reader with a detailed account of Eliot's life, and particularly those years in which Eliot produced his poetry. If there are any holes to be punched in this work, they are going to be in the psychological profile, which is a little shaky on certain points. Albright , Daniel. Quantum Poetics CUP. New York, 1997. T.S. Eliot Annual No. 1. Edited by Shyamal Bagchee . Macmillan Press. London, 1990. Style: COLLECTION Contains interesting article on Eliot and Ulysses. Bergonzi , Bernard. T.S. Eliot. The Macmillan Company. New York, 1972. Bush , Ronald. T.S. Eliot. A Study in Character and Style. Oxford UP. Oxford, 1983. Bush , Ronald. (Ed.) T.S. Eliot. Cambridge UP. New York, 1991. Childs , Donald J. T.S. Eliot: Mystic, Son and Lover Ethlone Press. London, 1997 Style: THEMATICAL/BIOGRAPHICAL Childs brilliantly combines rigid critical thinking and detailed literary background with a detailed examination of the actual poetry. Special interest in this book is human relations. Childs is clearly a specialist in his field, is detailed and accurate - an example to many of the more 'loose' autobiographical critics featured on these pages. Crawford , Robert. The Savage and the City in the work of T.S. Eliot. Clarendon Press. Oxford, 1987. Style: THEMATICAL Crawford has studied Eliot's study material and writings in great detail, which help him shed fresh light on otherwise repetetive discussions of the poems. This book does much more than many others and is recommended almost without reservation; the almost is due to a few obvious oversights and that Eliot's schoolwork, even in combination with Frazer, cannot explain everything. Gardner , Helen. Composition of the Four Quartets "It examines various drafts of FQ that were preserved, and reconstructs, through Eliot's correspondence (largely with one John Hayward), how many of the changes came to be made. It also has good discussions of FQ not directly tied to the drafts. I found it more enlightening re: Eliot's creative process and allusions than anything else I've read, including the WL manuscript." - Tom Kissane. on the T.S. Eliot list. Gish , Nancy. Time in the Poetry of T.S. Eliot. A Study of Structure and Theme. MacMaillan Press. London, 1981. A detailed and compact introduction to Eliot's poetry and although the title stresses time, Ms Gish's book is a good start for anyone interested in the poems. The work covers everything from Prufrock to Four Quartets . Graves , Robert and Riding, Laura. A Survey of Modernist Poetry Doubleday. New York, 1928. Style: SURVEY Important historical piece of literary criticism, and the first to treat the modernist movement as a historical movement rather than a contemporary one. The authors are both poets themselves. Jain , Manju. T.S. Eliot and American Philosophy. The Harvard Years. Cambridge UP. Cambridge, 1992 Julius , Anthony. T.S. Eliot, anit-Semitism, and literary form. Cambridge UP. Cambridge, 1995 Style: THEMATICAL/BIOGRAPHICAL Antony Julius' well-known book deals mainly with the issue of anti-semitism in T.S. Eliot's work. His approach is one of 'presumed guilty' and his method is of selecting as much evidence 'against' Eliot, which is fairly convincing, although doubt has been cast on his method and selection of evidence. The merit of this book lies mainly in the detailed and knowledgeable representation of the different forms of anti-Semitism that existed in Eliot's time. Like many other critics, Julius fails to pay sufficient attention to the works Eliot refers or alludes to. Lobb , Edward. T.S. Eliot and the Romantic Critical Tradition. Routledge & Kegan Paul. London, 1981. For what the title proposes to do I believe that the Quillian book on Joyce and Eliot ( Hamlet and the New Poetic ) is a better introduction - it discusses in much more detail how Eliot fitted into a literary critical tradition, by offering the reader many influential extracts from the critics preceding and influencing Eliot. Lobb's book, however, is a good introductory discussion of the social and historical cultural context on a more general level (rather than that of Hamlet, for instance), and gives a detailed overview of practically all of Eliot's criticism. Matthiessen , F.O. The Achievement of T.S. Eliot. An Essay on the Nature of Poetry. Oxford UP. New York, 1947. Maxwell , D.E.S. The Poetry of T.S. Eliot. Routledge & Kegan Paul Ltd. London, 1952. Style: SURVEY Hovers probably a little bit too much over the surface of the works for today's critic, but his cultural and social view of Eliot's poetry, prominent throughout the book, is closer to Eliot's own life and times and from that perspective interesting and informative. Moody , A. David. (Ed.) The Cambridge Companion to T.S. Eliot. Cambridge UP. Cambridge, 1994. Style: COLLECTION A good collection of essays. Particularly James Longenbach's very informed discussion of Eliot's allusive practice deserves mention. To quote: "it is ultimately more important to understand the nature of Eliot's allusive practice - to ask not only what is the source ? but why does Eliot allude ? and how do we experience the allusion ?" (p. 176) Moody , A. David. Thomas Stearnes Eliot. Poet. CUP. Cambridge, 1979 Style: SURVEY A broad discussion of Eliot as a poet. I find myself often surprised how Moody clings to certain points of view despite his own evidence. Whether this is due to a lack of insight or a lack of knowledge, I cannot tell. Perhaps it is a lack of scientific rigor, which is a more common fault in the field. Moody , A. David Tracing T.S. Eliot's Spirit CUP. Cambridge, 1996 North , Michael. The Political Aesthetic of Yeats, Eliot, and Pound. CUP. New York, 1991. Palmer , Marja. Men and Women in T.S. Eliot's Early Poetry. Lund University Press. Lund, 1996. Style: THEMATICAL Useful place to start if this is your angle on the poetry, but not particulary enlightning otherwise. Quillian , William. Hamlet and the New Poetic . UMI Research Press. Ann Arbor (MI), 1975. Style: THEMATICAL Discusses the shift in perception of Shakespeare's play during the Modernist age, by closely examining Joyce and Eliot's literary criticism of Hamlet and contrasting it mainly with the Victorian perception of the play. Obviously essential reading for anyone interested in Eliot's essay on Hamlet, but also very useful for anyone interested in Eliot as a critic in general, and for understanding the sections in the poetry in which Eliot refers to Hamlet (see influences). Rees , Thomas R. The Technique of T.S. Eliot. Mouton. The Hague, 1974. Style: TECHNICAL A detailed study of Eliot's poetical technique, following the development from Prufrock to the Four Quartets. It pays close attention to rhythm and the influences, particularly the French, which shaped them. The only one on this page at this moment which does so, and as such very valuable. Ricks , Christopher. T.S. Eliot and Prejudice. Faber and Faber. London, 1988. Style: THEMATICAL/BIOGRAPHICAL Christopher Ricks' book approaches T.S. Eliot's complex relation with prejudice in a broader, friendlier and somewhat more scholarly way than other books on this subject, and this is probably the book to read first. Nevertheless, it has its faults too: written in a rather loosely and Ricks' the biographer is overly prominent in this book. Sigg , Eric. The American T.S. Eliot. A Study of the Early Writings. Cambridge UP. New York, 1989. Style: SURVEY Detailed discussion of the early writings with an eye on Eliot's American background. Much better than its counterpart "The English T.S. Eliot." (not currently featured on these pages). Many unfortunate faults have been made in interpreting the evidence gathered, but the evidence itself is good and helpful. Sloane , Patricia. T.S. Eliot's Bleistein Poems: Uses of Literary Allusion in "Burbank with a Baedeker: Bleistein with a Cigar" and "Dirge." Introduction by Shyamal Bagchee. International Scholars Publications. New York, 2000. Style: SURVEY Highly recommended for anyone interested in Eliot's poetic method in general, especially of the earlier work, and obviously the Bleistein poems in particular. A must read for any academic whose work touches upon (supposed) anti-Semitism, the Bleistein and Sweeney poems, and Eliot's method of allusion and satire. Shyamal Bagchee, who wrote the introduction, is the Vice-President of the T. S. Eliot Society and the founder of the Yeats-Eliot Review. Smith , Grover. T.S. Eliot's Poetry and Plays. A Study in Sources and Meaning. University of Chicago Press. Chicago, 1950. Style: SURVEY This study is old, but a good place to start. Good about this book is that it has collected a lot of the sources for Eliot's allusionary poetry. Bad about this book is that Sources and Meaning seem to have been studied wholly separately. Fourty-eitght years later, we would still rather like to see a study of the meaning of the sources. Southam , B.C. A Student's Guide to the Selected Poems of T.S. Eliot. Faber & Faber. London, 1994 Style: SURVEY The most comprehensive selection of annotations and introductions to the Selected Poems available. This is the book to start with for any student or scholar; it also recommends other books when appropriate. Southam writes clear, concise, knowledgeable and uptodate - so that it is also recommended you get the latest edition. Strongest weakness is that it does not at this point identify sources very well, listing only a number of book at the end. Svarny , Erik. 'The Men of 1914'. T.S. Eliot and early Modernism. Open University Press. Stratford, 1988. Tratner , Michael. Modernism and Mass Politics. Joyce, Woolf, Eliot, Yeats. Stanford UP. Stanford, 1995. Wilk , Melvin. Jewish Presence in T.S. Eliot and Franz Kafka 1992 Style: THEMATICAL Wilk's conclusion is, like Julius, that Eliot had strong anti-Semitic tendencies. The method and approach of this book does not differ significantly from Ricks or Julius in that respect, nor do the conclusions. Williamson , George. A Reader's Guide To T.S. Eliot. A poem-by-poem analysis. The Noonday Press. New York, 1953. Style: OVERVIEW When compared to the the likes of Grover Smith, who published his work only three years before, initially this work seems limited and shallow - but upon closer inspection, its very concise discussions are detailed and as good as most others and provide a good starting point.`,c=[{kind:`internal`,path:`Books/IMG_Akroyd.htm`,fragment:null,label:``,resolvedPath:`Books/IMG_Akroyd.htm`,pageId:`books-img-akroyd`},{kind:`internal`,path:`Eliot_books.htm`,fragment:null,label:`Quick list of books by author`,resolvedPath:`Eliot_Books.htm`,pageId:`eliot-books`},{kind:`internal`,path:`Books/IMG_Akroyd.htm`,fragment:null,label:``,resolvedPath:`Books/IMG_Akroyd.htm`,pageId:`books-img-akroyd`},{kind:`internal`,path:`Books/IMG_Akroyd.htm`,fragment:null,label:`Image of cover`,resolvedPath:`Books/IMG_Akroyd.htm`,pageId:`books-img-akroyd`}],l=[{kind:`internal`,path:`pic.gif`,fragment:null,alt:``},{kind:`internal`,path:`pic.gif`,fragment:null,alt:``},{kind:`internal`,path:`pic.gif`,fragment:null,alt:``}],u={edition:`preserved`,sourceFile:`Eliot_Books.htm`},d=[`byauthor`,`contents`,`eliot-books`],f={id:e,slug:t,type:n,title:r,sourceFile:i,encoding:a,html:o,text:s,links:c,images:l,provenance:u,backlinks:d};export{d as backlinks,f as default,a as encoding,o as html,e as id,l as images,c as links,u as provenance,t as slug,i as sourceFile,s as text,r as title,n as type};