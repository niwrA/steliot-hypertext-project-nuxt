var e=`burbank-notes-stonesi-jr`,t=`stonesi-jr`,n=`source-page`,r=`Stones of Venice`,i=`Burbank_notes/Stonesi_JR.htm`,a=`windows-1252`,o=`
<p><font><em><strong>The Stones of Venice</strong></em></font></p>
<p><font><strong>from vol. I:</strong></font><font><strong><br/>
Chapter 1: "The Quarry"</strong></font></p>
<p>John Ruskin</p>
<div><center>
<table>
<tr>
<td><font>Ruskin,
        John.<em> The Stones of Venice. </em>Vol 1, chapter 1 -
        "The Quarry<em>". </em>p. 1-48</font></td>
</tr>
<tr>
<td>§ i. SINCE the first dominion of man was asserted
        over the ocean, three thrones, of mark beyond all others,
        have, been set upon its sands: the thrones of Tyre,
        Venice, and England. Of the First of these great powers
        only the memory remains; of the Second, the ruin ; the
        Third, which inherits their greatness, if it forget their
        example, may be led through prouder eminence to less
        pitied destruction.<p>The exaltation, the, sin, and the
        punishment of Tyre have been recorded for us, in perhaps
        the most touching words ever uttered by the Prophets of
        Israel against the cities of the stranger. But we read
        them as a lovely song; and close our cars to the
        sternness of their warning : for the very depth of the
        Fall of Tyre has blinded us to its reality, and we
        forget, as we watch the bleaching of the rocks between
        the sunshine and the sea, that they were once " as
        in Eden, the garden of God."</p>
<p>Her successor, like her in perfection of beauty,
        though less in endurance of dominion, is still left for
        our beholding in the final period of her decline: a ghost
        upon the sands of the sea, so weak-so quiet,-so bereft of
        all but her loveliness, that we might well doubt, as we
        watched her faint reflection in the mirage of the lagoon,
        which was the City, and which the Shadow.</p>
<p>I would endeavor to trace the lines of this image
        before it be for ever lost, and to record, as far as I
        may, the warning which seems to me to be uttered by every
        one of the fast gaining waves, that beat, Eke passing
        bells, against the Stones of Venice.</p>
<p>§ ii. It would be difficult to overrate the value of
        the lessons which might be derived from a faithful study
        of the history of this strange and mighty city: a history
        which, in spite of the labor of countless chroniclers,
        remains in vague and disputable outline,-barred with
        brightness and shade, like the far away edge of her own
        ocean, where the surf and the sandbank are mingled with
        the sky. The inquiries in which we have to engage will
        hardly render this outline clearer, but their results
        will, in some degree, alter its aspect; and, so far as
        they bear upon it at all, they possess an interest of a
        far higher kind than that usually belonging to
        architectural investigations. I may, perhaps, in the
        outset, and in few words, ,enable the general reader to
        form a clearer idea of the importance of every existing
        expression of Venetian character through Venetian art,
        and of the breadth of interest which the true history of
        Venice embraces, than be is likely to have gleaned from
        the current fables of her mystery or magnificence.</p>
<p>§ iii. Venice is usually conceived as an oligarchy :
        She was so during a period less than the half of her
        existence, and that including the days of her decline ;
        and it is one of the first questions needing severe
        examination, whether that decline was owing in any wise
        to the change in the form of her government, or
        altogether, as assuredly in great part, to changes, in
        the character of the persons of whom it was composed.</p>
<p>The state of Venice existed Thirteen Hundred and
        Seventy-six years, from the first establishment of a
        consular government on the island of the Rialto,* to the
        moment when the General-in-chief of the French army of
        Italy pronounced the Venetian republic a thing of the
        past. Of this period, Two Hundred and Seventy-six I years
        were passed in a nominal subjection to the cities of old
        Venetia, especially to Padua, and in an agitated form of
        democracy, of which the executive appears to have been
        entrusted to tribunes,!! chosen, one by the inhab</p>
<p>* Appendix 1, ' Foundation of Venice." I Appendix
        2, " Power of the Doges." !! Sismondi, Hist.
        des Rép. Ital. ~ vol. i.. ch. v,</p>
<p>itants of each of the principal islands. For six
        hundred years,* during which the power of Venice was
        continually on the increase, her government was an
        elective monarchy, her King or doge possessing, in early
        times at least, as much independent authority as any
        other European sovereign, but an authority gradually
        subjected to limitation, and shortened almost daily of
        its prerogatives, while it increased in a spectral and
        incapable magnificence. The final government of the
        nobles, under the image of a king, lasted for five
        hundred years, during which Venice reaped the fruits of
        her former energies, consumed them,-and expired.</p>
<p>§ iv. Let the reader therefore conceive the existence
        of the Venetian state as broadly divided into two periods
        : the first of nine hundred, the second of five hundred
        years, the separation being marked by what was called the
        " Serrar del Consiglio ; " that is to say, the
        final and absolute distinction of the nobles from the
        commonalty, and the establishment of the government in
        their hands to the exclusion alike of the influence of
        the people on the one side, and the authority of the Doge
        on the other.</p>
<p>Then the first period, of nine hundred years, presents
        us with the most interesting spectacle of a people
        struggling out 'of anarchy into order and power ; and
        then governed, for the most part, by the worthiest and
        noblest man whom they could find among them,! called
        their Doge or Leader' with an aristocracy gradually and
        resolutely forming itself around him, out of which, and
        at last by which, he was chosen; an aristocracy owing its
        origin to the accidental numbers, influence, and wealth
        of some among the families of the fugitives from the
        older Venetia, and gradually organizing itself. by its
        unity and heroism, into a separate body.</p>
<p>This first period includes the rise of Venice her
        noblest achievements, and the circumstances which
        determined her character and position among European
        powers; and within</p>
<p>* Appendix 3, " Serrar del Consiglio. "</p>
<p>1 " Ha saputo trovar modo che non uno' non pochi'
        non molti' signo-<br/>
        reggiano, ma molti buoni, pochi migliori, e
        insiemeniente, un ottime<br/>
        solo." Ah, well done, Venice ! Wisdom this, indeed.</p>
<p>its range, as might have been anticipated, we find the
        names of all. her hero princes,-of Pietro Urseolo,
        Ordalafo Falier, Domenico Michieli, Sebastiano Ziani, and
        Enrico Dandolo.</p>
<p>§ v. The second period opens with a hundred and
        twenty years, the most eventful in the career of
        Venice-the central struggle of her life-stained with her
        darkest crime, the murder of Carrara-disturbed by her
        most dangerous internal sedition, the conspiracy of
        Falier-oppressed by her most fatal wax, the war of
        Chiozza-and distinguished by the glory of her two noblest
        citizens (for in this period the heroism of her citizens
        replaces that of her monarchs), Vittor Pisani and Carlo
        Zeno.</p>
<p>I date the commencement of the fall of Venice from the
        death of Carlo Zeno, 8th May 1418 * the visible
        commencement from that of another oiler noblest and
        wisest children, the Doge Tomaso Mocenigo, who expired
        five years later.</p>
<p>The reign of Foscari followed, gloomy with pestilence
        and war; a war in which large acquisitions of territory
        were made by subtle or fortunate policy in Lombardy, and
        disgrace, significant as irreparable, sustained in the
        battles on the Po at Cremona, and in the marshes of
        Caravaggio. In 1454, Venice, the first of the states of
        Christendom, humiliated herself to the Turk: in the same
        year was established the Inquisition of State,! and from
        this period her government takes the perfidious and
        mysterious form under which it is usually conceived. In
        1477, the great Turkish invasion spread terror to the
        shores of the lagoons ; and in 1508 the league of Cambrai
        marks the period usually assigned as the commencement of
        the decline of the Venetian power; I the commercial
        prosperity of Venice in the close of the fifteenth
        century blinding her historians to the previous evidence
        of the diminution of her internal strength.</p>
<p>* Daru, liv. xii. ch. xii.</p>
<p>!Daru, liv. xvi. cap. xx. We owe to this historian the
        discovery of the statutes of the tribunal and date of its
        establishment.</p>
<p>!!Ominously signified by their humiliation to the
        Papal power (as before to the Turkish) in 1509' and their
        abandonment of their right of appointing the clergy of
        their territories.</p>
<p>§ vi. Now there is apparently a significative
        coincidence between the establishment of the aristocratic
        and oligarchical powers, and the diminution of the
        prosperity of the state. But this is the very question at
        issue; and it appears to me quite undetermined by any
        historian, or determined by each in accordance with his
        own prejudices. It is a triple question : first, whether
        the oligarchy established by the efforts of individual
        ambition was the cause, in its subsequent operation, of
        the Fall of Venice ; or (secondly) whether the
        establishment of the oligarchy itself be not the sign and
        evidence rather than the cause, of national enervation ;
        or (lastly) whether, as I rather think, the history of
        Venice might not be written almost without reference to
        the construction of her senate or the prerogatives of her
        Doge. It is the history of a people eminently at unity in
        itself, descendants of Roman race, long disciplined by
        adversity, and compelled by its position either to live
        nobly or to perish :-for a thousand years they fought for
        life ; for three hundred they invited death: their battle
        was rewarded, and their call was heard.</p>
<p>§ vii. Throughout her career, the victories of
        Venice, and, at many periods of it, her safety, were
        purchased by individual heroism ; and the man who exalted
        or saved her was sometimes (oftenest) her king, sometimes
        a noble, sometimes a citizen. To him no matter, nor to
        her: the real question is, not so much what names they
        bore' or with what powers they were entrusted, as how
        they were trained; how they were made masters of
        themselves, servants of their country, patient of
        distress, impatient of dishonor; and what was the true
        reason of the change from the time when she could find
        saviours among those whom she had cast into prison' to
        that when the voices of her own children commanded her to
        sign convenant with Death.*</p>
<p>§ viii. On this collateral question I wish the
        reader's mind to be fixed throughout all our subsequent
        inquiries. It will give double interest to every detail :
        nor will the interest be profitless ; for the evidence
        which I shall be able to deduce</p>
<p>* The senate voted the abdication of their authority
        by a majority of 612 to 14. (Alison, ch, xxiii.)</p>
<p>from the arts of Venice will be both frequent and
        irrefragable, that the decline of her political
        prosperity was exactly coincident with that of domestic
        and individual religion.</p>
<p>I say domestic and individual ; for-and this is the
        second point which I wish the reader to keep in mind-the
        most curious phenomenon in all Venetian history is the
        vitality of religion in private life, and its deadness in
        public policy. Amidst the. enthusiasm, chivalry, or
        fanaticism of the other states of Europe, Venice stands,
        from first to last, like a masked statue ; her coldness
        impenetrable' her exertion only aroused by the touch of a
        secret spring. . That spring was her commercial
        interest,-this the one motive of all her important
        political acts, or enduring national animosities. She
        could forgive insults to her honor, but never rivalship
        in her commerce ; she calculated the glory of her
        conquests by their value, and estimated their justice by
        their facility. The fame of success remains, when the
        motives of attempt are forgotten ; and the casual reader
        of her history may perhaps be surprised to be reminded,
        that the expedition which was commanded by the noblest of
        her princes, and whose results added most to her military
        glory, was one in which while all Europe around her was
        wasted by the fire of its devotion, she first calculated
        the highest price she could exact from its piety for the
        armament she furnished, and then, for the advancement of
        her own private interests, at once broke her faith * and
        betrayed her religion.</p>
<p>§ ix. And yet, in the midst of this national
        criminality, we shall be struck again and again by the
        evidences of the most noble individual feeling. The tears
        of Dandolo were not shed in hypocrisy, though they could
        not blind him to the importance of the conquest of Zara.
        The habit of assigning to religion a direct influence
        over all his own actions, and all the affairs of his own
        daily life, is remarkable in every great Venetian during
        the times of the prosperity of the state ; nor are
        instances wanting in which the private feeling of the
        citizens</p>
<p>* By directing the arms of the Crusaders against a
        Christian prince Daru, liv. iv. ch. iv. viii.)</p>
<p>reaches the sphere of their policy, and even becomes
        the guide of its course where the scales of expediency
        are doubtfully balanced. I sincerely trust that the
        inquirer would be disap- pointed who should endeavor to
        trace any more immediate reasons for their adoption of
        the cause of Alexander III against Barbarossa, than the
        piety which was excited by the character of their
        suppliant, and the noble pride which was provoked by the
        insolence of the emperor. But the heart of Venice is
        shown only in her hastiest councils; her worldly spirit
        recovers the ascendency whenever she has time to
        calculate the probabilities of advantage, or when they
        are sufficiently distinct to need no calculation ; and
        the entire subjection of private piety to national policy
        is not only remarkable throughout the almost endless
        series of tra and tyrannies by which her empire was
        enlarged and maintained, but symbolised by a very
        singular circumstance in the building of the city itself.
        I am aware of no other city of Europe in which its
        cathedral was not the principal feature. But the
        principal church in Venice was the chapel attached to the
        palace of her prince, and called the " Chiesa
        Ducale." The patriarchal church'* inconsiderable in
        size and mean in decoration, stands on the outermost
        islet of the Venetian group, and its name, as well as its
        site, is probably unknown to the greater number of
        travellers passing hastily through the city. Nor is it
        less worthy of remark, that the two most important
        temples of Venice, next to the ducal chapel, owe their
        size and magnificence, not to national effort, but to the
        energy of the Franciscan and Dominican monks, supported
        by the vast organization of those great societies on the
        mainland of Italy, and countenanced by the most pious,
        and perhaps also, in his generation, the most wise, of
        all the princes of Venice! who now rests beneath the roof
        of one of those very temples' and whose life is not
        satirized by the images of the Virtues which a Tuscan
        sculptor has placed around his tomb.</p>
<p>§ x. There are, therefore, two strange and solemn
        lights</p>
<p>* Appendix 4, " San Pietro di Castello.' <br/>
        ! Tomaso Mocenigo, above named, § v.</p>
<p>in which we have to regard almost every scene in the
        fitful history of the Rivo Alto. We find, on the one
        hand, a deep and constant tone of individual religion
        characterising the lives of the citizens of Venice in her
        greatness ; we find this spirit influencing them in all
        the familiar and immediate concerns of life, giving a
        peculiar dignity to the conduct even of their commercial
        transactions, and confessed by them with a simplicity of
        faith that may well put to shame the hesitation with
        which a man of the world at present admits (even if it be
        so in reality) that religious feeling has any influence
        over the minor branches of his conduct. And we find as
        the natural. consequence of all this, a healthy serenity
        of mind and energy of will expressed in all their
        actions, and a habit of heroism which never fails them'
        even when the immediate motive of action ceases to be
        praiseworthy. With the fulness of this spirit the
        prosperity of the state is exactly correspondent, and
        with its failure her decline, and that with a closeness
        and precision which it will be one of the collateral
        objects of the following essay to demonstrate from such
        accidental evidence as the field of its inquiry presents.
        And, thus far, all is natural and simple. But the
        stopping short of this religious faith when it appears
        likely to influence national action, correspondent as it
        is, and that most strikingly, with several
        characteristics of the temper of our present English
        legislature, is a subject, morally and politically, of
        the most curious interest and complicated difficulty ;
        one, however, which the range of my present inquiry will
        not permit me to preach, and for the treatment of which 1
        must be content to furnish materials in the light I may
        be able to throw upon the private tendencies of the
        Venetian character.</p>
<p>§ xi. There is, however, another most interesting
        feature in the policy of Venice which will be often
        brought before us; and which a Romanist would gladly
        assign as the reason of its irreligion; namely, the
        magnificent and successful struggle which she maintained
        against the temporal authority of the Church of Rome. It
        is true that, in a rapid survey of her career, the eye is
        at first arrested by the strange drama to which I have
        already alluded, closed by that ever memorable scene in
        the portico of St Mark's,* the central expression in most
        men's thoughts of the unendurable elevation of the
        pontifical power; it is true that the proudest thoughts
        of Venice, as well as the insignia of her prince, and the
        form of her chief festival, recorded the service thus
        rendered to the Roman Church. But the enduring sentiment
        of years more than balanced the enthusiasm of a moment ;
        and the bull of Clement V., which excommunicated the
        Venetians and their doge, likening them to Dathan,
        Abiram, Absalom, and Lucifer, is a stronger evidence of
        the great tendencies of the Venetian government than the
        umbrella of the doge or the ring of the Adriatic. The
        humiliation of Francesco Dandolo blotted out the shame of
        Barbarossa, and the total exclusion of ecclesiastics from
        all share in the councils of Venice became an enduring
        mark of her knowledge of the spirit of the Church of
        Rome, and of her defiance of it.</p>
<p>To this exclusion of Papal influence from her
        councils, the Romanist will attribute their irreligion,
        and the Protestant their success.! The first may be
        silenced by a reference to the character of the policy of
        the Vatican itself ; and the second by his own shame,
        when he reflects that the English legislature sacrificed
        their principles to expose themselves to the very danger
        which the Venetian senate sacrificed theirs to avoid.</p>
<p>§ xii. One more circumstance remains to be noted
        respecting the Venetian government, the singular unity of
        the families composing it,--unity far from sincere or
        perfect, but still In that temple porch,</p>
<p>(The brass is gone' the porphyry remains,)<br/>
        Did BARBAROSSA fling his mantle off,<br/>
        And kneeling, oil his neck receive the foot <br/>
        Of the proud Pontiff-thus at last consoled <br/>
        For flight, disguise, and many ail aguish shake <br/>
        On his stone pillow."</p>
<p>I need hardly say whence the lines are taken: Rogers'
        " Italy " has, I believe, now a place in the
        best beloved compartment of all libraries, and will never
        be removed from it. There is more true expression of the
        spirit of Venice in the passages devoted to her in that
        poem, than in all else that has been written of her.</p>
<p>! At least, such success as they had. Vide Appendix 5,
        II The Papal Power in Venice. 91</p>
<p>admirable when contrasted with the fiery feuds, the
        almost daily revolutions, the restless successions of
        families and parties in power, which fill the annals of
        the other states of Italy. That rivalship should
        sometimes be ended by the dagger' or enmity conducted to
        its ends under the mask of law, could not but be
        anticipated where the fierce Italian spirit was subjected
        to so severe a restraint: it is much that jealousy
        appears usually unmingled with illegitimate ambition, and
        that, for every instance in which private passion sought
        its gratification through public danger, there are a
        thousand in which it was sacrificed to the public
        advantage. Venice may well call upon us to note with
        reverence that of all the towers which are still seen
        rising like a branchless forest from her islands, there
        is but one whose office was other than that of summoning
        to prayer, and that one was a watch-tower only: from
        first to last, while the palaces of the other cities of
        Italy were lifted into sullen fortitudes of rampart, and
        fringed with forked battlements for the javelin and the
        bow, the sands of Venice never sank under the weight of a
        war tower, and her roof terraces were wreathed with
        Arabian imagery, of golden globes suspended on the leaves
        of lilies.*</p>
<p>§ xiii. These, then, appear to me to be the points of
        chief general interest in the character and fate of the
        Venetian people. I would next endeavor to give the reader
        some idea of the manner in which the testimony of Art
        bears upon these questions, and of the aspect which the
        arts themselves assume when they are regarded in their
        true connexion with the history of the state.</p>
<p>1st. Receive the witness of Painting.</p>
<p>It will be remembered that I put the commencement of
        the Fall of Venice as far back as 1418.<br/>
        Now, John Bellini was born in 1423, and Titian in 1480.
        John Bellini, and his brother Gentile, two years older
        than he, close the line of the sacred painters of Venice.
        But the most solemn spirit of religious faith animates
        their works to the</p>
<p>* The inconsiderable fortifications of the arsenal are
        no exception to this statement as fax as it regards the
        city itself. They are little more than a semblance of
        precaution against the attack of a foreign enemy last
        There is no religion in any work of Titian's : there is
        not even the smallest evidence of religious temper or
        sympathies either in himself, or in those for whom he
        painted. His larger sacred subjects are merely themes for
        the exhibition of pictorial rhetoric,-composition and
        color. His minor works .are generally made subordinate to
        purposes of portraiture, The Madonna in the church of the
        Frari is a mere lay figure, introduced to form a link of
        connexion between the portraits of various members of the
        Pesaro family who surround her.</p>
<p>Now this is not merely because John Bellini was a
        religious man and Titian was not. Titian and Bellini are
        each true representatives of the school of painters
        contemporary with them; and the difference in their
        artistic feeling is a consequence not so much of
        difference in their own natural characters as in their
        early education : Bellini was brought up in faith; Titian
        in formalism. Between the years of their births the vital
        religion of Venice had expired.</p>
<p>§ xiv. The vital religion, observe, not the formal.
        Outward observance was as strict as ever; and doge and
        senator still were painted, in almost every important
        instance, kneeling before the Madonna or St. Mark; a
        confession of faith made universal by the pure gold of
        the Venetian sequin. But ob. serve the great picture of
        Titian's in the ducal palace, of the Doge Antonio Grimani
        kneeling before Faith : there is a curious lesson in it.
        The figure of Faith is a coarse portrait of one of
        Titian's least graceful female models : Faith bad become
        carnal The eye is first caught by the flash of the Doge's
        armor. The heart of Venice was in her wars, not in her
        worship.</p>
<p>The mind of Tintoret, incomparably more deep and
        serious than that of Titian, casts the solemnity of its
        own tone over the sacred subjects which it approaches,
        and sometimes forgets itself into devotion ; but the
        principle of treatment is altogether the same as
        Titian's: absolute subordination of the religious subject
        to purposes of decoration or portraiture.</p>
<p>The evidence might be accumulated a thousandfold from
        the works of Veronese, and of every succeeding
        painter,-that the fifteenth century had taken away the
        religious heart of Venice.</p>
<p>§ xv. Such is the evidence of Painting. To collect
        that of Architecture will be our task through many a page
        to come; but I must here give a general idea of its
        heads.</p>
<p>Philippe de Commynes, writing of his entry into Venice
        in 1495, says,--</p>
<p>"Chascun me feit seoir au meillieu de ces deux
        ambassadeurs qui est l'honneur d'ltalie que d'estre au
        meillieu; et me menerent au long de la grant rue, qu'ilz
        appellent le Canal Grant, et est bien large. Les gallees
        y passent à travers et y ay Yeu na-vire de quatre cens
        tonneaux ou plus pres des maisons : et est la plus belle
        rue que je croy qui soit en tout le monde, et la mieulx
        maisonnee, et va le -long de la ville. Les maisons sont
        fort grandes et haultes, et de bonne pierre, et les
        anciennes toutes painctes ; les aultres faictes depuis
        cent ans : toutes ont le devant de marbre blanc, qui leur
        vient d'Istrie, à cent mils de là, et encores maincte
        grant piece de porphire et de sarpentine sur le devant. .
        . . C'est la plus triumphante cité que j'aye jamais veue
        et qui plus faict d'honneur àambassadeurs et
        estrangiers, et qui plus saigement se gouverne, et où le
        service de Dieu est le plus sollempellement faict : et
        encores qu'il y peust bien avoir d'aultres faultes, si je
        croy que Dieu les a en ayde pour Ia. reverence qu'ilz
        portent au service de l'Eglise." *</p>
<p>§ xvi. This passage is of peculiar interest, for two
        reasons, Observe, first' the impression of Commynes
        respecting the religion of Venice: of which, as I have
        above said, the forms still remained with some glimmering
        of life in them, and were the evidence of what the real
        life had been in former times. But observe, secondly, the
        impression instantly made on Commynes' mind by the
        distinction between the older palaces and those built
        "within this last hundred years; which all have
        their fronts of white marble brought from Istria, a
        hundred miles away, and besides, many a large piece of
        porphyry and serpentine upon their fronts."</p>
<p>On the opposite page I have given two of the ornaments
        of</p>
<p>* Mémoires -de Commynes, liv. vii. ch. xviii.</p>
<p>the palaces which so struck the French ambassador.* He
        was right in his notice of the distinction. There had
        indeed come a change over Venetian architecture in the
        fifteenth century ; and a change , of some importance to
        us moderns: we English owe to it our St. Paul's
        Cathedral, and Europe in general owes to it the utter
        degradation or destruction of her schools of
        architecture, never since revived. But that the reader
        may understand this, it is necessary that he should have
        some general idea of the connexion of the architecture of
        Venice with that of the rest of Europe, from its origin
        forwards.</p>
<p>§ xvii. All European architecture, bad and good, old
        and new, is derived from Greece through Rome, and colored
        and perfected from the Fast. The history of architecture
        is nothing but the tracing of the various modes and
        directions of this derivation. Understand this, once for
        all: if you hold fast this great connecting clue, you may
        string all the types of successive architectural
        invention upon it like so many beads. The Doric and the
        Corinthian orders are the roots the one of all
        Romanesque, massy-capifaled buildings-Norman, Lombard,
        Byzantine, and what else you can name of the kind; and
        the Corinthian of all Gothic, Early English, French,
        German, and Tuscan. Now observe: those old Greeks gave
        the shaft ; Rome gave the arch; the Arabs pointed and
        foliated the arch. The shaft and arch, the frame-work and
        strength of architecture, are from the race of Japeth ;
        the spirituality and sanctity of it from Ismael, Abraham,
        and Shem.</p>
<p>§ xviii. There is high probability that the Greek
        received his shaft system from Egypt ; but I do not care
        to keep this earlier derivation in the mind of the
        reader. It is only necessary that he should be able to
        refer to a fixed point of origin, when the form of the
        shaft was first perfected. But it may be incidentally
        observed, that if the Greeks did indeed receive their
        Doric from Egypt' then the three families of the earth
        have each contributed their part to its noblest
        architecture; and Ham, the servant of the others,
        furnishes the sustaining</p>
<p>* Appendix 6, 'Renaissance Ornaments."</p>
<p>or bearing member, the shaft; Japheth the arch; Shem
        the spiritualisation of both.</p>
<p>§ xix. 1 have said that the two orders, Doric and
        Corinthian, are the roots of all European architecture.
        You have' perhaps heard of five orders - but there are
        only two real orders, and there never can be any more
        until doomsday. On one of these orders the ornament is
        convex : those are Doric, Norman, and what else you
        recollect of the kind On the other the ornament is
        concave : those are Corinthian, Early English, Decorated,
        and what else you recollect of that kind. The
        transitional form, in which the ornamental line is
        straight, is the centre or root of both. All other orders
        are varieties oil those, or phantasms and grotesques
        altogether indefinite in number and species.*</p>
<p>§ xx. This Greek architecture, then, with its two
        orders, was clumsily copied and varied by the Romans with
        no particular result, until they begun to bring the arch
        into extensive practical service ; except only that the
        Doric capital was spoiled in endeavors to mend it, and
        the Corinthian much varied and enriched with fanciful,
        and often very beautiful imagery. And in this state of
        things came Christianity : seized upon the arch as her
        own ; decorated it, a-ad delighted in it; invented a new
        Doric capital to replace the spoiled Roman one: and all
        over the Roman empire set to work, with such materials as
        were nearest at hand, to express and adorn herself as
        best she could. This Roman Christian architecture is the
        exact expression of the Christianity of the time, very
        fervid and beautiful-but very imperfect; in many respects
        ignorant' and yet radiant with a strong, childlike light
        of imagination, which flames up under Constantine,
        illumines all the shores of the Bosphorus and the Eagean
        and the Adriatic Sea, and then gradually, as the people
        give themselves up to idolatry, becomes Corpse-light. The
        architecture sinks into a settled form-a strange, gilded'
        and embalmed repose : it, with the religion it expressed;
        and so would have remained for ever,-so does remain,
        where its</p>
<p>I Appendix 7, "Varieties of the Orders."</p>
<p>languor has been undisturbed.* But rough wakening was
        ordained for it.</p>
<p>§ xxi. This Christian art of the declining empire is
        divided into two great branches, western and eastern ;
        one centred at Rome, the other at Byzantium, of which the
        one is the early Christian Romanesque, properly so
        called, and the other, carried to higher imaginative
        perfection by Greek workmen, is distinguished from it as
        Byzantine. But I wish the reader, for the present, to
        class these two branches of art together in his mind,
        they being, in points of main importance, the same; that
        is to say, both of them a true continuance and sequence
        of the art of old Rome itself, flowing uninterruptedly
        down from the fountain-head, and entrusted always to the
        best workmen who could be found-Latins in Italy and
        Greeks in Greece ; and thus both branches may be ranged
        under the general term of Christian Romanesque, an
        architecture which had lost the refinement of Pagan art
        in the degradation of the empire, but which was elevated
        by Christianity to higher aims, and by the fancy of the
        Greek workmen endowed with brighter forms. And this art
        the reader may conceive as extending in its various
        branches over all the central provinces of the empire,
        taking aspects more or less refined, according to its
        proximity to the seats of government ; dependent for all
        its power on the 'vigor and freshness of the religion
        which animated it ; and as that vigor and purity
        departed, losing its own vitality, and sinking into
        nerveless rest, not deprived of its beauty, but benumbed
        and incapable of advance or change.</p>
<p>§ xxii. Meantime there had been preparation for its
        renewal, While in Rome and Constantinople, and in the
        districts under their immediate influence' this Roman art
        of pure descent was practised in all its refinement, an
        impure form of it-a patois of Romanesque-was carried by
        inferior workmen into distant provinces ; and still ruder
        imitations of this patois were executed by the barbarous
        nations on the</p>
<p>* The reader will find the weak points of Byzantine
        architecture Shrewdly seized' and exquisitely sketched,
        in the opening chapter of the most delightful book of
        travels I ever opened,-Curzon's " Monasteries of the
        Levant" skirts of the empire. But these barbarous
        nations were in the strength of their youth; and while,
        in the centre of Europe, a refined and purely descended
        art was sinking into graceful formalism, on its confines
        a barbarous and borrowed art was organising itself into
        strength and consistency. The reader must therefore
        consider the history of the work of the period as broadly
        divided into two great heads: the one embracing the
        elaborately languid succession of the Christian art of
        Rome ; and the other, the imitations of it executed by
        nations in every conceivable phase of early organisation,
        on the edges of the empire, or included in its now merely
        nominal extent.</p>
<p>§ xxiii. Some of the barbaric nations were, of
        course, not susceptible of this influence; and when they
        burst over the Alps, appear, like the Huns, as scourges
        only, or mix, as the Ostrogoths, with the enervated
        Italians, and give physical strength to the mass with
        which they mingle, without materially affecting its
        intellectual character. But others, both south and north
        of the empire, had felt its influence, back to the beach
        of the Indian Ocean on the one hand, and to the ice
        creeks of the North Sea on the other. On the north and
        west the influence was of the Latins ; on the south and
        east, of the Greeks. Two nations, pre-eminent above all
        the rest, represent to us the force of derived mind on
        either side. As the central power is eclipsed, the orbs
        of reflected light gather into their fulness; and when
        sensuality and idolatry bad done their work, and the
        religion of the empire was laid asleep in a glittering
        sepulchre, the living light rose upon both horizons, and
        the fierce swords of the Lombard and Arab were shaken
        over its golden paralysis.</p>
<p>§ xxiv. The work of the Lombard was to give hardihood
        and system to the enervated body and enfeebled mind of
        Christendom ; that of the Arab was to punish idolatry,
        and to proclaim the spirituality of worship. The Lombard
        covered every church which he built with the sculptured
        representations of bodily exercises-bunting and war.* The
        Arab banished all imagination of creature form from his
        temples And</p>
<p>* Appendix 8. " The Northern Energy."</p>
<p>proclaimed from their minarets' " There is no god
        but God." opposite in their character and mission,
        alike in their magnificence of energy, they came from the
        North and from the South, the glacier torrent and the
        lava stream they met and contended over the wreck of the
        Roman empire and the very centre of the struggle, the
        point of pause of both, the dead water of the opposite
        eddies, charged with embayed fragments of the Roman
        wreck, is VENICE.<br/>
        The Ducal palace of Venice contains the three elements in
        exactly equal proportions--the Roman, Lombard, and Arab.
        It is the central building of the world.</p>
<p>§ xxv. The reader will now begin to understand
        something of the importance of the study of the edifices
        of a city which includes, within the circuit of some
        seven or eight miles, the field of contest between the
        three pre-eminent architectures of the world :-each
        architecture expressing a condition of religion ; each an
        erroneous condition, yet necessary to the cor. rection of
        the others, and corrected by them.</p>
<p>§ xxvi. It will be part of my endeavor, in the
        following work to mark the various modes in which the
        northern and southern architectures were developed from
        the Roman: here I must pause only to name the
        distinguishing characteristics of the great families. The
        Christian Roman and Byzantine work is round-arched, with
        single and well-proportioned shafts; capitals imitated
        from classical Roman ; mouldings more or less so; and
        large surfaces of walls entirely covered with imagery,
        mosaic, and paintings, whether of scripture history or of
        sacred symbols.<br/>
        The Arab school is at first the same in its principal
        features, the Byzantine workmen being employed by the
        caliphs; but the Arab rapidly introduces characters half
        Persepolitan, half Egyptian, into the shafts and
        capitals: in his intense love of excitement he points the
        arch and writhes it into extravagant foliations ; he
        banishes the animal imagery, and invents an ornamentation
        of his own (called Arabesqine) to replace it: this not
        being adapted for covering large surfaces, he
        concentrates it on features interest, and bars his
        surfaces , "',~ , horizontal lines of color, the
        expression of the level of Desert, He retains the dome,
        and adds the minaret. All is done with exquisite
        refinement.</p>
<p>§ xxvii. The changes effected by the Lombard are more
        curious still, for they are in the anatomy of the
        building, more than its decoration. The Lombard
        architecture represents, as 1 said, the whole of that of
        the northern barbaric nations And this I believe was, at
        first' an imitation in wood of the Christian Roman
        churches or basilicas. Without staying to examine the
        whole structure of a basilica, the reader will easily
        under. stand thus much of it: that it had a nave and two
        aisles' the nave much higher than the aisles; that the
        nave was separated from the aisles by rows of shafts'
        which supported, above, large spaces of flat or dead
        wall, rising above the aisles, and forming the upper part
        of the nave, now called the clerestory, which had a
        gabled wooden roof.</p>
<p>These high dead walls were, in Roman work, built of
        stone; but in the wooden work of the North, they must
        necessarily have been made of horizontal boards or
        timbers attached to uprights on the top of the nave
        pillars, which were themselves also of wood.* Now, these
        uprights were necessarily thicker than the rest of the
        timbers, and formed vertical square pilasters above the
        nave piers. As Christianity extended and civilisation
        increased, these wooden structures were changed into
        stone; but they were literally petrified, retaining the
        form which had been made necessary by their being of
        wood. The upright pilaster above the nave pier remains in
        the stone edifice' and is the first form of the great
        distinctive feature of Northern architecture--the
        vaulting shaft. In that form the Lombards brought it into
        Italy, in the seventh century' and it remains to this day
        in St. Ambrogio of Milan, and St. Michele of Pavia.</p>
<p>§ xxviii. When the vaulting shaft was introduced in
        the clerestory walls, additional members were added for
        its sup-port to the nave piers. Perhaps two or three pine
        trunks used for a single pillar, gave the first idea of
        the grouped shaft. Be that as it may, the arrangement of
        the nave pier in the form of a cross accompanies the
        superimposition of</p>
<p>* Appendix 9, " Wooden Churches of the
        North."</p>
<p>the vaulting shaft; together with corresponding
        grouping of minor shafts in doorways and apertures of
        windows. Thus, the whole body of the Northern
        architecture, represented by that of the Lombards, may be
        described as rough but majestic work, round-arched, with
        grouped shafts, added vaulting shafts, and endless
        imagery of active life and fantastic superstitions.</p>
<p>§ xxix. The glacier stream of the Lombards, and the
        following one of the Normans, left their erratic blocks,
        wherever they had flowed; but without influencing, I
        think, the Southern nations beyond the sphere of their
        own presence. But the lava stream of the Arab, even after
        it ceased to flow, warmed the whole of the Northern air;
        and the history of Gothic architecture is the history of
        the refinement and spiritiualisation of Northern work
        under its influence. The noblest buildings of the world,
        the Pisan-Romanesque, Tuscan (Giottesque) Gothic, and
        Veronese Gothic, are those of the Loynbard schools
        themselves, under its close and direct influence ; the
        various Gothics of the North axe the original forms of
        the architecture which the Lombards brought into Italy,
        changing under the less direct influence of the Arab.</p>
<p>§ xxx. Understanding thus much of the formation of
        the great European styles, we shall have no difficulty in
        tracing the succession of architectures in Venice
        herself. From what I said of the central character of
        Venetian art, the reader is not, of course, to conclude
        that the Roman, Northern, and Arabian elements met
        together and contended for the mastery at the same
        period. The earliest element was the pure Christian Roman
        ; but few, if any, remains of this art exist at Venice ;
        for the present city was in the earliest times only one
        of many settlements formed on the chain of marshy islands
        which extend from the mouths of the Isonzo to those of
        the Adige, and it was not until the beginning of the
        ninth century that it became the seat of government;
        while the cathedral of Torcello, though Christian Roman
        in general form, was rebuilt in the eleventh century, and
        shows evidence of Byzantine workmanship in many of its
        details. This cathedral, however' with the church of
        Santa Fosca at Torcello, Vol. 1.-3</p>
<p>San Giacomo di Rialto at Venice, and the crypt of St.
        Mark's. forms a distinct group of buildings, in which the
        Byzantine influence is exceedingly slight ; and which is
        probably very sufficiently representative of the earliest
        architecture on the islands.</p>
<p>§ xxxi. The Ducal residence was removed to Venice in
        809, and the body of St. Mark was brought from Alexandria
        twenty years later. The first church of St. Mark's was,
        doubtless, built in imitation of that destroyed at
        Alexandria, and from which the relies of the saint had
        been obtained. During the ninth, tenth, and eleventh
        centuries, the architecture of Venice seems to have been
        formed on the same model, and is almost identical with
        that of Cairo under the caliplis,* it being quite
        immaterial whether the reader chooses to call both
        Byzantine or both Arabic; the workmen being certainly
        Byzantine, but forced to the invention of new forms by
        their Arabian masters, and bringing these forms into use
        in whatever other parts of the world they were employed.</p>
<p>To this first manner of Venetian architecture,
        together with such vestiges as remain of the Christian
        Roman, I shall devote the first division of the following
        inquiry. The examples remaining of it consist of three
        noble churches (those of Torcello, Murano, and the
        greater part of St. Mark's), and about ten or twelve
        fragments of palaces.</p>
<p>§ xxxii. To this style succeeds a transitional one,
        of a char- much more distinctly Arabian : the shafts
        become more slender, and the arches consistently pointed'
        instead of round; certain other changes, not to be
        enumerated in a sentence, taking place in the capitals
        and mouldings. This style is almost exclusively secular.
        It was natural for the Venetians to imitate the beautiful
        details of the Arabian dwelling-house, while they would
        with reluctance adopt those of the mosque for Christian
        churches.</p>
<p>I have not succeeded in fixing limiting dates for this
        style. It appears in part contemporary with the Byzantine
        manner but outlives it. Its position is, however, fixed
        by the central date, 1180, that of the elevation of the
        granite shafts of the</p>
<p>* Appendix 10, 11 Church of Alexandria." 11</p>
<p>Piazetta, -whose capitals are the two most important
        Pieces of detail in this transitional style in Venice.
        Examples of its application to domestic buildings exist
        in almost every street of the city, and will form the
        subject of the second division of the following essay.</p>
<p>§ xxxiiii. The Venetians were always ready to receive
        les- sons in art from their enemies (else had there been
        no Arab work in Venice). But their especial dread and
        hatred of the Lombards appears to have long prevented
        them from receiving the influence of the art which that
        people bad introduced on the mainland of Italy.
        Nevertheless, during the practice of the two styles above
        distinguished, a peculiar and very primitive condition of
        pointed Gothic bad arisen in ecclesiastical architecture.
        It appears to be a feeble reflection of the Lombard-Arab
        forms' -which were attaining perfection upon the
        continent, and would probably, if left to itself, have
        been soon merged in the Venetian-Arab school' with which
        it bad from the first so close a fellowship, that it will
        be found difficult to distinguish the Arabian gives from
        those which seem to have been built under this early
        Gothic influence. The churches of San Giacopo dell' Orio,
        San Giovanni in Bra- ra, the Carmine, and one or two
        more, furnish the only important examples of it. But, in
        the thirteenth century, the Franciscans and Dominicans
        introduced from the continent their morality and their
        architecture, already a distinct Gothic, curiously
        developed from Lombardic and Northern (German?) forms;
        and the influence of the principles exhibited in the vast
        churches of St. Paul and the Frari began rapidly to
        affect the 'Venetian-Arab school. Still the two systems
        never became united; the Venetian policy repressed the
        power of the church, and the Venetian artists resisted
        its example; and thenceforward the architecture of the
        city becomes divided into ecclesiastical and civil: the
        one an ungraceful yet powerful form of the Western
        Gothic, common to the whole peninsula, and only showing
        Venetian sympathies in the adoption of certain
        characteristic mouldings; the other a rich, luxuriant,
        and entirely original Gothic, formed from the
        Venetian-Arab by the influence of the Dominican and
        Franciscan architecture, and especially by the engrafting
        upon the Arab forms of the most novel feature of the
        Franciscan work, its traceries These various forms of
        Gothic, the distinctive architecture of Venice, chiefly
        represented by the churches of St. John and Paul, the
        Frari, and San Stefano, on the ecclesiastical side, and
        by the Ducal palace, and the other principal Gothic pal,
        aces, on the secular side, will be the subject of the
        third division of the essay.</p>
<p>§ xxxiv. Now observe. The transitional (or especially
        Arabic) style of the Venetian work is centralised by the
        date 1180, and is transformed gradually into the Gothic,
        which extends in its purity from the middle of the
        thirteenth to the beginning of the fifteenth century ;
        that is to say, over the precise period which I have
        described as the central epoch of the life of Venice. I
        dated her decline from the year 1418 ; Foscari became
        doge five years later, and in his reign the first marked
        signs appear in architecture of that mighty change which
        Philippe de Commynes notices as above, the change to
        which London owes St. Paul's, Rome St. Peter's, Venice
        and Vicenza the edifices commonly supposed to be their
        noblest, and Europe in general the degradation of every
        art she has since practised.</p>
<p>§ xxxv. This change appears first in a loss of truth
        and vitality in existing architecture all. over the
        world. (Compare " Seven Lamps, " chap. ii.).
        All the Gothics in existence, southern or northern, were
        corrupted at once: the German and French lost themselves
        in every species of extravagance; the English Gothic was
        confined, in its insanity, by a strait. waistcoat of
        perpendicular lines ; the Italian effloresced on the
        mainland into the meaningless ornamentation of the
        Certosa of Pavia and the Cathedral of Como (a style
        sometimes ignorantly called Italian Gothic), and at
        Venice into the insipid confusion of the Porta della
        Carta and wild crockets of St. Mark's. This corruption of
        all architecture, especially ecclesiastical, corresponded
        with, and marked the state of religion over all
        Europe,-the peculiar degradation of the Romanist
        superstition, and of public morality in consequence which
        brought about the Reformation.</p>
<p>§ xxxvi. Against the corrupted papacy arose two great
        divisions of adversaries, Protestants in Germany and
        England, Rationalists in France and Italy; the one
        requiring the purification of religion, the other its
        destruction. The Protestant kept the religion, but cast
        aside the heresies of Rome and with them her arts, by
        which last rejection he injured his own character,
        cramped his intellect in refusing to it one of its
        noblest exercises, and materially diminished his
        influence. It may be a serious question how far- the
        Pausing of the Re. formation has been a consequence of
        this error.</p>
<p>The Rationalist kept the arts and cast aside the
        religion. This rationalistic art is the art commonly
        called Renaissance, marked by a return to pagan systems,
        not to adopt them and hallow them for Christianity, but
        to rank itself under them as an imitator and pupil. In
        Painting it is headed by Giulio Romano and Nicolo Poussin
        ; in Architecture by Sansovino and Palladio.</p>
<p>§ xxxvii. Instant degradation followed in every
        direction,-- flood of folly and hypocrisy. Mythologies
        ill understood at first, then perverted into feeble
        sensualities, take the place of the representations of
        Christian subjects, which had become blasphemous under
        the treatment of men like the Ca- Gods without power,
        satyrs without rusticity, nymphs without innocence, men
        without humanity, gather into idiot groups upon the
        polluted canvas, and scenic affectations en. cumber the
        streets with preposterous marble. Lower and lower
        declines the level of abused intellect; the base school
        of landscape * gradually usurps the place of the
        historical painting, which had sunk into prurient
        pedantry,-the Alsatian sublimities of Salvator, the
        confectionery idealities of Claude, the dull manufacture
        of Gaspar and Canaletto, south of the Alps, and on the
        north the patient devotion of besotted lives to
        delineation of bricks and fogs' fat cattle and
        ditch-water. And thus Christianity and morality, courage,
        and Intellect and art crumbling together into one wreck,
        we am hurried on to the fall of Italy, the revolution in
        France</p>
<p>* Appendix 11, 11 Renaissance Landscape,"</p>
<p>and the condition of art in England (saved by her
        Protestantism from severer penalty) in the time of George
        II</p>
<p>§ xxxviii. I have not written in vain if 1 have
        heretofore clone qDytbiDg towards diminishing the
        reputation of the Renaissance landscape painting. But the
        harm which has been done by Claude and the Poussins is as
        nothing when com-pared to the mischief effected by
        Palladio, Scamozzi, and Sansovino. Claude and the
        Poussins were weak men, and have had no serious influence
        on the general mind. There is little harm in their works
        being purchased at high prices, their real influence is
        very slight, and they may be left with- out grave
        indignation to their poor mission of furnishing
        drawing-rooms and assisting stranded conversation. Not so
        the Renaissance architecture. Raised at once into all the
        magnificence of which it was capable by Michael Angelo,
        then taken up by men of real intellect and imagination,
        such as Scamozzi, Sansovino, Inigo Jones, and Wren, it is
        impossible to estimate the extent of its influence on the
        European mind; and that the more, because few persons are
        concerned with painting, and, of those few, the larger
        number regard it with slight attention ; but all men are
        concerned with architecture, and have at some time of
        their lives serious business with it. It does not much
        matter that an individual loses two or three hundred
        pounds in buying a bad picture, but it is to be
        re-gretted that a nation should lose two or three hundred
        thou-sand in raising a ridiculou building. Nor is it
        merely wasted wealth or distempered conception which we
        have to regret in this Renaissance architecture: but we
        shall find in it partly the root, partly the expression,
        of certain dominant evils of modern times-over-so
        histication and ignorant classicalism ; the one
        destroying the healthfulness of general society, the
        other rendering our schools and universities useless to a
        large number of the men who pass through them.<br/>
        Now Venice, as she was once the most religious, was in
        her fall the most corrupt, of European states; and as she
        was in her strength the centre of the pure currents of
        Christian architecture, so she is in her decline the
        source of the Renaissance. It was the originality and
        splendor of the Palaces of Vicenza and Venice which gave
        this school its eminence in the eyes of Europe ; and the
        dying city, magnificent in her dissipation, and graceful
        in her follies, obtained wider worship in her de.
        crepitude than in her youth, and sank from the midst of
        her admirers into the grave.</p>
<p>§ xxxix. It is in Venice, therefore, and in Venice
        only that effectual blows can be struck at this pestilent
        art of the Renaissance. Destroy its claims to admiration
        there, and it can assert them nowhere else. This,
        therefore, will be the final purpose of the following
        essay. I shall not devote a fourth section to Palladia,
        nor weary the reader with successive chapters of
        virtuperation; but I shall, in my account of the earlier
        architecture, compare the forms of all its leading
        features with those into which they were corrupted by the
        Classicalists; and pause, in the close, on the edge of
        the precipice of decline, so soon as I have made its
        depths discernible. In doing this I shall depend upon two
        distinct kinds of evidence:-the first, the testimony
        borne by particular incidents and facts to a want of
        thought or of feeling in the builders; from which we may
        conclude that their architecture must be bad:-the second,
        the sense, which I doubt not I shall be able to excite in
        the reader, of a systematic ugliness in the architecture
        itself. Of the first kind of testimony I shall here give
        two instances, which may be immediately useful in fixing
        in the reader's mind the epoch above indicated for the
        commencement of decline.</p>
<p>§ xl. 1 must again refer to the importance which I
        have above attached to the death of Carlo Zeno and the
        doge Tomaso Mocenigo. The tomb of that doge is, as I
        said, wrought by a Florentine ; but it is of the same
        general type and feeling as all the Venetian tombs of the
        period, and it is one of the last which retains it. The
        classical element enters largely into its details, but
        the feeling of the whole is as yet unaffected. Like all
        the lovely tombs of Venice and Verona' it is a
        sarcophagus with a recumbent figure above, and this
        figure is a faithful but tender portrait, wrought as far
        as it can be without painfulness, of the doge as be lay
        in death. He wears his ducal robe and bonnet-his bead is
        laid slightly aside upon his pillow-his hands are simply
        crossed as they fall. The face is emaciated, the features
        large, but so pure and lordly in their natural
        chiselling, that they must have looked like marble even
        in their animation. They are deeply worn away by thought
        and death; the veins on the temples branched and starting
        ; the skin gathered in sharp folds; the brow higharched
        and shaggy ; the eye-ball magnificently large ; the curve
        of the lips just veiled by the light mustache at the
        side; the beard short, double and sharp-pointed: all
        noble and quiet; the white sepulchral dust marking like
        light the stern angles of the cheek and brow. This tomb
        was sculptured in 1424, and is thus described by one of
        the most intelligent of the recent writers who represent
        the popular feeling respecting Venetian art.</p>
<p>"Of the Italian school is also the rich but ugly
        (ricco ma non bel) sarcophagus in which repose the ashes
        of Tomaso Mocenigo. It may be called one of the last
        links which connect the declining art of the Middle Ages
        with that of the Renaissance, which was in its rise. We
        will not stay to particularise the defects of each of the
        seven figures of the front and sides, which represent the
        cardinal and theological virtues; nor will we make any
        remarks upon those which stand in the niches above the
        pavilion because we consider theta unworthy both of the
        age and reputation of the Florentine school, which was
        then with reason considered the most notable in
        Italy." *</p>
<p>It is well, indeed, not to pause over these defects ;
        but A might have been better to have paused a moment
        beside that noble image of it king's mortality.</p>
<p>§ xli. In the choir of the same church, St. Giov. and
        Paolo, is another tomb, that of the Doge Andrea
        Vendramin. This doge died in 1478' after a short reign of
        two years, the most disastrous in the annals of Venice.
        He died of a pestilence which followed the ravage of the
        Turks carried to the shores of the lagoons. He died,
        leaving Venice disgraced by sea -and land, with the smoke
        of hostile devastation rising in the blue distances of
        Friuli; and there was raised to him the most costly tomb
        ever bestowed on her monarchs.</p>
<p>§ xlii. If the writer above quoted was cold beside
        the</p>
<p>* Selvatico, " Architettura di Venezia," p,
        147,</p>
<p>statue of one of the fathers of his country, he atones
        for it by his eloquence beside the tomb of the Vendramin.
        1 must not spoil the force of Italian superlative by
        translation.</p>
<p>"Quando si guarda a quella corretta eleganza di
        profili e di proporzioni, a quella squisitezza
        d'ornamenti, a quel certo sapore antico che senza ombra
        d'imitazione traspare da tutta l'opera" " Sopra
        ornatissimo zoccolo fornito di squisiti intagli s' alza
        uno stylobate "-&amp;e. "Sotto le colonne, il
        predetto stilobate si muta leggiadramente in piedistallo,
        poi con bella novità di pensiero e di effetto va
        coronato da un fregio il più gentile che veder si possa
        "-&amp;c. "Non poussi lasciar senza un cenno
        l'arca dove sta chiuso il doge ; capo lavoro di pensiero
        e di esecuzione," &amp;c.</p>
<p>There are two pages and a half of closely printed
        praise, of which the above specimens may suffice; but
        there is not a word. of the statue of the dead from
        beginning to end. 1 am myself in the habit of considering
        this rather an important part of a tomb, and 1 was
        especially interested in it here, because Selvatico only
        echoes the praise of thousands. It is unanimously
        declared the chef d'oevre of Renaissance sepulchral work,
        and pronounced by Cicognara (also quoted by Selvatico)</p>
<p>" Il vertice a cui I' arti Veneziane si spinsero
        col ministero del scalpello," - ' The very
        culminating point to which the Venetian arts attained by
        ministry of the chisel."</p>
<p>To this culminating point, therefore, covered with
        dust and cobwebs, 1 attained, as I did to every tomb of
        importance in Venice, by the ministry of such ancient
        ladders as were to be found in the sacristan's keeping. I
        was struck at first by the excessive awkwardness and want
        of feeling in the fall of the hand towards the spectator,
        for it is thrown of the middle of the body in order to
        show its fine cutting. Now the Mocenigo hand, severe and
        even stiff in its articulations, has its veins finely
        drawn, its sculptor having justly felt that the delicacy
        of the veining expresses alike dignity and age and birth.
        Tile Vendramin hand is far more laboriously cut, but its
        blunt and clumsy contour at once makes us feel that all
        the care has been thrown away, and well it may be, for it
        has been entirely bestowed in cutting gouty wrinkles
        about the joints. Such as the hand is, I looked for its
        fellow. At first I thought it had been broken off, but,
        on clearing away the dust, I saw the wretched effigy had
        only one hand, and was a mere block on the inner side.
        The face, heavy and disagreeable in its feat-is made
        monstrous by its semi-sculpture. One side of the forehead
        is wrinkled elaborately, the other left smooth; one side
        only of the doge's cap is chased; one cheek only is
        finished, and the other blocked out and distorted
        besides; finally, the ermine robe, which is elaborately
        imitated to its utmost lock of hair and of ground hair on
        the one side, is blocked out only on the other : it
        having been supposed throughout the work that "he
        effigy was only to be seen from below, and from one side.</p>
<p>§ xliii. It was indeed to be so seen by nearly every
        one and I do not blame-I should, on the contrary, have
        praised -the sculptor for regulating his treatment of it
        by its position ; if that treatment had not involved,
        first, dishonesty, ill giving only half a face, a
        monstrous mask, when we demanded true portraiture of the
        dead; and, secondly, such utter coldness of geeling, as
        could only consist with an extreme of intellectual and
        moral degradation: Who, with a heart in his breast, could
        have stayed his hand as lie drew the dim lines of the Old
        man's countenance-unmajestic once, indeed, but at least
        sanctified by the solemnities of death-could have stayed
        his hand, as he reached the bend of the grey forehead,
        and measured out the last veins of it at so much the
        zecchin ?</p>
<p>I do not think the reader, if he has feeling, will
        expect that much talent should be shown in the rest of
        his work, by the sculptor of this base and senseless lie.
        The whole monument is one wearisome aggregation of that
        species of ornamental flourish, which, when it is done
        with a pen, is called pernamship and when done with a
        chisel, should be called chiselmanship ; the subject of
        it being chiefly fat-limbed boys sprawling on dolphins,
        dolphins incapable of swimming, and dragged along the sea
        by expanded pocket-handkerchiefs.</p>
<p>THE QUARRY. 43</p>
<p>But now, reader, comes the very gist and point of the
        whole matter. This lying monument to a dishonored doge,
        this culminating pride of the Renaissance art of Venice,
        is at least veracious, if in' nothing else, in a
        testimony to the character of its sculptor. He was
        banished from Venice for forgery in 1487.*</p>
<p>§ xliv. I have more to say about this convict's work
        hereafter; but I pass at present, to the second,
        slighter, but yet more interesting piece of evidence,
        which I promised.</p>
<p>The ducal palace has two principal facades ; one
        towards the sea, the other towards the Piazzetta. The
        seaward side, and, as far as the seventh main arch
        inclusive, the Piazzetta side, is work of the early part
        of the fourteenth century, some of it perhaps even
        earlier; while the rest of the Piazzetta side is of the
        fifteenth. The difference in age has been gravely
        disputed by the Venetian antiquaries, who have examined
        many documents on the subject, and quoted some -which
        they never examined. I have myself collated most of the
        written documents, and one document more, to which the
        Venetian antiquaries never thought of referring,-the
        masonary of the palace itself.</p>
<p>§ xlv. That masonry changes at the centre of the
        eighth arch from the sea angle on the Piazzetta side. It
        has been of comparatively small stones up to that point ;
        the fifteenth century work instantly begins with larger
        stones, "brought from Istria, a hundred miles
        away." The ninth shaft from the sea in the lower
        arcade, and the seventeenth, which is above it, in the
        upper arcade, commence the series of fifteenth century
        shafts. These two are somewhat thicker than the others,
        and carry the party-wall of the Sala del Scrutinio. Now
        observe' reader. The face of the palace, from this point
        to the Porta della Carta' was built at the instance of
        that noble Doge Mocenigo beside whose tomb yon have been
        standing ; at his instance, and in the beginning of the
        reign of his successor' Foscari ; that is to say, circa
        1424. This is not disputed ; it is only disputed that the
        sea facade is earlier;</p>
<p>Selvatico, p. 221.<br/>
        The older work is of Istrian stone also, but of different
        quality</p>
<p>of which, however, the proofs are as simple as they
        are incontrovertible : for not only the masonry, but the
        sculpture, changes at the ninth lower shaft, and that in
        the capitals of the shafts both of the upper and lower
        arcade : the costumes of the figures introduced in the
        sea facade being purely Giottesque, correspondent with
        Giotto's work in the Arena Chapel at Padua, while the
        costume on the other capitals is Renaissance-Classic :
        and the lions' heads between the arches change at the
        same point. And there are a multitude of other evidences
        in the statues of the angels, with which I shall not at
        present trouble the reader.</p>
<p>§ xlvi. Now, the architect who built under Foscari,
        in 1424 (remember my date for the decline of Venice,
        1418), was obliged to follow the principal forms of the
        older palace. But lie had not the wit to invent new
        capitals in the same style ; he therefore clumsily copied
        the old ones. The palace has seventeen main arches on the
        sea facade eighteen on the Piazzetta side, which in all
        are of course carried by thirty-six pillars ; and these
        pillars I shall always number from right to left, from
        the angle of the palace at the Ponte della Paglia to that
        next the Porta della Carta. I number them in this
        succession, because I thus have the earliest shafts first
        numbered. So counted, the 1st, the 18th, and the 36th,
        are the great supports of the angles of the palace ; and
        the first of the fifteenth century series, being, as
        above stated, the 9th from the sea on the Piazzetta side,
        is the 26th of the entire series, and will always in
        future be so numbered, so that all numbers above
        twenty-six indicate fifteenth century work, and all below
        it, fourteenth century, with some exceptional cases of
        restoration.</p>
<p>Then the copied capitals are : the 28th, copied from
        the 7th ; the 29th, from the 9th ; the 30th, from the
        10th ; the 31st, from the 8th ; the 33d, from the 12th ;
        and the 34th, from the 11th; the others being dull
        inventions of the 15th century, except the 36th, which is
        very nobly designed.</p>
<p>§ xlvii. The capitals thus selected from the earlier
        portion 'of the palace for imitation, together with the
        rest, will be accurately described hereafter ; the point
        I have here to notice is in the copy of the ninth
        capital, which was decorated (being, like the rest,
        octagonal) with figures of the eight Virtues :-Faith,
        Hope, Charity, Justice, Temperance, Prudence, Humility
        (the Venetian antiquaries call it Humanity !), and
        Fortitude, The Virtues of the fourteenth century are
        somewhat hard-featured ; with vivid and living
        expression, and plain every-day clothes of the time.
        Charity has her lap full of apples (perhaps loaves), and
        is giving one to a little child, who stretches his arm
        for it across a gap in the leafage of the capital.
        Fortitude tears open a lion's jaws; Faith lays her hand
        on her breast, as she beholds the Cross ; and Hope is
        praying, while above her a hand is seen emerging from
        sunbeams-the hand of God (according to that of
        Revelations, " The Lord God giveth them light and
        the inscription above is, " Spes optima in
        Deo."</p>
<p>§ xlviii. This design, thong is, rudely and with
        imperfect chiselling' imitated by the fifteenth century
        workmen : the Virtues have lost their hard features and
        living expression; they have now all got Roman noses, and
        have had their hair curled. Their actions and emblems
        are, however, preserved until we come to Hope : she is
        still praying, but she is praying to the sun only: The
        hand of God is gone.</p>
<p>Is not this a curious and striking type of the spirit
        which had then become dominant in the world, forgetting
        to see God's hand in the light He gave ; so that in the
        issue, when that light opened into the Reformation on the
        one side, and into full knowledge of ancient literature
        on the other, the one was arrested and the other
        perverted ?</p>
<p>§ xlix. Such is the nature of the accidental evidence
        on which I shall depend for the proof of the inferiority
        of character in the Renaissance workmen. But the proof of
        the inferiority of the work itself is not so easy, for in
        this I have to appeal to judgments which the Renaissance
        work has itself distorted. I felt this difficulty very
        forcibly as I read a slight review of my former work'
        " The Seven Lamps," in " The Architect :
        " the writer noticed my constant praise of St.
        Mark's: "Mr. Ruskin thinks it a very beautiful
        building ! We," said the Architect, " think it
        a very ugly building." I was not surprised at the
        difference of opinion, but at the thing being consided so
        completely a subject of opinion. My opponents in matters
        of painting always assume that there is such a thing as a
        law of right, and that I do not understand it, but my
        architectual adversaries appeal to no law, they simply
        set their opinion against mine ; and indeed there is no
        law at present. to which either they or I can appeal. No
        man can speak with rational decision of the merits or
        demerits of buildings : he may with obstinacy ; he may
        with resolved adherence to previous prejudices ; but
        never as if the matter could be otherwise decided than by
        a majority of votes, or pertinacity of partizanship. I
        had always, however, a clear conviction that there was a
        law in this matter : that good architecture might be
        indisputably discerned and divided from the bad ; that
        the opposition in their very nature and essence was
        clearly visible and that we were all of us just as unwise
        in disputing about the matter without reference to
        principle, as we should be for debating about the
        genuineness of a coin, without ringing it. 1 felt also
        assured that this law must be universal if it were
        conclusive ; that it must enable us to reject all foolish
        and base work, and to accept all noble and wise work,
        without reference to style or national feeling ; that it
        must sanction the design of all truly great nations and
        times, Gothic or Greek or Arab .. that it must cast of
        and reprobate the design of all foolish nations and
        times, Chinese or Mexican, or modern European., and that
        it must be easily applicable to all possible
        architectural inventions of human mind. I set myself,
        therefore, to establish such a law, in full belief that
        men are intended, with. out excessive difficulty, and by
        use of their general common sense, to know good things
        from bad ; and that it is only be. cause they will not be
        at the pains required for the discernment, that the world
        is so widely encumbered with forgeries and basenesses. I
        found the work simpler than I had hoped; the reasonable
        things ranged themselves in the order I required, and the
        foolish things fell aside, and took themselves away so
        soon as they were looked in the face. I had then with
        respect to Venetian architecture' the choice, either to
        establish each division of law in a separate form, as I
        came to the features with which it was concerned, or else
        to ask the reader's patience, while I followed out the
        general inquiry first, and determined with him a code of
        right and wrong, to which we might together make
        retrospective appeal. I thought this the best, though
        perhaps the dullest way; and in these first following
        pages I have therefore endeavored to arrange those
        foundations of criticism, on which I shall rest in my
        account of Venetian architecture, in a form clear and
        simple enough to be intelligible even to those who never
        thought of architecture before. To those who have, much
        of what is slated in them will be well known or
        self-evident; but they must not be indignant at a
        simplicity on which the whole argument depends for its
        usefulness. From that which appears a mere truism when
        first stated, they will find very singular consequences
        sometimes following'-consequences altogether unexpected,
        and of considerable importance ; I will not pause here to
        dwell on their importance, nor on that of the thing
        itself to be done; for I believe most readers will at
        once admit the value of a criterion of right and wrong in
        so practical and costly an art as architecture, and will
        be apt rather to doubt the possibility of its attainment
        than dispute its usefulness if attained. I invite them,
        therefore, to a fair trial, being certain that even if I
        should fail in my main purpose, and be unable to induce
        in my reader the confidence of judgment I desire, I shall
        at least receive his thanks for the suggestion of
        consistent reasons, which may determine hesitating
        choice, or justify involuntary preference. And if I
        should succeed' as I hope, in making the Stones of Venice
        touchstones, and detecting, by the mouldering of her
        marble, poison more subtle than ever was betrayed by the
        rending of her crystal ; and if thus I am enabled to show
        the baseness of the schools of architecture and nearly
        every other art, which have for three centuries been
        predominant in Europe, I believe the result of the
        inquiry may be serviceable for proof of a more vital
        truth than any at which I have hitherto hinted. For
        observe : I said. the Protestant had despised the arts'
        and the Rationalist corrupted them. Bat what has the
        Romanist done meanwhile ? He boasts that it Was the
        papacy which raised the arts ; why could it not support
        them when it was left to its own strength? How came it to
        yield to Classicalism which was based on infidelity, and
        to oppose no barrier to innovations, which have reduced
        the once faithfully conceived imagery of its worship to
        stage decoration? Shall we not rather find that Romanism,
        instead of being a promoter of the arts, has never shown
        itself capable of a single great conception since the
        separation of Protestantism from its side ? * So long as,
        corrupt though it might be, no clear witness had been
        borne against it, so that it still included in its ranks
        a vast number of faithful Christians, so long its arts
        were noble. But the witness was borne-the error made
        apparent ; and Rome refusing to hear the testimony or
        forsake the falsehood, has been struck from that instant
        with an intellectual palsy, which has not only
        incapacitated her from any further use of the arts which
        once were her ministers, but has made her worship the
        shame of its own shrines, and her worshippers their
        destroyers. Come, then, if truths such as these are worth
        our thoughts; come, and let us know, before we enter the
        streets of the Sea city, whether we are indeed to submit
        ourselves to their undistinguished enchantment, and to
        look upon the last changes which were wrought on the
        lifted forms of her palaces, as we should on the
        capricious towering of summer clouds in the sunset, ere
        they sank into the deep of night ; or whether, rather, we
        shall not behold in the brightness of their accumulated
        marble, pages on which the sentence of her luxury was to
        be written until the waves should efface it, as they
        fulfilled-" God has numbered thy kingdom, and
        finished it."</p>
</td>
</tr>
<tr>
<td><font>Ruskin,
        John.<em> The Stones of Venice. </em>Vol 1, chapter 1 -
        "The Quarry<em>". </em>p. 1-48</font></td>
</tr>
</table>
</center></div>
`,s=`The Stones of Venice from vol. I: Chapter 1: "The Quarry" John Ruskin Ruskin, John. The Stones of Venice. Vol 1, chapter 1 - "The Quarry ". p. 1-48 § i. SINCE the first dominion of man was asserted over the ocean, three thrones, of mark beyond all others, have, been set upon its sands: the thrones of Tyre, Venice, and England. Of the First of these great powers only the memory remains; of the Second, the ruin ; the Third, which inherits their greatness, if it forget their example, may be led through prouder eminence to less pitied destruction. The exaltation, the, sin, and the punishment of Tyre have been recorded for us, in perhaps the most touching words ever uttered by the Prophets of Israel against the cities of the stranger. But we read them as a lovely song; and close our cars to the sternness of their warning : for the very depth of the Fall of Tyre has blinded us to its reality, and we forget, as we watch the bleaching of the rocks between the sunshine and the sea, that they were once " as in Eden, the garden of God." Her successor, like her in perfection of beauty, though less in endurance of dominion, is still left for our beholding in the final period of her decline: a ghost upon the sands of the sea, so weak-so quiet,-so bereft of all but her loveliness, that we might well doubt, as we watched her faint reflection in the mirage of the lagoon, which was the City, and which the Shadow. I would endeavor to trace the lines of this image before it be for ever lost, and to record, as far as I may, the warning which seems to me to be uttered by every one of the fast gaining waves, that beat, Eke passing bells, against the Stones of Venice. § ii. It would be difficult to overrate the value of the lessons which might be derived from a faithful study of the history of this strange and mighty city: a history which, in spite of the labor of countless chroniclers, remains in vague and disputable outline,-barred with brightness and shade, like the far away edge of her own ocean, where the surf and the sandbank are mingled with the sky. The inquiries in which we have to engage will hardly render this outline clearer, but their results will, in some degree, alter its aspect; and, so far as they bear upon it at all, they possess an interest of a far higher kind than that usually belonging to architectural investigations. I may, perhaps, in the outset, and in few words, ,enable the general reader to form a clearer idea of the importance of every existing expression of Venetian character through Venetian art, and of the breadth of interest which the true history of Venice embraces, than be is likely to have gleaned from the current fables of her mystery or magnificence. § iii. Venice is usually conceived as an oligarchy : She was so during a period less than the half of her existence, and that including the days of her decline ; and it is one of the first questions needing severe examination, whether that decline was owing in any wise to the change in the form of her government, or altogether, as assuredly in great part, to changes, in the character of the persons of whom it was composed. The state of Venice existed Thirteen Hundred and Seventy-six years, from the first establishment of a consular government on the island of the Rialto,* to the moment when the General-in-chief of the French army of Italy pronounced the Venetian republic a thing of the past. Of this period, Two Hundred and Seventy-six I years were passed in a nominal subjection to the cities of old Venetia, especially to Padua, and in an agitated form of democracy, of which the executive appears to have been entrusted to tribunes,!! chosen, one by the inhab * Appendix 1, ' Foundation of Venice." I Appendix 2, " Power of the Doges." !! Sismondi, Hist. des Rép. Ital. ~ vol. i.. ch. v, itants of each of the principal islands. For six hundred years,* during which the power of Venice was continually on the increase, her government was an elective monarchy, her King or doge possessing, in early times at least, as much independent authority as any other European sovereign, but an authority gradually subjected to limitation, and shortened almost daily of its prerogatives, while it increased in a spectral and incapable magnificence. The final government of the nobles, under the image of a king, lasted for five hundred years, during which Venice reaped the fruits of her former energies, consumed them,-and expired. § iv. Let the reader therefore conceive the existence of the Venetian state as broadly divided into two periods : the first of nine hundred, the second of five hundred years, the separation being marked by what was called the " Serrar del Consiglio ; " that is to say, the final and absolute distinction of the nobles from the commonalty, and the establishment of the government in their hands to the exclusion alike of the influence of the people on the one side, and the authority of the Doge on the other. Then the first period, of nine hundred years, presents us with the most interesting spectacle of a people struggling out 'of anarchy into order and power ; and then governed, for the most part, by the worthiest and noblest man whom they could find among them,! called their Doge or Leader' with an aristocracy gradually and resolutely forming itself around him, out of which, and at last by which, he was chosen; an aristocracy owing its origin to the accidental numbers, influence, and wealth of some among the families of the fugitives from the older Venetia, and gradually organizing itself. by its unity and heroism, into a separate body. This first period includes the rise of Venice her noblest achievements, and the circumstances which determined her character and position among European powers; and within * Appendix 3, " Serrar del Consiglio. " 1 " Ha saputo trovar modo che non uno' non pochi' non molti' signo- reggiano, ma molti buoni, pochi migliori, e insiemeniente, un ottime solo." Ah, well done, Venice ! Wisdom this, indeed. its range, as might have been anticipated, we find the names of all. her hero princes,-of Pietro Urseolo, Ordalafo Falier, Domenico Michieli, Sebastiano Ziani, and Enrico Dandolo. § v. The second period opens with a hundred and twenty years, the most eventful in the career of Venice-the central struggle of her life-stained with her darkest crime, the murder of Carrara-disturbed by her most dangerous internal sedition, the conspiracy of Falier-oppressed by her most fatal wax, the war of Chiozza-and distinguished by the glory of her two noblest citizens (for in this period the heroism of her citizens replaces that of her monarchs), Vittor Pisani and Carlo Zeno. I date the commencement of the fall of Venice from the death of Carlo Zeno, 8th May 1418 * the visible commencement from that of another oiler noblest and wisest children, the Doge Tomaso Mocenigo, who expired five years later. The reign of Foscari followed, gloomy with pestilence and war; a war in which large acquisitions of territory were made by subtle or fortunate policy in Lombardy, and disgrace, significant as irreparable, sustained in the battles on the Po at Cremona, and in the marshes of Caravaggio. In 1454, Venice, the first of the states of Christendom, humiliated herself to the Turk: in the same year was established the Inquisition of State,! and from this period her government takes the perfidious and mysterious form under which it is usually conceived. In 1477, the great Turkish invasion spread terror to the shores of the lagoons ; and in 1508 the league of Cambrai marks the period usually assigned as the commencement of the decline of the Venetian power; I the commercial prosperity of Venice in the close of the fifteenth century blinding her historians to the previous evidence of the diminution of her internal strength. * Daru, liv. xii. ch. xii. !Daru, liv. xvi. cap. xx. We owe to this historian the discovery of the statutes of the tribunal and date of its establishment. !!Ominously signified by their humiliation to the Papal power (as before to the Turkish) in 1509' and their abandonment of their right of appointing the clergy of their territories. § vi. Now there is apparently a significative coincidence between the establishment of the aristocratic and oligarchical powers, and the diminution of the prosperity of the state. But this is the very question at issue; and it appears to me quite undetermined by any historian, or determined by each in accordance with his own prejudices. It is a triple question : first, whether the oligarchy established by the efforts of individual ambition was the cause, in its subsequent operation, of the Fall of Venice ; or (secondly) whether the establishment of the oligarchy itself be not the sign and evidence rather than the cause, of national enervation ; or (lastly) whether, as I rather think, the history of Venice might not be written almost without reference to the construction of her senate or the prerogatives of her Doge. It is the history of a people eminently at unity in itself, descendants of Roman race, long disciplined by adversity, and compelled by its position either to live nobly or to perish :-for a thousand years they fought for life ; for three hundred they invited death: their battle was rewarded, and their call was heard. § vii. Throughout her career, the victories of Venice, and, at many periods of it, her safety, were purchased by individual heroism ; and the man who exalted or saved her was sometimes (oftenest) her king, sometimes a noble, sometimes a citizen. To him no matter, nor to her: the real question is, not so much what names they bore' or with what powers they were entrusted, as how they were trained; how they were made masters of themselves, servants of their country, patient of distress, impatient of dishonor; and what was the true reason of the change from the time when she could find saviours among those whom she had cast into prison' to that when the voices of her own children commanded her to sign convenant with Death.* § viii. On this collateral question I wish the reader's mind to be fixed throughout all our subsequent inquiries. It will give double interest to every detail : nor will the interest be profitless ; for the evidence which I shall be able to deduce * The senate voted the abdication of their authority by a majority of 612 to 14. (Alison, ch, xxiii.) from the arts of Venice will be both frequent and irrefragable, that the decline of her political prosperity was exactly coincident with that of domestic and individual religion. I say domestic and individual ; for-and this is the second point which I wish the reader to keep in mind-the most curious phenomenon in all Venetian history is the vitality of religion in private life, and its deadness in public policy. Amidst the. enthusiasm, chivalry, or fanaticism of the other states of Europe, Venice stands, from first to last, like a masked statue ; her coldness impenetrable' her exertion only aroused by the touch of a secret spring. . That spring was her commercial interest,-this the one motive of all her important political acts, or enduring national animosities. She could forgive insults to her honor, but never rivalship in her commerce ; she calculated the glory of her conquests by their value, and estimated their justice by their facility. The fame of success remains, when the motives of attempt are forgotten ; and the casual reader of her history may perhaps be surprised to be reminded, that the expedition which was commanded by the noblest of her princes, and whose results added most to her military glory, was one in which while all Europe around her was wasted by the fire of its devotion, she first calculated the highest price she could exact from its piety for the armament she furnished, and then, for the advancement of her own private interests, at once broke her faith * and betrayed her religion. § ix. And yet, in the midst of this national criminality, we shall be struck again and again by the evidences of the most noble individual feeling. The tears of Dandolo were not shed in hypocrisy, though they could not blind him to the importance of the conquest of Zara. The habit of assigning to religion a direct influence over all his own actions, and all the affairs of his own daily life, is remarkable in every great Venetian during the times of the prosperity of the state ; nor are instances wanting in which the private feeling of the citizens * By directing the arms of the Crusaders against a Christian prince Daru, liv. iv. ch. iv. viii.) reaches the sphere of their policy, and even becomes the guide of its course where the scales of expediency are doubtfully balanced. I sincerely trust that the inquirer would be disap- pointed who should endeavor to trace any more immediate reasons for their adoption of the cause of Alexander III against Barbarossa, than the piety which was excited by the character of their suppliant, and the noble pride which was provoked by the insolence of the emperor. But the heart of Venice is shown only in her hastiest councils; her worldly spirit recovers the ascendency whenever she has time to calculate the probabilities of advantage, or when they are sufficiently distinct to need no calculation ; and the entire subjection of private piety to national policy is not only remarkable throughout the almost endless series of tra and tyrannies by which her empire was enlarged and maintained, but symbolised by a very singular circumstance in the building of the city itself. I am aware of no other city of Europe in which its cathedral was not the principal feature. But the principal church in Venice was the chapel attached to the palace of her prince, and called the " Chiesa Ducale." The patriarchal church'* inconsiderable in size and mean in decoration, stands on the outermost islet of the Venetian group, and its name, as well as its site, is probably unknown to the greater number of travellers passing hastily through the city. Nor is it less worthy of remark, that the two most important temples of Venice, next to the ducal chapel, owe their size and magnificence, not to national effort, but to the energy of the Franciscan and Dominican monks, supported by the vast organization of those great societies on the mainland of Italy, and countenanced by the most pious, and perhaps also, in his generation, the most wise, of all the princes of Venice! who now rests beneath the roof of one of those very temples' and whose life is not satirized by the images of the Virtues which a Tuscan sculptor has placed around his tomb. § x. There are, therefore, two strange and solemn lights * Appendix 4, " San Pietro di Castello.' ! Tomaso Mocenigo, above named, § v. in which we have to regard almost every scene in the fitful history of the Rivo Alto. We find, on the one hand, a deep and constant tone of individual religion characterising the lives of the citizens of Venice in her greatness ; we find this spirit influencing them in all the familiar and immediate concerns of life, giving a peculiar dignity to the conduct even of their commercial transactions, and confessed by them with a simplicity of faith that may well put to shame the hesitation with which a man of the world at present admits (even if it be so in reality) that religious feeling has any influence over the minor branches of his conduct. And we find as the natural. consequence of all this, a healthy serenity of mind and energy of will expressed in all their actions, and a habit of heroism which never fails them' even when the immediate motive of action ceases to be praiseworthy. With the fulness of this spirit the prosperity of the state is exactly correspondent, and with its failure her decline, and that with a closeness and precision which it will be one of the collateral objects of the following essay to demonstrate from such accidental evidence as the field of its inquiry presents. And, thus far, all is natural and simple. But the stopping short of this religious faith when it appears likely to influence national action, correspondent as it is, and that most strikingly, with several characteristics of the temper of our present English legislature, is a subject, morally and politically, of the most curious interest and complicated difficulty ; one, however, which the range of my present inquiry will not permit me to preach, and for the treatment of which 1 must be content to furnish materials in the light I may be able to throw upon the private tendencies of the Venetian character. § xi. There is, however, another most interesting feature in the policy of Venice which will be often brought before us; and which a Romanist would gladly assign as the reason of its irreligion; namely, the magnificent and successful struggle which she maintained against the temporal authority of the Church of Rome. It is true that, in a rapid survey of her career, the eye is at first arrested by the strange drama to which I have already alluded, closed by that ever memorable scene in the portico of St Mark's,* the central expression in most men's thoughts of the unendurable elevation of the pontifical power; it is true that the proudest thoughts of Venice, as well as the insignia of her prince, and the form of her chief festival, recorded the service thus rendered to the Roman Church. But the enduring sentiment of years more than balanced the enthusiasm of a moment ; and the bull of Clement V., which excommunicated the Venetians and their doge, likening them to Dathan, Abiram, Absalom, and Lucifer, is a stronger evidence of the great tendencies of the Venetian government than the umbrella of the doge or the ring of the Adriatic. The humiliation of Francesco Dandolo blotted out the shame of Barbarossa, and the total exclusion of ecclesiastics from all share in the councils of Venice became an enduring mark of her knowledge of the spirit of the Church of Rome, and of her defiance of it. To this exclusion of Papal influence from her councils, the Romanist will attribute their irreligion, and the Protestant their success.! The first may be silenced by a reference to the character of the policy of the Vatican itself ; and the second by his own shame, when he reflects that the English legislature sacrificed their principles to expose themselves to the very danger which the Venetian senate sacrificed theirs to avoid. § xii. One more circumstance remains to be noted respecting the Venetian government, the singular unity of the families composing it,--unity far from sincere or perfect, but still In that temple porch, (The brass is gone' the porphyry remains,) Did BARBAROSSA fling his mantle off, And kneeling, oil his neck receive the foot Of the proud Pontiff-thus at last consoled For flight, disguise, and many ail aguish shake On his stone pillow." I need hardly say whence the lines are taken: Rogers' " Italy " has, I believe, now a place in the best beloved compartment of all libraries, and will never be removed from it. There is more true expression of the spirit of Venice in the passages devoted to her in that poem, than in all else that has been written of her. ! At least, such success as they had. Vide Appendix 5, II The Papal Power in Venice. 91 admirable when contrasted with the fiery feuds, the almost daily revolutions, the restless successions of families and parties in power, which fill the annals of the other states of Italy. That rivalship should sometimes be ended by the dagger' or enmity conducted to its ends under the mask of law, could not but be anticipated where the fierce Italian spirit was subjected to so severe a restraint: it is much that jealousy appears usually unmingled with illegitimate ambition, and that, for every instance in which private passion sought its gratification through public danger, there are a thousand in which it was sacrificed to the public advantage. Venice may well call upon us to note with reverence that of all the towers which are still seen rising like a branchless forest from her islands, there is but one whose office was other than that of summoning to prayer, and that one was a watch-tower only: from first to last, while the palaces of the other cities of Italy were lifted into sullen fortitudes of rampart, and fringed with forked battlements for the javelin and the bow, the sands of Venice never sank under the weight of a war tower, and her roof terraces were wreathed with Arabian imagery, of golden globes suspended on the leaves of lilies.* § xiii. These, then, appear to me to be the points of chief general interest in the character and fate of the Venetian people. I would next endeavor to give the reader some idea of the manner in which the testimony of Art bears upon these questions, and of the aspect which the arts themselves assume when they are regarded in their true connexion with the history of the state. 1st. Receive the witness of Painting. It will be remembered that I put the commencement of the Fall of Venice as far back as 1418. Now, John Bellini was born in 1423, and Titian in 1480. John Bellini, and his brother Gentile, two years older than he, close the line of the sacred painters of Venice. But the most solemn spirit of religious faith animates their works to the * The inconsiderable fortifications of the arsenal are no exception to this statement as fax as it regards the city itself. They are little more than a semblance of precaution against the attack of a foreign enemy last There is no religion in any work of Titian's : there is not even the smallest evidence of religious temper or sympathies either in himself, or in those for whom he painted. His larger sacred subjects are merely themes for the exhibition of pictorial rhetoric,-composition and color. His minor works .are generally made subordinate to purposes of portraiture, The Madonna in the church of the Frari is a mere lay figure, introduced to form a link of connexion between the portraits of various members of the Pesaro family who surround her. Now this is not merely because John Bellini was a religious man and Titian was not. Titian and Bellini are each true representatives of the school of painters contemporary with them; and the difference in their artistic feeling is a consequence not so much of difference in their own natural characters as in their early education : Bellini was brought up in faith; Titian in formalism. Between the years of their births the vital religion of Venice had expired. § xiv. The vital religion, observe, not the formal. Outward observance was as strict as ever; and doge and senator still were painted, in almost every important instance, kneeling before the Madonna or St. Mark; a confession of faith made universal by the pure gold of the Venetian sequin. But ob. serve the great picture of Titian's in the ducal palace, of the Doge Antonio Grimani kneeling before Faith : there is a curious lesson in it. The figure of Faith is a coarse portrait of one of Titian's least graceful female models : Faith bad become carnal The eye is first caught by the flash of the Doge's armor. The heart of Venice was in her wars, not in her worship. The mind of Tintoret, incomparably more deep and serious than that of Titian, casts the solemnity of its own tone over the sacred subjects which it approaches, and sometimes forgets itself into devotion ; but the principle of treatment is altogether the same as Titian's: absolute subordination of the religious subject to purposes of decoration or portraiture. The evidence might be accumulated a thousandfold from the works of Veronese, and of every succeeding painter,-that the fifteenth century had taken away the religious heart of Venice. § xv. Such is the evidence of Painting. To collect that of Architecture will be our task through many a page to come; but I must here give a general idea of its heads. Philippe de Commynes, writing of his entry into Venice in 1495, says,-- "Chascun me feit seoir au meillieu de ces deux ambassadeurs qui est l'honneur d'ltalie que d'estre au meillieu; et me menerent au long de la grant rue, qu'ilz appellent le Canal Grant, et est bien large. Les gallees y passent à travers et y ay Yeu na-vire de quatre cens tonneaux ou plus pres des maisons : et est la plus belle rue que je croy qui soit en tout le monde, et la mieulx maisonnee, et va le -long de la ville. Les maisons sont fort grandes et haultes, et de bonne pierre, et les anciennes toutes painctes ; les aultres faictes depuis cent ans : toutes ont le devant de marbre blanc, qui leur vient d'Istrie, à cent mils de là, et encores maincte grant piece de porphire et de sarpentine sur le devant. . . . C'est la plus triumphante cité que j'aye jamais veue et qui plus faict d'honneur àambassadeurs et estrangiers, et qui plus saigement se gouverne, et où le service de Dieu est le plus sollempellement faict : et encores qu'il y peust bien avoir d'aultres faultes, si je croy que Dieu les a en ayde pour Ia. reverence qu'ilz portent au service de l'Eglise." * § xvi. This passage is of peculiar interest, for two reasons, Observe, first' the impression of Commynes respecting the religion of Venice: of which, as I have above said, the forms still remained with some glimmering of life in them, and were the evidence of what the real life had been in former times. But observe, secondly, the impression instantly made on Commynes' mind by the distinction between the older palaces and those built "within this last hundred years; which all have their fronts of white marble brought from Istria, a hundred miles away, and besides, many a large piece of porphyry and serpentine upon their fronts." On the opposite page I have given two of the ornaments of * Mémoires -de Commynes, liv. vii. ch. xviii. the palaces which so struck the French ambassador.* He was right in his notice of the distinction. There had indeed come a change over Venetian architecture in the fifteenth century ; and a change , of some importance to us moderns: we English owe to it our St. Paul's Cathedral, and Europe in general owes to it the utter degradation or destruction of her schools of architecture, never since revived. But that the reader may understand this, it is necessary that he should have some general idea of the connexion of the architecture of Venice with that of the rest of Europe, from its origin forwards. § xvii. All European architecture, bad and good, old and new, is derived from Greece through Rome, and colored and perfected from the Fast. The history of architecture is nothing but the tracing of the various modes and directions of this derivation. Understand this, once for all: if you hold fast this great connecting clue, you may string all the types of successive architectural invention upon it like so many beads. The Doric and the Corinthian orders are the roots the one of all Romanesque, massy-capifaled buildings-Norman, Lombard, Byzantine, and what else you can name of the kind; and the Corinthian of all Gothic, Early English, French, German, and Tuscan. Now observe: those old Greeks gave the shaft ; Rome gave the arch; the Arabs pointed and foliated the arch. The shaft and arch, the frame-work and strength of architecture, are from the race of Japeth ; the spirituality and sanctity of it from Ismael, Abraham, and Shem. § xviii. There is high probability that the Greek received his shaft system from Egypt ; but I do not care to keep this earlier derivation in the mind of the reader. It is only necessary that he should be able to refer to a fixed point of origin, when the form of the shaft was first perfected. But it may be incidentally observed, that if the Greeks did indeed receive their Doric from Egypt' then the three families of the earth have each contributed their part to its noblest architecture; and Ham, the servant of the others, furnishes the sustaining * Appendix 6, 'Renaissance Ornaments." or bearing member, the shaft; Japheth the arch; Shem the spiritualisation of both. § xix. 1 have said that the two orders, Doric and Corinthian, are the roots of all European architecture. You have' perhaps heard of five orders - but there are only two real orders, and there never can be any more until doomsday. On one of these orders the ornament is convex : those are Doric, Norman, and what else you recollect of the kind On the other the ornament is concave : those are Corinthian, Early English, Decorated, and what else you recollect of that kind. The transitional form, in which the ornamental line is straight, is the centre or root of both. All other orders are varieties oil those, or phantasms and grotesques altogether indefinite in number and species.* § xx. This Greek architecture, then, with its two orders, was clumsily copied and varied by the Romans with no particular result, until they begun to bring the arch into extensive practical service ; except only that the Doric capital was spoiled in endeavors to mend it, and the Corinthian much varied and enriched with fanciful, and often very beautiful imagery. And in this state of things came Christianity : seized upon the arch as her own ; decorated it, a-ad delighted in it; invented a new Doric capital to replace the spoiled Roman one: and all over the Roman empire set to work, with such materials as were nearest at hand, to express and adorn herself as best she could. This Roman Christian architecture is the exact expression of the Christianity of the time, very fervid and beautiful-but very imperfect; in many respects ignorant' and yet radiant with a strong, childlike light of imagination, which flames up under Constantine, illumines all the shores of the Bosphorus and the Eagean and the Adriatic Sea, and then gradually, as the people give themselves up to idolatry, becomes Corpse-light. The architecture sinks into a settled form-a strange, gilded' and embalmed repose : it, with the religion it expressed; and so would have remained for ever,-so does remain, where its I Appendix 7, "Varieties of the Orders." languor has been undisturbed.* But rough wakening was ordained for it. § xxi. This Christian art of the declining empire is divided into two great branches, western and eastern ; one centred at Rome, the other at Byzantium, of which the one is the early Christian Romanesque, properly so called, and the other, carried to higher imaginative perfection by Greek workmen, is distinguished from it as Byzantine. But I wish the reader, for the present, to class these two branches of art together in his mind, they being, in points of main importance, the same; that is to say, both of them a true continuance and sequence of the art of old Rome itself, flowing uninterruptedly down from the fountain-head, and entrusted always to the best workmen who could be found-Latins in Italy and Greeks in Greece ; and thus both branches may be ranged under the general term of Christian Romanesque, an architecture which had lost the refinement of Pagan art in the degradation of the empire, but which was elevated by Christianity to higher aims, and by the fancy of the Greek workmen endowed with brighter forms. And this art the reader may conceive as extending in its various branches over all the central provinces of the empire, taking aspects more or less refined, according to its proximity to the seats of government ; dependent for all its power on the 'vigor and freshness of the religion which animated it ; and as that vigor and purity departed, losing its own vitality, and sinking into nerveless rest, not deprived of its beauty, but benumbed and incapable of advance or change. § xxii. Meantime there had been preparation for its renewal, While in Rome and Constantinople, and in the districts under their immediate influence' this Roman art of pure descent was practised in all its refinement, an impure form of it-a patois of Romanesque-was carried by inferior workmen into distant provinces ; and still ruder imitations of this patois were executed by the barbarous nations on the * The reader will find the weak points of Byzantine architecture Shrewdly seized' and exquisitely sketched, in the opening chapter of the most delightful book of travels I ever opened,-Curzon's " Monasteries of the Levant" skirts of the empire. But these barbarous nations were in the strength of their youth; and while, in the centre of Europe, a refined and purely descended art was sinking into graceful formalism, on its confines a barbarous and borrowed art was organising itself into strength and consistency. The reader must therefore consider the history of the work of the period as broadly divided into two great heads: the one embracing the elaborately languid succession of the Christian art of Rome ; and the other, the imitations of it executed by nations in every conceivable phase of early organisation, on the edges of the empire, or included in its now merely nominal extent. § xxiii. Some of the barbaric nations were, of course, not susceptible of this influence; and when they burst over the Alps, appear, like the Huns, as scourges only, or mix, as the Ostrogoths, with the enervated Italians, and give physical strength to the mass with which they mingle, without materially affecting its intellectual character. But others, both south and north of the empire, had felt its influence, back to the beach of the Indian Ocean on the one hand, and to the ice creeks of the North Sea on the other. On the north and west the influence was of the Latins ; on the south and east, of the Greeks. Two nations, pre-eminent above all the rest, represent to us the force of derived mind on either side. As the central power is eclipsed, the orbs of reflected light gather into their fulness; and when sensuality and idolatry bad done their work, and the religion of the empire was laid asleep in a glittering sepulchre, the living light rose upon both horizons, and the fierce swords of the Lombard and Arab were shaken over its golden paralysis. § xxiv. The work of the Lombard was to give hardihood and system to the enervated body and enfeebled mind of Christendom ; that of the Arab was to punish idolatry, and to proclaim the spirituality of worship. The Lombard covered every church which he built with the sculptured representations of bodily exercises-bunting and war.* The Arab banished all imagination of creature form from his temples And * Appendix 8. " The Northern Energy." proclaimed from their minarets' " There is no god but God." opposite in their character and mission, alike in their magnificence of energy, they came from the North and from the South, the glacier torrent and the lava stream they met and contended over the wreck of the Roman empire and the very centre of the struggle, the point of pause of both, the dead water of the opposite eddies, charged with embayed fragments of the Roman wreck, is VENICE. The Ducal palace of Venice contains the three elements in exactly equal proportions--the Roman, Lombard, and Arab. It is the central building of the world. § xxv. The reader will now begin to understand something of the importance of the study of the edifices of a city which includes, within the circuit of some seven or eight miles, the field of contest between the three pre-eminent architectures of the world :-each architecture expressing a condition of religion ; each an erroneous condition, yet necessary to the cor. rection of the others, and corrected by them. § xxvi. It will be part of my endeavor, in the following work to mark the various modes in which the northern and southern architectures were developed from the Roman: here I must pause only to name the distinguishing characteristics of the great families. The Christian Roman and Byzantine work is round-arched, with single and well-proportioned shafts; capitals imitated from classical Roman ; mouldings more or less so; and large surfaces of walls entirely covered with imagery, mosaic, and paintings, whether of scripture history or of sacred symbols. The Arab school is at first the same in its principal features, the Byzantine workmen being employed by the caliphs; but the Arab rapidly introduces characters half Persepolitan, half Egyptian, into the shafts and capitals: in his intense love of excitement he points the arch and writhes it into extravagant foliations ; he banishes the animal imagery, and invents an ornamentation of his own (called Arabesqine) to replace it: this not being adapted for covering large surfaces, he concentrates it on features interest, and bars his surfaces , "',~ , horizontal lines of color, the expression of the level of Desert, He retains the dome, and adds the minaret. All is done with exquisite refinement. § xxvii. The changes effected by the Lombard are more curious still, for they are in the anatomy of the building, more than its decoration. The Lombard architecture represents, as 1 said, the whole of that of the northern barbaric nations And this I believe was, at first' an imitation in wood of the Christian Roman churches or basilicas. Without staying to examine the whole structure of a basilica, the reader will easily under. stand thus much of it: that it had a nave and two aisles' the nave much higher than the aisles; that the nave was separated from the aisles by rows of shafts' which supported, above, large spaces of flat or dead wall, rising above the aisles, and forming the upper part of the nave, now called the clerestory, which had a gabled wooden roof. These high dead walls were, in Roman work, built of stone; but in the wooden work of the North, they must necessarily have been made of horizontal boards or timbers attached to uprights on the top of the nave pillars, which were themselves also of wood.* Now, these uprights were necessarily thicker than the rest of the timbers, and formed vertical square pilasters above the nave piers. As Christianity extended and civilisation increased, these wooden structures were changed into stone; but they were literally petrified, retaining the form which had been made necessary by their being of wood. The upright pilaster above the nave pier remains in the stone edifice' and is the first form of the great distinctive feature of Northern architecture--the vaulting shaft. In that form the Lombards brought it into Italy, in the seventh century' and it remains to this day in St. Ambrogio of Milan, and St. Michele of Pavia. § xxviii. When the vaulting shaft was introduced in the clerestory walls, additional members were added for its sup-port to the nave piers. Perhaps two or three pine trunks used for a single pillar, gave the first idea of the grouped shaft. Be that as it may, the arrangement of the nave pier in the form of a cross accompanies the superimposition of * Appendix 9, " Wooden Churches of the North." the vaulting shaft; together with corresponding grouping of minor shafts in doorways and apertures of windows. Thus, the whole body of the Northern architecture, represented by that of the Lombards, may be described as rough but majestic work, round-arched, with grouped shafts, added vaulting shafts, and endless imagery of active life and fantastic superstitions. § xxix. The glacier stream of the Lombards, and the following one of the Normans, left their erratic blocks, wherever they had flowed; but without influencing, I think, the Southern nations beyond the sphere of their own presence. But the lava stream of the Arab, even after it ceased to flow, warmed the whole of the Northern air; and the history of Gothic architecture is the history of the refinement and spiritiualisation of Northern work under its influence. The noblest buildings of the world, the Pisan-Romanesque, Tuscan (Giottesque) Gothic, and Veronese Gothic, are those of the Loynbard schools themselves, under its close and direct influence ; the various Gothics of the North axe the original forms of the architecture which the Lombards brought into Italy, changing under the less direct influence of the Arab. § xxx. Understanding thus much of the formation of the great European styles, we shall have no difficulty in tracing the succession of architectures in Venice herself. From what I said of the central character of Venetian art, the reader is not, of course, to conclude that the Roman, Northern, and Arabian elements met together and contended for the mastery at the same period. The earliest element was the pure Christian Roman ; but few, if any, remains of this art exist at Venice ; for the present city was in the earliest times only one of many settlements formed on the chain of marshy islands which extend from the mouths of the Isonzo to those of the Adige, and it was not until the beginning of the ninth century that it became the seat of government; while the cathedral of Torcello, though Christian Roman in general form, was rebuilt in the eleventh century, and shows evidence of Byzantine workmanship in many of its details. This cathedral, however' with the church of Santa Fosca at Torcello, Vol. 1.-3 San Giacomo di Rialto at Venice, and the crypt of St. Mark's. forms a distinct group of buildings, in which the Byzantine influence is exceedingly slight ; and which is probably very sufficiently representative of the earliest architecture on the islands. § xxxi. The Ducal residence was removed to Venice in 809, and the body of St. Mark was brought from Alexandria twenty years later. The first church of St. Mark's was, doubtless, built in imitation of that destroyed at Alexandria, and from which the relies of the saint had been obtained. During the ninth, tenth, and eleventh centuries, the architecture of Venice seems to have been formed on the same model, and is almost identical with that of Cairo under the caliplis,* it being quite immaterial whether the reader chooses to call both Byzantine or both Arabic; the workmen being certainly Byzantine, but forced to the invention of new forms by their Arabian masters, and bringing these forms into use in whatever other parts of the world they were employed. To this first manner of Venetian architecture, together with such vestiges as remain of the Christian Roman, I shall devote the first division of the following inquiry. The examples remaining of it consist of three noble churches (those of Torcello, Murano, and the greater part of St. Mark's), and about ten or twelve fragments of palaces. § xxxii. To this style succeeds a transitional one, of a char- much more distinctly Arabian : the shafts become more slender, and the arches consistently pointed' instead of round; certain other changes, not to be enumerated in a sentence, taking place in the capitals and mouldings. This style is almost exclusively secular. It was natural for the Venetians to imitate the beautiful details of the Arabian dwelling-house, while they would with reluctance adopt those of the mosque for Christian churches. I have not succeeded in fixing limiting dates for this style. It appears in part contemporary with the Byzantine manner but outlives it. Its position is, however, fixed by the central date, 1180, that of the elevation of the granite shafts of the * Appendix 10, 11 Church of Alexandria." 11 Piazetta, -whose capitals are the two most important Pieces of detail in this transitional style in Venice. Examples of its application to domestic buildings exist in almost every street of the city, and will form the subject of the second division of the following essay. § xxxiiii. The Venetians were always ready to receive les- sons in art from their enemies (else had there been no Arab work in Venice). But their especial dread and hatred of the Lombards appears to have long prevented them from receiving the influence of the art which that people bad introduced on the mainland of Italy. Nevertheless, during the practice of the two styles above distinguished, a peculiar and very primitive condition of pointed Gothic bad arisen in ecclesiastical architecture. It appears to be a feeble reflection of the Lombard-Arab forms' -which were attaining perfection upon the continent, and would probably, if left to itself, have been soon merged in the Venetian-Arab school' with which it bad from the first so close a fellowship, that it will be found difficult to distinguish the Arabian gives from those which seem to have been built under this early Gothic influence. The churches of San Giacopo dell' Orio, San Giovanni in Bra- ra, the Carmine, and one or two more, furnish the only important examples of it. But, in the thirteenth century, the Franciscans and Dominicans introduced from the continent their morality and their architecture, already a distinct Gothic, curiously developed from Lombardic and Northern (German?) forms; and the influence of the principles exhibited in the vast churches of St. Paul and the Frari began rapidly to affect the 'Venetian-Arab school. Still the two systems never became united; the Venetian policy repressed the power of the church, and the Venetian artists resisted its example; and thenceforward the architecture of the city becomes divided into ecclesiastical and civil: the one an ungraceful yet powerful form of the Western Gothic, common to the whole peninsula, and only showing Venetian sympathies in the adoption of certain characteristic mouldings; the other a rich, luxuriant, and entirely original Gothic, formed from the Venetian-Arab by the influence of the Dominican and Franciscan architecture, and especially by the engrafting upon the Arab forms of the most novel feature of the Franciscan work, its traceries These various forms of Gothic, the distinctive architecture of Venice, chiefly represented by the churches of St. John and Paul, the Frari, and San Stefano, on the ecclesiastical side, and by the Ducal palace, and the other principal Gothic pal, aces, on the secular side, will be the subject of the third division of the essay. § xxxiv. Now observe. The transitional (or especially Arabic) style of the Venetian work is centralised by the date 1180, and is transformed gradually into the Gothic, which extends in its purity from the middle of the thirteenth to the beginning of the fifteenth century ; that is to say, over the precise period which I have described as the central epoch of the life of Venice. I dated her decline from the year 1418 ; Foscari became doge five years later, and in his reign the first marked signs appear in architecture of that mighty change which Philippe de Commynes notices as above, the change to which London owes St. Paul's, Rome St. Peter's, Venice and Vicenza the edifices commonly supposed to be their noblest, and Europe in general the degradation of every art she has since practised. § xxxv. This change appears first in a loss of truth and vitality in existing architecture all. over the world. (Compare " Seven Lamps, " chap. ii.). All the Gothics in existence, southern or northern, were corrupted at once: the German and French lost themselves in every species of extravagance; the English Gothic was confined, in its insanity, by a strait. waistcoat of perpendicular lines ; the Italian effloresced on the mainland into the meaningless ornamentation of the Certosa of Pavia and the Cathedral of Como (a style sometimes ignorantly called Italian Gothic), and at Venice into the insipid confusion of the Porta della Carta and wild crockets of St. Mark's. This corruption of all architecture, especially ecclesiastical, corresponded with, and marked the state of religion over all Europe,-the peculiar degradation of the Romanist superstition, and of public morality in consequence which brought about the Reformation. § xxxvi. Against the corrupted papacy arose two great divisions of adversaries, Protestants in Germany and England, Rationalists in France and Italy; the one requiring the purification of religion, the other its destruction. The Protestant kept the religion, but cast aside the heresies of Rome and with them her arts, by which last rejection he injured his own character, cramped his intellect in refusing to it one of its noblest exercises, and materially diminished his influence. It may be a serious question how far- the Pausing of the Re. formation has been a consequence of this error. The Rationalist kept the arts and cast aside the religion. This rationalistic art is the art commonly called Renaissance, marked by a return to pagan systems, not to adopt them and hallow them for Christianity, but to rank itself under them as an imitator and pupil. In Painting it is headed by Giulio Romano and Nicolo Poussin ; in Architecture by Sansovino and Palladio. § xxxvii. Instant degradation followed in every direction,-- flood of folly and hypocrisy. Mythologies ill understood at first, then perverted into feeble sensualities, take the place of the representations of Christian subjects, which had become blasphemous under the treatment of men like the Ca- Gods without power, satyrs without rusticity, nymphs without innocence, men without humanity, gather into idiot groups upon the polluted canvas, and scenic affectations en. cumber the streets with preposterous marble. Lower and lower declines the level of abused intellect; the base school of landscape * gradually usurps the place of the historical painting, which had sunk into prurient pedantry,-the Alsatian sublimities of Salvator, the confectionery idealities of Claude, the dull manufacture of Gaspar and Canaletto, south of the Alps, and on the north the patient devotion of besotted lives to delineation of bricks and fogs' fat cattle and ditch-water. And thus Christianity and morality, courage, and Intellect and art crumbling together into one wreck, we am hurried on to the fall of Italy, the revolution in France * Appendix 11, 11 Renaissance Landscape," and the condition of art in England (saved by her Protestantism from severer penalty) in the time of George II § xxxviii. I have not written in vain if 1 have heretofore clone qDytbiDg towards diminishing the reputation of the Renaissance landscape painting. But the harm which has been done by Claude and the Poussins is as nothing when com-pared to the mischief effected by Palladio, Scamozzi, and Sansovino. Claude and the Poussins were weak men, and have had no serious influence on the general mind. There is little harm in their works being purchased at high prices, their real influence is very slight, and they may be left with- out grave indignation to their poor mission of furnishing drawing-rooms and assisting stranded conversation. Not so the Renaissance architecture. Raised at once into all the magnificence of which it was capable by Michael Angelo, then taken up by men of real intellect and imagination, such as Scamozzi, Sansovino, Inigo Jones, and Wren, it is impossible to estimate the extent of its influence on the European mind; and that the more, because few persons are concerned with painting, and, of those few, the larger number regard it with slight attention ; but all men are concerned with architecture, and have at some time of their lives serious business with it. It does not much matter that an individual loses two or three hundred pounds in buying a bad picture, but it is to be re-gretted that a nation should lose two or three hundred thou-sand in raising a ridiculou building. Nor is it merely wasted wealth or distempered conception which we have to regret in this Renaissance architecture: but we shall find in it partly the root, partly the expression, of certain dominant evils of modern times-over-so histication and ignorant classicalism ; the one destroying the healthfulness of general society, the other rendering our schools and universities useless to a large number of the men who pass through them. Now Venice, as she was once the most religious, was in her fall the most corrupt, of European states; and as she was in her strength the centre of the pure currents of Christian architecture, so she is in her decline the source of the Renaissance. It was the originality and splendor of the Palaces of Vicenza and Venice which gave this school its eminence in the eyes of Europe ; and the dying city, magnificent in her dissipation, and graceful in her follies, obtained wider worship in her de. crepitude than in her youth, and sank from the midst of her admirers into the grave. § xxxix. It is in Venice, therefore, and in Venice only that effectual blows can be struck at this pestilent art of the Renaissance. Destroy its claims to admiration there, and it can assert them nowhere else. This, therefore, will be the final purpose of the following essay. I shall not devote a fourth section to Palladia, nor weary the reader with successive chapters of virtuperation; but I shall, in my account of the earlier architecture, compare the forms of all its leading features with those into which they were corrupted by the Classicalists; and pause, in the close, on the edge of the precipice of decline, so soon as I have made its depths discernible. In doing this I shall depend upon two distinct kinds of evidence:-the first, the testimony borne by particular incidents and facts to a want of thought or of feeling in the builders; from which we may conclude that their architecture must be bad:-the second, the sense, which I doubt not I shall be able to excite in the reader, of a systematic ugliness in the architecture itself. Of the first kind of testimony I shall here give two instances, which may be immediately useful in fixing in the reader's mind the epoch above indicated for the commencement of decline. § xl. 1 must again refer to the importance which I have above attached to the death of Carlo Zeno and the doge Tomaso Mocenigo. The tomb of that doge is, as I said, wrought by a Florentine ; but it is of the same general type and feeling as all the Venetian tombs of the period, and it is one of the last which retains it. The classical element enters largely into its details, but the feeling of the whole is as yet unaffected. Like all the lovely tombs of Venice and Verona' it is a sarcophagus with a recumbent figure above, and this figure is a faithful but tender portrait, wrought as far as it can be without painfulness, of the doge as be lay in death. He wears his ducal robe and bonnet-his bead is laid slightly aside upon his pillow-his hands are simply crossed as they fall. The face is emaciated, the features large, but so pure and lordly in their natural chiselling, that they must have looked like marble even in their animation. They are deeply worn away by thought and death; the veins on the temples branched and starting ; the skin gathered in sharp folds; the brow higharched and shaggy ; the eye-ball magnificently large ; the curve of the lips just veiled by the light mustache at the side; the beard short, double and sharp-pointed: all noble and quiet; the white sepulchral dust marking like light the stern angles of the cheek and brow. This tomb was sculptured in 1424, and is thus described by one of the most intelligent of the recent writers who represent the popular feeling respecting Venetian art. "Of the Italian school is also the rich but ugly (ricco ma non bel) sarcophagus in which repose the ashes of Tomaso Mocenigo. It may be called one of the last links which connect the declining art of the Middle Ages with that of the Renaissance, which was in its rise. We will not stay to particularise the defects of each of the seven figures of the front and sides, which represent the cardinal and theological virtues; nor will we make any remarks upon those which stand in the niches above the pavilion because we consider theta unworthy both of the age and reputation of the Florentine school, which was then with reason considered the most notable in Italy." * It is well, indeed, not to pause over these defects ; but A might have been better to have paused a moment beside that noble image of it king's mortality. § xli. In the choir of the same church, St. Giov. and Paolo, is another tomb, that of the Doge Andrea Vendramin. This doge died in 1478' after a short reign of two years, the most disastrous in the annals of Venice. He died of a pestilence which followed the ravage of the Turks carried to the shores of the lagoons. He died, leaving Venice disgraced by sea -and land, with the smoke of hostile devastation rising in the blue distances of Friuli; and there was raised to him the most costly tomb ever bestowed on her monarchs. § xlii. If the writer above quoted was cold beside the * Selvatico, " Architettura di Venezia," p, 147, statue of one of the fathers of his country, he atones for it by his eloquence beside the tomb of the Vendramin. 1 must not spoil the force of Italian superlative by translation. "Quando si guarda a quella corretta eleganza di profili e di proporzioni, a quella squisitezza d'ornamenti, a quel certo sapore antico che senza ombra d'imitazione traspare da tutta l'opera" " Sopra ornatissimo zoccolo fornito di squisiti intagli s' alza uno stylobate "-&e. "Sotto le colonne, il predetto stilobate si muta leggiadramente in piedistallo, poi con bella novità di pensiero e di effetto va coronato da un fregio il più gentile che veder si possa "-&c. "Non poussi lasciar senza un cenno l'arca dove sta chiuso il doge ; capo lavoro di pensiero e di esecuzione," &c. There are two pages and a half of closely printed praise, of which the above specimens may suffice; but there is not a word. of the statue of the dead from beginning to end. 1 am myself in the habit of considering this rather an important part of a tomb, and 1 was especially interested in it here, because Selvatico only echoes the praise of thousands. It is unanimously declared the chef d'oevre of Renaissance sepulchral work, and pronounced by Cicognara (also quoted by Selvatico) " Il vertice a cui I' arti Veneziane si spinsero col ministero del scalpello," - ' The very culminating point to which the Venetian arts attained by ministry of the chisel." To this culminating point, therefore, covered with dust and cobwebs, 1 attained, as I did to every tomb of importance in Venice, by the ministry of such ancient ladders as were to be found in the sacristan's keeping. I was struck at first by the excessive awkwardness and want of feeling in the fall of the hand towards the spectator, for it is thrown of the middle of the body in order to show its fine cutting. Now the Mocenigo hand, severe and even stiff in its articulations, has its veins finely drawn, its sculptor having justly felt that the delicacy of the veining expresses alike dignity and age and birth. Tile Vendramin hand is far more laboriously cut, but its blunt and clumsy contour at once makes us feel that all the care has been thrown away, and well it may be, for it has been entirely bestowed in cutting gouty wrinkles about the joints. Such as the hand is, I looked for its fellow. At first I thought it had been broken off, but, on clearing away the dust, I saw the wretched effigy had only one hand, and was a mere block on the inner side. The face, heavy and disagreeable in its feat-is made monstrous by its semi-sculpture. One side of the forehead is wrinkled elaborately, the other left smooth; one side only of the doge's cap is chased; one cheek only is finished, and the other blocked out and distorted besides; finally, the ermine robe, which is elaborately imitated to its utmost lock of hair and of ground hair on the one side, is blocked out only on the other : it having been supposed throughout the work that "he effigy was only to be seen from below, and from one side. § xliii. It was indeed to be so seen by nearly every one and I do not blame-I should, on the contrary, have praised -the sculptor for regulating his treatment of it by its position ; if that treatment had not involved, first, dishonesty, ill giving only half a face, a monstrous mask, when we demanded true portraiture of the dead; and, secondly, such utter coldness of geeling, as could only consist with an extreme of intellectual and moral degradation: Who, with a heart in his breast, could have stayed his hand as lie drew the dim lines of the Old man's countenance-unmajestic once, indeed, but at least sanctified by the solemnities of death-could have stayed his hand, as he reached the bend of the grey forehead, and measured out the last veins of it at so much the zecchin ? I do not think the reader, if he has feeling, will expect that much talent should be shown in the rest of his work, by the sculptor of this base and senseless lie. The whole monument is one wearisome aggregation of that species of ornamental flourish, which, when it is done with a pen, is called pernamship and when done with a chisel, should be called chiselmanship ; the subject of it being chiefly fat-limbed boys sprawling on dolphins, dolphins incapable of swimming, and dragged along the sea by expanded pocket-handkerchiefs. THE QUARRY. 43 But now, reader, comes the very gist and point of the whole matter. This lying monument to a dishonored doge, this culminating pride of the Renaissance art of Venice, is at least veracious, if in' nothing else, in a testimony to the character of its sculptor. He was banished from Venice for forgery in 1487.* § xliv. I have more to say about this convict's work hereafter; but I pass at present, to the second, slighter, but yet more interesting piece of evidence, which I promised. The ducal palace has two principal facades ; one towards the sea, the other towards the Piazzetta. The seaward side, and, as far as the seventh main arch inclusive, the Piazzetta side, is work of the early part of the fourteenth century, some of it perhaps even earlier; while the rest of the Piazzetta side is of the fifteenth. The difference in age has been gravely disputed by the Venetian antiquaries, who have examined many documents on the subject, and quoted some -which they never examined. I have myself collated most of the written documents, and one document more, to which the Venetian antiquaries never thought of referring,-the masonary of the palace itself. § xlv. That masonry changes at the centre of the eighth arch from the sea angle on the Piazzetta side. It has been of comparatively small stones up to that point ; the fifteenth century work instantly begins with larger stones, "brought from Istria, a hundred miles away." The ninth shaft from the sea in the lower arcade, and the seventeenth, which is above it, in the upper arcade, commence the series of fifteenth century shafts. These two are somewhat thicker than the others, and carry the party-wall of the Sala del Scrutinio. Now observe' reader. The face of the palace, from this point to the Porta della Carta' was built at the instance of that noble Doge Mocenigo beside whose tomb yon have been standing ; at his instance, and in the beginning of the reign of his successor' Foscari ; that is to say, circa 1424. This is not disputed ; it is only disputed that the sea facade is earlier; Selvatico, p. 221. The older work is of Istrian stone also, but of different quality of which, however, the proofs are as simple as they are incontrovertible : for not only the masonry, but the sculpture, changes at the ninth lower shaft, and that in the capitals of the shafts both of the upper and lower arcade : the costumes of the figures introduced in the sea facade being purely Giottesque, correspondent with Giotto's work in the Arena Chapel at Padua, while the costume on the other capitals is Renaissance-Classic : and the lions' heads between the arches change at the same point. And there are a multitude of other evidences in the statues of the angels, with which I shall not at present trouble the reader. § xlvi. Now, the architect who built under Foscari, in 1424 (remember my date for the decline of Venice, 1418), was obliged to follow the principal forms of the older palace. But lie had not the wit to invent new capitals in the same style ; he therefore clumsily copied the old ones. The palace has seventeen main arches on the sea facade eighteen on the Piazzetta side, which in all are of course carried by thirty-six pillars ; and these pillars I shall always number from right to left, from the angle of the palace at the Ponte della Paglia to that next the Porta della Carta. I number them in this succession, because I thus have the earliest shafts first numbered. So counted, the 1st, the 18th, and the 36th, are the great supports of the angles of the palace ; and the first of the fifteenth century series, being, as above stated, the 9th from the sea on the Piazzetta side, is the 26th of the entire series, and will always in future be so numbered, so that all numbers above twenty-six indicate fifteenth century work, and all below it, fourteenth century, with some exceptional cases of restoration. Then the copied capitals are : the 28th, copied from the 7th ; the 29th, from the 9th ; the 30th, from the 10th ; the 31st, from the 8th ; the 33d, from the 12th ; and the 34th, from the 11th; the others being dull inventions of the 15th century, except the 36th, which is very nobly designed. § xlvii. The capitals thus selected from the earlier portion 'of the palace for imitation, together with the rest, will be accurately described hereafter ; the point I have here to notice is in the copy of the ninth capital, which was decorated (being, like the rest, octagonal) with figures of the eight Virtues :-Faith, Hope, Charity, Justice, Temperance, Prudence, Humility (the Venetian antiquaries call it Humanity !), and Fortitude, The Virtues of the fourteenth century are somewhat hard-featured ; with vivid and living expression, and plain every-day clothes of the time. Charity has her lap full of apples (perhaps loaves), and is giving one to a little child, who stretches his arm for it across a gap in the leafage of the capital. Fortitude tears open a lion's jaws; Faith lays her hand on her breast, as she beholds the Cross ; and Hope is praying, while above her a hand is seen emerging from sunbeams-the hand of God (according to that of Revelations, " The Lord God giveth them light and the inscription above is, " Spes optima in Deo." § xlviii. This design, thong is, rudely and with imperfect chiselling' imitated by the fifteenth century workmen : the Virtues have lost their hard features and living expression; they have now all got Roman noses, and have had their hair curled. Their actions and emblems are, however, preserved until we come to Hope : she is still praying, but she is praying to the sun only: The hand of God is gone. Is not this a curious and striking type of the spirit which had then become dominant in the world, forgetting to see God's hand in the light He gave ; so that in the issue, when that light opened into the Reformation on the one side, and into full knowledge of ancient literature on the other, the one was arrested and the other perverted ? § xlix. Such is the nature of the accidental evidence on which I shall depend for the proof of the inferiority of character in the Renaissance workmen. But the proof of the inferiority of the work itself is not so easy, for in this I have to appeal to judgments which the Renaissance work has itself distorted. I felt this difficulty very forcibly as I read a slight review of my former work' " The Seven Lamps," in " The Architect : " the writer noticed my constant praise of St. Mark's: "Mr. Ruskin thinks it a very beautiful building ! We," said the Architect, " think it a very ugly building." I was not surprised at the difference of opinion, but at the thing being consided so completely a subject of opinion. My opponents in matters of painting always assume that there is such a thing as a law of right, and that I do not understand it, but my architectual adversaries appeal to no law, they simply set their opinion against mine ; and indeed there is no law at present. to which either they or I can appeal. No man can speak with rational decision of the merits or demerits of buildings : he may with obstinacy ; he may with resolved adherence to previous prejudices ; but never as if the matter could be otherwise decided than by a majority of votes, or pertinacity of partizanship. I had always, however, a clear conviction that there was a law in this matter : that good architecture might be indisputably discerned and divided from the bad ; that the opposition in their very nature and essence was clearly visible and that we were all of us just as unwise in disputing about the matter without reference to principle, as we should be for debating about the genuineness of a coin, without ringing it. 1 felt also assured that this law must be universal if it were conclusive ; that it must enable us to reject all foolish and base work, and to accept all noble and wise work, without reference to style or national feeling ; that it must sanction the design of all truly great nations and times, Gothic or Greek or Arab .. that it must cast of and reprobate the design of all foolish nations and times, Chinese or Mexican, or modern European., and that it must be easily applicable to all possible architectural inventions of human mind. I set myself, therefore, to establish such a law, in full belief that men are intended, with. out excessive difficulty, and by use of their general common sense, to know good things from bad ; and that it is only be. cause they will not be at the pains required for the discernment, that the world is so widely encumbered with forgeries and basenesses. I found the work simpler than I had hoped; the reasonable things ranged themselves in the order I required, and the foolish things fell aside, and took themselves away so soon as they were looked in the face. I had then with respect to Venetian architecture' the choice, either to establish each division of law in a separate form, as I came to the features with which it was concerned, or else to ask the reader's patience, while I followed out the general inquiry first, and determined with him a code of right and wrong, to which we might together make retrospective appeal. I thought this the best, though perhaps the dullest way; and in these first following pages I have therefore endeavored to arrange those foundations of criticism, on which I shall rest in my account of Venetian architecture, in a form clear and simple enough to be intelligible even to those who never thought of architecture before. To those who have, much of what is slated in them will be well known or self-evident; but they must not be indignant at a simplicity on which the whole argument depends for its usefulness. From that which appears a mere truism when first stated, they will find very singular consequences sometimes following'-consequences altogether unexpected, and of considerable importance ; I will not pause here to dwell on their importance, nor on that of the thing itself to be done; for I believe most readers will at once admit the value of a criterion of right and wrong in so practical and costly an art as architecture, and will be apt rather to doubt the possibility of its attainment than dispute its usefulness if attained. I invite them, therefore, to a fair trial, being certain that even if I should fail in my main purpose, and be unable to induce in my reader the confidence of judgment I desire, I shall at least receive his thanks for the suggestion of consistent reasons, which may determine hesitating choice, or justify involuntary preference. And if I should succeed' as I hope, in making the Stones of Venice touchstones, and detecting, by the mouldering of her marble, poison more subtle than ever was betrayed by the rending of her crystal ; and if thus I am enabled to show the baseness of the schools of architecture and nearly every other art, which have for three centuries been predominant in Europe, I believe the result of the inquiry may be serviceable for proof of a more vital truth than any at which I have hitherto hinted. For observe : I said. the Protestant had despised the arts' and the Rationalist corrupted them. Bat what has the Romanist done meanwhile ? He boasts that it Was the papacy which raised the arts ; why could it not support them when it was left to its own strength? How came it to yield to Classicalism which was based on infidelity, and to oppose no barrier to innovations, which have reduced the once faithfully conceived imagery of its worship to stage decoration? Shall we not rather find that Romanism, instead of being a promoter of the arts, has never shown itself capable of a single great conception since the separation of Protestantism from its side ? * So long as, corrupt though it might be, no clear witness had been borne against it, so that it still included in its ranks a vast number of faithful Christians, so long its arts were noble. But the witness was borne-the error made apparent ; and Rome refusing to hear the testimony or forsake the falsehood, has been struck from that instant with an intellectual palsy, which has not only incapacitated her from any further use of the arts which once were her ministers, but has made her worship the shame of its own shrines, and her worshippers their destroyers. Come, then, if truths such as these are worth our thoughts; come, and let us know, before we enter the streets of the Sea city, whether we are indeed to submit ourselves to their undistinguished enchantment, and to look upon the last changes which were wrought on the lifted forms of her palaces, as we should on the capricious towering of summer clouds in the sunset, ere they sank into the deep of night ; or whether, rather, we shall not behold in the brightness of their accumulated marble, pages on which the sentence of her luxury was to be written until the waves should efface it, as they fulfilled-" God has numbered thy kingdom, and finished it." Ruskin, John. The Stones of Venice. Vol 1, chapter 1 - "The Quarry ". p. 1-48`,c=[],l=[],u={edition:`preserved`,sourceFile:`Burbank_notes/Stonesi_JR.htm`},d=[`burbank-notes-alltheda-n`,`burbank-notes-clipped-n`,`burbank-notes-entertains-n`,`burbank-notes-ferdinand-n`,`burbank-notes-flead-n`,`burbank-notes-lights-n`,`burbank-notes-lions-n`,`burbank-notes-passing-n`,`burbank-notes-rialto-n`,`burbank-notes-seven-n`,`burbank-notes-shuttered-n`,`burbank-notes-smoky-n`,`burbank-notes-stones-jr`],f={id:e,slug:t,type:n,title:r,sourceFile:i,encoding:a,html:o,text:s,links:c,images:l,provenance:u,backlinks:d};export{d as backlinks,f as default,a as encoding,o as html,e as id,l as images,c as links,u as provenance,t as slug,i as sourceFile,s as text,r as title,n as type};