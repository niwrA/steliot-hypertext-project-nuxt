var e=`prufrock-and-other-observations`,t=`prufrock-and-other-observations`,n=`source-page`,r=`Prufrock and Other Observations.`,i=`prufrock_and_other_observations.htm`,a=`windows-1252`,o=`
<div><center>
<table>
<tr>
<td><p><font><strong><i>Prufrock
        and Other Observations.</i></strong><strong> <br/>
</strong></font><font>London, 1917</font></p>
<hr noshade=""/>
<p><font><em>publication history</em></font></p>
<p><font>Prufrock was T.S. Eliot's
        first published collection of poems. It did not become
        well-known until after <em>The Waste Land </em>was
        published in 1922. </font></p>
<p><a href="Prufrock_FRAME.htm#Title"><font>J. Alfred Prufrock</font></a><font><br/>
        First line: "<em>Let us go then, you and I</em>,..."</font></p>
<p><font>First publication of
        Prufrock in the Chicago magazine <em>Poetry</em>, June
        1915. </font></p>
<p><font>Prufrock was written
        together with Portrait of a Lady in fragments during
        1910-11, and completed August 1911 while Eliot stayed in
        Munich. Its original title was "Prufrock Among the
        Women," and several scraps have turned up which were
        originally probably a part of this poem - see <em>Inventions
        of the March Hare</em>, p. 39-47, where these scraps -
        Prufrocks' Pervigilium in particular - can be read. The
        feeling expressed in this poem is generally thought to be
        a fear of women, and although Eliot grew up in a house
        with a considerable amount of women himself, this feeling
        is often also attributed to Eliot himself. It is equally
        likely, however, that Eliot understood women well enough
        to be able to criticize and satirize them as he did
        everyone else, including himself. This is more fitting
        with Eliot's confession to Aiken "that he relied
        very much on the company of women" (# check <em>Letters</em>:
        To Conrad Aiken, 31 December 1914)</font></p>
<p><a href="Portrait_FRAME.htm#Title"><font>Portrait of a Lady</font></a><font><br/>
        First line: "<em>Among the smoke and fog of a
        December afternoon</em>..."</font></p>
<p><font>First published in <em>Others</em>,
        September 1915.</font></p>
<p><font>Written during roughly the
        same period as Prufrock, 1910-11, the poem is
        conventionally thought to be inspired by Adeleine Moffat,
        a Bostonian grande dame who Aiken and Eliot used to
        visit. Other obvious influences are Henry James' novel of
        the same name, particularly when remembering Eliot's
        resolve during that time to "develop in the manner
        of Henry James"; and finally it is interesting to
        note that Pound had a "Portrait d'une Femme"
        which he must have written during the same time as Eliot
        (it was published in 1912), and this coincidence must
        have helped their friendship - in one letter, Eliot
        writes to Pound that he has found at least four more
        portrait ladies. (# check <em>Letters</em>)</font></p>
<p><a href="Preludes_FRAME.htm"><font>Preludes</font></a><font><br/>
        First line: "<em>The winter evening settles down</em>..."</font></p>
<p><font>First published in <em>Blast</em>,
        July 1915.</font></p>
<p><a href="Rhapsody_FRAME.htm"><font>Rhapsody on a Windy
        Night</font></a><font><br/>
        First line: "<em>Twelve o'clock.</em>"</font></p>
<p><font>First published in <em>Blast</em>,
        July 1915.</font></p>
<p><a href="Morning_FRAME.htm"><font>Morning at the Window</font></a><font><br/>
        First line:</font></p>
<p><a href="Boston_FRAME.htm"><font>The 'Boston Evening
        Transcript'</font></a><font><br/>
        First line:</font></p>
<p><font>First publication of
        Prufrock in the Chicago magazine <em>Poetry</em>, August?
        1915. </font></p>
<p><a href="Helen_FRAME.htm"><font>Aunt Helen</font></a><font><br/>
        First line:</font></p>
<p><font>First publication of
        Prufrock in the Chicago magazine <em>Poetry</em>, August?
        1915. </font></p>
<p><a href="Nancy_FRAME.htm"><font>Cousin Nancy</font></a><font><br/>
        First line:</font></p>
<p><font>First publication of
        Prufrock in the Chicago magazine <em>Poetry</em>, August?
        1915. </font></p>
<p><a href="Apollinax_FRAME.htm"><font>Mr. Apollinax</font></a><font><br/>
        First line:</font></p>
<p><a href="Hysteria_FRAME.htm"><font>Hysteria</font></a><font><br/>
        First line:</font></p>
<p><a href="Galante_FRAME.htm"><font>Conversation Galante</font></a><font><br/>
        First line:</font></p>
<p><a href="Figlia_FRAME.htm"><font>La Figlia Che Piange</font></a><font><br/>
        First line:</font></p>
<table>
<tr>
<td><strong>sources</strong></td>
</tr>
<tr>
<td>Akroyd, Peter. <em>T.S. Eliot. </em>(1984)</td>
</tr>
<tr>
<td>Quillian, <em>William. Hamlet and the New
                Poetic. </em>(1975)</td>
</tr>
<tr>
<td>\xA0</td>
</tr>
</table>
</td>
</tr>
</table>
</center></div>
`,s=`Prufrock and Other Observations. London, 1917 publication history Prufrock was T.S. Eliot's first published collection of poems. It did not become well-known until after The Waste Land was published in 1922. J. Alfred Prufrock First line: " Let us go then, you and I ,..." First publication of Prufrock in the Chicago magazine Poetry , June 1915. Prufrock was written together with Portrait of a Lady in fragments during 1910-11, and completed August 1911 while Eliot stayed in Munich. Its original title was "Prufrock Among the Women," and several scraps have turned up which were originally probably a part of this poem - see Inventions of the March Hare , p. 39-47, where these scraps - Prufrocks' Pervigilium in particular - can be read. The feeling expressed in this poem is generally thought to be a fear of women, and although Eliot grew up in a house with a considerable amount of women himself, this feeling is often also attributed to Eliot himself. It is equally likely, however, that Eliot understood women well enough to be able to criticize and satirize them as he did everyone else, including himself. This is more fitting with Eliot's confession to Aiken "that he relied very much on the company of women" (# check Letters : To Conrad Aiken, 31 December 1914) Portrait of a Lady First line: " Among the smoke and fog of a December afternoon ..." First published in Others , September 1915. Written during roughly the same period as Prufrock, 1910-11, the poem is conventionally thought to be inspired by Adeleine Moffat, a Bostonian grande dame who Aiken and Eliot used to visit. Other obvious influences are Henry James' novel of the same name, particularly when remembering Eliot's resolve during that time to "develop in the manner of Henry James"; and finally it is interesting to note that Pound had a "Portrait d'une Femme" which he must have written during the same time as Eliot (it was published in 1912), and this coincidence must have helped their friendship - in one letter, Eliot writes to Pound that he has found at least four more portrait ladies. (# check Letters ) Preludes First line: " The winter evening settles down ..." First published in Blast , July 1915. Rhapsody on a Windy Night First line: " Twelve o'clock. " First published in Blast , July 1915. Morning at the Window First line: The 'Boston Evening Transcript' First line: First publication of Prufrock in the Chicago magazine Poetry , August? 1915. Aunt Helen First line: First publication of Prufrock in the Chicago magazine Poetry , August? 1915. Cousin Nancy First line: First publication of Prufrock in the Chicago magazine Poetry , August? 1915. Mr. Apollinax First line: Hysteria First line: Conversation Galante First line: La Figlia Che Piange First line: sources Akroyd, Peter. T.S. Eliot. (1984) Quillian, William. Hamlet and the New Poetic. (1975)`,c=[{kind:`internal`,path:`Prufrock_FRAME.htm`,fragment:`Title`,label:`J. Alfred Prufrock`,resolvedPath:`Prufrock_FRAME.htm`,pageId:`prufrock-frame`},{kind:`internal`,path:`Portrait_FRAME.htm`,fragment:`Title`,label:`Portrait of a Lady`,resolvedPath:`Portrait_FRAME.htm`,pageId:`portrait-frame`},{kind:`internal`,path:`Preludes_FRAME.htm`,fragment:null,label:`Preludes`,resolvedPath:`Preludes_FRAME.htm`,pageId:`preludes-frame`},{kind:`internal`,path:`Rhapsody_FRAME.htm`,fragment:null,label:`Rhapsody on a Windy Night`,resolvedPath:`Rhapsody_FRAME.htm`,pageId:`rhapsody-frame`},{kind:`internal`,path:`Morning_FRAME.htm`,fragment:null,label:`Morning at the Window`,resolvedPath:`Morning_FRAME.htm`,pageId:`morning-frame`},{kind:`internal`,path:`Boston_FRAME.htm`,fragment:null,label:`The 'Boston Evening Transcript'`,resolvedPath:`Boston_FRAME.htm`,pageId:`boston-frame`},{kind:`internal`,path:`Helen_FRAME.htm`,fragment:null,label:`Aunt Helen`,resolvedPath:`Helen_FRAME.htm`,pageId:`helen-frame`},{kind:`internal`,path:`Nancy_FRAME.htm`,fragment:null,label:`Cousin Nancy`,resolvedPath:`Nancy_FRAME.htm`,pageId:`nancy-frame`},{kind:`internal`,path:`Apollinax_FRAME.htm`,fragment:null,label:`Mr. Apollinax`,resolvedPath:`Apollinax_FRAME.htm`,pageId:`apollinax-frame`},{kind:`internal`,path:`Hysteria_FRAME.htm`,fragment:null,label:`Hysteria`,resolvedPath:`Hysteria_FRAME.htm`,pageId:`hysteria-frame`},{kind:`internal`,path:`Galante_FRAME.htm`,fragment:null,label:`Conversation Galante`,resolvedPath:`Galante_FRAME.htm`,pageId:`galante-frame`},{kind:`internal`,path:`Figlia_FRAME.htm`,fragment:null,label:`La Figlia Che Piange`,resolvedPath:`Figlia_FRAME.htm`,pageId:`figlia-frame`}],l=[],u={edition:`preserved`,sourceFile:`prufrock_and_other_observations.htm`},d=[`eliot-works`],f={id:e,slug:t,type:n,title:r,sourceFile:i,encoding:a,html:o,text:s,links:c,images:l,provenance:u,backlinks:d};export{d as backlinks,f as default,a as encoding,o as html,e as id,l as images,c as links,u as provenance,t as slug,i as sourceFile,s as text,r as title,n as type};