var e=`essays-mirsky`,t=`mirsky`,n=`source-page`,r=`T.S. Eliot and the End of Bourgeois Poetry`,i=`Essays/Mirsky.htm`,a=`windows-1252`,o=`
<div>
<center>
<table>
<tr>
<td>
<h1 style="text-align:center"><span lang="EN-GB">T. S. Eliot and The
End of Bourgeois Poetry</span><span lang="EN-GB" style='mso-fareast-font-family:
"Arial Unicode MS"'><o:p></o:p></span></h1>
<p class="MsoBodyText"><span lang="EN-GB">by<br/>
D. S. Mirsky</span></p>
<p class="MsoBodyText"><span lang="EN-GB"><!--[if !supportEmptyParas]-->\xA0<!--[endif]--><o:p></o:p></span></p>
<p class="MsoBodyText"><span lang="EN-GB" style="font-size:10.0pt;mso-bidi-font-size:
12.0pt">(translated by Gunnar Jauch, Annelie Hultén, and Arwin van Arum)<o:p></o:p></span></p>
<p class="MsoNormal"><span lang="EN-GB"><!--[if !supportEmptyParas]-->\xA0<!--[endif]--><o:p></o:p></span></p>
<p class="MsoNormal"><span lang="EN-GB">I believe T. S. Eliot has no equal among
the bourgeois poets of today, in France or in England. I know the regime of the
literary society which has established itself now for more than one generation
of bourgeois poets makes it all\xA0the more difficult to sustain this claim;
the glories of poetry are confined to Chapels, and I have not nearly visited
all of them. It is quite possible that those which I have not visited may be
concealing poets no less remarkable than Eliot. The technical difficulty of
paying a visit to all these Chapels is, however, not as great as the difficulty
of learning all of the resident languages: a fundamental aspect of these kind
of societies is that each has its own exclusive idiom, and they are idioms of a
kind that cannot be quickly mastered. Eliot’s own growing fame has contributed
more than one example of this linguistic difficulty. Thousands of readers have
failed when confronted by the obscurity of his poetic grammar, and even
experienced critics (notably I. A. Richards and Edwin Muir) have been careless
enough to analyse his work without learning his language first. This obscurity
of contemporary poets cannot be reduced to the simple problem of logic, to
these almost mandatory elliptical accumulations, which on first sight make
contemporary poetry seem a disquieting and indecipherable shorthand. Even worse
is that each poet has his own symbolic language, but does not bother to explain
this language to the reader so that it becomes intelligible only to experienced
psychoanalysts. The poet does not want to be understood. The reader does not
want to understand, either. Poetry has ceased to be a means of communication;
the poetical forum has become a market of snobbism on which one learns to trade
without considering its intrinsic content. Poetic glories have become mere
fortuities, linked to poetically insignificant individuals. On the stock
exchange of values, poets possess nothing that yields interest to either the
literature scholar or the sensibility of the dying bourgeoisie. Nothing is
being said about anything the reader likes or understands. Poetry has
devaluated to being merely an aspect of social organization, relevant perhaps
to sociologists or economists, but to nobody else. </span></p>
<p class="MsoNormal" style="text-indent:14.2pt"><span lang="EN-GB">But do bourgeois
poets deserve any better? Is there anything more to them than their
disconcerting displays of originality? Poetry has never been as devoid of
meaning and of valid social content<a href="#_ftn1" name="_ftnref1" style="mso-footnote-id:ftn1" title=""><span style="mso-special-character:footnote"><!--[if !supportFootnotes]-->[1]<!--[endif]--></span></a>
as now. The worlds these poets construct are rigorously ‘private’ – they are as
arbitrary and exclusive as dreams. Nobody needs this. Watching them pass by has
become a mere mind-game. Sentiment (with which I mean all that contains a value
judgement) can find nothing to react to. All that remains of these poets’
efforts is their deformation of the language (in the widest sense of the term),
emptying it of all social content, ‘demagnetising’<a href="#_ftn2" name="_ftnref2" style="mso-footnote-id:
ftn2" title=""><span style="mso-special-character:footnote"><!--[if !supportFootnotes]-->[2]<!--[endif]--></span></a>
it. </span></p>
<p class="MsoNormal" style="text-indent:14.2pt"><span lang="EN-GB">Standing out
from this core of crossed-word and mixed-image brokers are a small number of
poets whose work holds at least some interpersonal interest. And among them, an
even smaller number actually has anything truly significant to say. The
importance of a poet derives from two variables: his poetic power, and the
human and historical relevance of his topic. The poetic power itself has a
neutral value, comparable to a cannon whose destructive power does not depend
on the cause it is used for.<a href="#_ftn3" name="_ftnref3" style="mso-footnote-id:ftn3" title=""><span style="mso-special-character:footnote"><!--[if !supportFootnotes]-->[3]<!--[endif]--></span></a>
These two elements had a strong tendency to coincide in the grand poets of
preceding times: Dante, Milton and Goethe were at once the mightiest voices <i>and
</i>the most representative spirits of their respective eras. Victor Hugo was
the last of the great poets<a href="#_ftn4" name="_ftnref4" style="mso-footnote-id:ftn4" title=""><span style="mso-special-character:footnote"><!--[if !supportFootnotes]-->[4]<!--[endif]--></span></a>\xA0who
were at the same time popular and a representative of the living forces of
their era. But bourgeois poetry, emasculated of the last remnants of its
revolutionary power,\xA0ceased to be fertile even before Hugo’s death.\xA0
From Tennyson, Longfellow and Sully-Prudhomme onwards poets have become no more
than eunuchs detaining the public ear, and the only poetic power left were the
"poetes maudits", with Rimbaud as their prime representative. These
poets\xA0were no longer moved by the hopes and ideals\xA0of a vigorous
class, but by the tragic contradictions of a society dominated by a class in a
stage of latent but incurable decomposition. They were no revolutionaries, but
symptoms of a state of affairs where revolution should have been the only
issue. Their poetry became a button which set off the bourgeoisie’s festering
decomposition at an explosive speed and with likewise power. Being a ‘poete
maudit’ was not easy, these were "tragic heroes", scapegoats singled
out to be sacrificed for the sins of the tribe. The truest of them perished
literally. Their deaths left behind a potent vaccine for posterity, which,
after the tragic deaths of Verlaine and Rimbaud, degenerated to a spicy
seasoning for the meals of the decomposing middle-class. The contrast between
the disgrace of Rimbaud's living conditions and his posthumous glory among
today’s elite\xA0– a glory so tangible that the most expensive bar of the </span><i><span lang="FR" style="mso-ansi-language:FR">quartier latin</span></i><span lang="EN-GB">
in Paris bears the name of Rimbaud’s most celebrated poem – represents the
contrast between a time when the death of bourgeois civilization haunted only
the most inspired of Cassandras, and a time when that same death has become an
object of daily consumption – after all, one might as well make death
consumable when one is forced to consume it anyway. Today, the potent chemicals
left us by the "poetes maudits" have been reduced to a harmless goo.
For most poets, they have become only more or less dominant ingredients to be
added to their bowl of stirred images. Other poets who did imbued the vaccine,
have become immune by making the vaccine a springboard, a point of departure
from which they can leave a positive value system. But unfortunately,\xA0
under the current regime of bourgeois civilization, which is itself incapable
of producing a value system, they can only produce dummy values, intellectually
unacceptable and historically false, borrowed from more fertile eras but
profoundly alien to ours. Such is the nature of Claudel's Catholicism. </span></p>
<p class="MsoBodyTextIndent"><span lang="EN-GB">Asked who was the greatest poet in
France, Andre Gide answered: "Victor Hugo, alas", which is a
respectable answer from one the last members of the bourgeois decadence, who
finds the robust self-sufficiency of a less corrupt age ridiculous and vulgar;
an answer worthy enough of an intelligent critic who knows how to appreciate
without liking. One ought to answer the question who is currently our greatest
French poet in the manner of Gide: "Paul Claudel, alas". There can be
no doubt that Claudel's voice is the ablest among the French authors of today.
But this poetic ability serves an ideology, the acceptance of which only demonstrates
the extent of the bourgeois poets’ moral and intellectual disintegration.
Hugo's democratic vitality was a religion that lived for its time; Claudel's
Catholicism is a hole in the sand in which the ostrich-like poet believes to be
sheltered from sad, sad reality, a refuge where the shirker of history tries to
shelter himself from the approaching future. Morally it is a flight, a
cowardice; intellectually an abdication, for only by blinding one’s
intelligence can such a fantastic and unreal system be accepted. Claudel's
poetry is not empty in the way typical decadent bourgeois poetry is; it is
worse. He has inflated his poetry with negative matter, invested it with a
power that serves an unreal and negative goal – all too typical of the dying
bourgeois civilization: Claudel's poetry\xA0 is not unlike the immense amount
of negative energy that was shed in the Great War. </span></p>
<p class="MsoNormal" style="text-indent:14.2pt"><span lang="EN-GB">What
distinguishes Eliot from all these poets is that in him, an exceptional poetic
power has allied itself to a truly important social theme, indeed, the only
historically valid\xA0and sincere theme that remains a bourgeois poet in our
time. Where his contemporaries are themselves nothing but manifestations
of\xA0 the death of bourgeois civilization, he alone has been able to create
a poetry of death. </span></p>
<p class="MsoNormal" style="text-indent:14.2pt"><span lang="EN-GB">Eliot's theme is
the only one available for a poet of the decadent bourgeoisie. For a true poet
is a true poet also for having an understanding, an 'intuition' if you will, of
the historical reality that his understanding has to be more or less self-conscious.
One could object that there is another possibility, that the fight against the
past by a class dedicated to death could well be the source of inspiration for
a poet of bourgeois imperialism. But Lucain's Caton, the typical militant of
this condemned class, is a figure devoid of high poetry. Why could fascism not
inspire a poet of Eliot's size? Because long before its physical and military
defeat bourgeoisie lost everything justifying, even to itself, its struggle
against the class that will superannuate it. The bourgeoisie is devoid of
values and all the living values are on the side of the working class. If a
bourgeois poet, or ideologist, wants to confront the revolution with something
positive and convincing (convincing to himself also), he has no other option
but to rely on the resurrection of some medieval ghost – such is Claudel's
Catholicism – with the consequence that inevitably he will become irrelevant to
his contemporaries. The fight of the bourgeoisie against the revolution is
ideologically sterile. Fascism is merely an <i>atto puro</i>, an action without
rational aim or justification beyond the action itself.<a href="#_ftn5" name="_ftnref5" style="mso-footnote-id:
ftn5" title=""><span style="mso-special-character:footnote"><!--[if !supportFootnotes]-->[5]<!--[endif]--></span></a>
Fascism is a mere binge,<span style="mso-spacerun: yes">\xA0 </span>a
drinking-bout that blinds all reason and intelligence and reduces mankind to a
system of reactions, sterile from conscience. Like Dr. Watson's rats, the
system constitutes of behaviour only and of the hypothesis that conscience is
superfluous to explain its movements. Fascism cannot have its own poet, and for
today's bourgeois poet Fascism cannot be a topic: the only one left to him is
Death. </span></p>
<p class="MsoNormal" style="text-indent:14.2pt"><span lang="EN-GB">Death is a very
interpersonal theme, since it is firmly grounded in both history and society.
But it is hardly a popular theme. The poet who takes it as the leitmotif of his
oeuvre by definition lacks popular elements, in every sense of the word
‘popular’. Besides, the ‘private’ and exclusive style developed by the
bourgeois poets of recent decades serves excellently for poker-facing a lost
game, and insisting on that to which one can but resign oneself.<a href="#_ftn6" name="_ftnref6" style="mso-footnote-id:ftn6" title=""><span style="mso-special-character:footnote"><!--[if !supportFootnotes]-->[6]<!--[endif]--></span></a>
Taken from that point of view, Eliot's obscurity becomes very interesting.
Eliot is obscure. He is so consciously, aggressively – obscure with a
vengeance. One might even call him a champion of obscurity, of the poet's right
not to be understood. But his complexity is different from that of most of his
contemporaries. The latter go to great lengths to be incomprehensible simply
because they have nothing to say worth understanding. For Eliot, obscurity is a
weapon with which he defend defends himself; it allows him to speak of secret
things the populace was never <i>meant </i>to understand. Yet the content of
his poetry is not in the least obscure. It is not a private world of hybrid
images expressed by means of symbols that were carefully sifted from the most
perplexing bunch that a troubled and putrescent subconscious could come up
with. Eliot’s poetry is essentially based on a social and universal experience,
an experience which on the level of the individual manages to encompass a full
perspective of the death of a civilization. To be explicit about this would,
however, have been lacking in refinement, it would have been a betrayal to
revered simplicity. Strong inhibitions (due in part, as has been too often
insisted upon, to a Puritan upbringing and to the inferiority complex of American
highbrows, for whom not having been born an Englishman hurts like an incurable
wound<a href="#_ftn7" name="_ftnref7" style="mso-footnote-id:ftn7" title=""><span style="mso-special-character:footnote"><!--[if !supportFootnotes]-->[7]<!--[endif]--></span></a>)
have come to Eliot's aid and simplified the task of obscuring that which might
otherwise have become too obvious. A closer analysis of his poetry shows that
his obscurity is all superficial, superimposed, created out of ellipses and
silences. The content, the system of symbols with which he works, is remarkably
transparent and there is nothing affected or arbitrary about it. Its order and
logic are so rigorous that one might classify Eliot's oeuvre as allegory. <i>The
Waste Land </i>is wholly structured around three fundamental symbols: Humidity,
Aridity, and Fire.<a href="#_ftn8" name="_ftnref8" style="mso-footnote-id:ftn8" title=""><span style="mso-special-character:
footnote"><!--[if !supportFootnotes]-->[8]<!--[endif]--></span></a> These
symbols are predominant throughout almost his entire oeuvre. His obscurity is
superimposed onto this clear and simple drama. It is above all to be found in
the sequence of the images, in this ingenious and confusing poetic 'montage'
which brings Eliot close to surrealism – especially to surrealist cinema, of
which he is the unacknowledged precursor.<a href="#_ftn9" name="_ftnref9" style="mso-footnote-id:ftn9" title=""><span style="mso-special-character:footnote"><!--[if !supportFootnotes]-->[9]<!--[endif]--></span></a>
</span></p>
<p class="MsoNormal"><span lang="EN-GB"><span style="mso-spacerun: yes">\xA0 \xA0\xA0\xA0</span>Eliot's poetry is, like all great decadent
poetry, at once violently innovative and solidly traditional, retrospective
even. One might call the tradition to which he attaches himself that of the
English <i>secentismo</i>,<a href="#_ftn10" name="_ftnref10" style="mso-footnote-id:ftn10" title=""><span style="mso-special-character:footnote"><!--[if !supportFootnotes]-->[10]<!--[endif]--></span></a>
that influential school which begins with Shakespeare and Chapman, finds its
most individual expression in Donne and Webster, and, then, after a long period
of decline, is briefly revived in the works of Pope. Laforgue chiselled his
light irony onto this strong and heavy pillar, and Eliot keeps much of this
incongruous juxtaposition of <i>secentist </i>sonorities placed under the
ironic damper of French decadence in his own style – the Eliotic ‘montage’ owes
many of its best effects to these paragraphs of blank verse which are easily
mistaken to be Elizabethan at first, but then suddenly broken off by a vulgar
modern dissonance.</span></p>
<p class="MsoNormal"><span lang="EN-GB"><span style="mso-spacerun: yes">\xA0\xA0\xA0\xA0
</span>The power that the English <i>secentism </i>has over Eliot is the result
of a complex play of attraction and repugnance. Since he is the last poet of
the English bourgeoisie, it is only natural he should be drawn to this Golden
Age of English poetry. But there is more to it. This golden age had its element
of decadence too, and this adds to the attraction.<span style="mso-spacerun:
yes">\xA0 </span>It was a time of transition during which a young bourgeois
civilization was still caught up in the last forms of medieval decadence.
Alongside a truly modern elite, whose most notable names were Bacon and Hobbes,
persisted an elite still attached to the Church, the feudal system, and whom
still considered scholasticism, astrology, and alchemy to be relevant
disciplines; the most influential and characteristic poet representative of
this elite is Donne. Eliot’s current position is in several respects similar to
that of Donne three hundred years ago. Donne represents something which has
been fairly uncommon in the past: a real poet endowed with great poetic power,
whose theme is historically viable, but who is nevertheless esoteric rather
than popular – which is quite common for poets who belong to a superannuated
elite. But Donne’s class was not under threat of the kind of complete
extinction that the class which Eliot descends from is under. Donne's class
would survive for a while yet, needing only to reject certain outmoded values
to be able to adapt itself to a new era with relative ease. And so, while<span style="mso-spacerun: yes">\xA0 </span>Donne’s effort to remain obscure mainly
reveals his attachment to everything his class had to abandon in order to
survive, Donne introduces the theme of death under very different auspices than
Eliot does. These similarities and differences betwixt the two poets are
reflected in Eliot's attitude towards Donne, an attitude marked by complexity
and ambivalence. Drawn to him by an affinity too great to be ignored, Eliot at
the same time fights against that which he finds alien and hostile in the older
poet – his disciplined yet ever living flesh, his soul, and his psyche, which
cannot detach itself from the flesh to become pure spirit, <i>pneuma</i>. </span></p>
<p class="MsoNormal"><span lang="EN-GB"><span style="mso-spacerun: yes">\xA0\xA0\xA0\xA0
</span>The affinity between Eliot and Laforgue is more direct and immediate. In
the poetic family-tree, this poet is Eliot’s true father: the ties which bind
them together manifest themselves above all in Eliot's early poems (those
collected in <i>Prufrock and Other Observations </i>(1917) and <i>Ara Vos Prec </i>(1920))
only to disappear almost completely in his mature works. Laforgue was not a <i>poète
maudit</i>. He was only an epigone of Romanticism. In other words, his soul was
not laid bare by the crumbling of bourgeois values, but rather directed towards
a ‘green paradise' to be created after the inferno of capitalism. The true
romantic, however, is the petty, degraded bourgeois who still cherishes
memories of an idyllic order, still hoping to recover his paradise through a
utopian revolution (Baudelaire in 1848), through faith (Baudelaire on his
death-bed), through dreams (like the great opium smokers of English
Romanticism), or through a dream-like death. If the romantic tries to escape
the bourgeois world, then not because he can see its corruption and has
fore-suffered its death. On the contrary, he wishes to escape because he sees
that the world is strong and stable, and he neither can nor wants to adapt to
it, finds it inhospitable. If we compare the decadent romantics of the <i>fin
de siècle</i> with the first generation of romantics, we find that the former
differ from the latter mainly in that they have much less faith in the reality
of a romantic paradise and put far more emphasis on the cult of disease. The
first romantics lived in an era when the “dark Satanic Mills” had only just
begun invading “England's green &amp; pleasant Land” (Blake). The
pre-capitalist idyll was still a reality for them; they believed in something
tangible. Besides, their inability to adapt to the capitalist struggle for life
was not put down to defects, personal insufficiencies, it was still the sign of
a class which would not admit defeat and was full of life, energy. A hundred
years later, this ideal remained only in the form of dreams, and the inability
to adapt was increasingly associated with personal failure, with illness and
physical weakness. Romantic irony was attracted to death as the only possible
route of escape to a paradise “where all is but order and beauty”,<a href="#_ftn11" name="_ftnref11" style="mso-footnote-id:ftn11" title=""><span style="mso-special-character:footnote"><!--[if !supportFootnotes]-->[11]<!--[endif]--></span></a>
but which is more likely to be a useless “all-inclusive sinecure”, such as
permeates Laforgue's poetry (this irony also becomes the point of departure for
the clownery which is the poet's revenge on the philistine, and which also the
young Eliot practised, not without success). In Laforgue, the irony is
associated with the characteristic behaviour of someone suffering from tuberculosis,
not willing to resign himself to death and desperately trying to hold onto life
as it slips away from him. There is, in his poetry, an atmosphere of impurity,
a permanent itch linked to sexual impotence, and an ironic sentimentality which
makes fun of that which it cowardly adores in secret.</span></p>
<p class="MsoNormal"><span lang="EN-GB"><span style="mso-spacerun: yes">\xA0\xA0\xA0\xA0
</span>This Laforguian atmosphere permeates Eliot's early poems and only little
by little can one see a completely different kind of poetry stand out against
this background, a poetry liberated from the decadent poet's wavering
ambiguities, a poetry where irony is slowly eclipsed by tragedy, and the
consumptive artist’s sexual ambivalence is slowly being replaced with the
renunciation of the ascetic. </span></p>
<p class="MsoNormal"><span lang="EN-GB"><span style="mso-spacerun: yes">\xA0\xA0\xA0\xA0
</span>Eliot's critics tend to make much of his romantic irony, these contrasts
which repeat the action in two different keys – one sublime, the other sordid.
This is the kind of irony which prevails in the satiric poems of <i>Ara Vos
Prec</i>: in “Sweeney Erect”, the banal scene of a man shaving himself
peacefully, not paying any attention to the hysterical convulsions of the girl
he has just made love to, is compared to the story of Theseus and Ariadne in
sublimely declamatory lines; in "Sweeney Among the Nightingales", the
shoddy machinations of a Montmartre bar owner and a whore who plan to cheat a
customer, evoke images of Clytemnestra's conspiracy against Agamemnon. Even
later, in the famous third part of <i>The Waste Land</i>, we find the splendour
of Queen Elizabeth and her lover, the Earl of Leicester, sailing down the Thames,
and the image is juxtaposed with the sordidly tragic loves of the “Thames
daughters” who live among “trams and dusty trees” and die among the oil slicks
polluting the river and among the tins which litter the popular beaches. All
these episodes should probably be connected to Laforgue and the romanticism of
the decadent poets. But in the new context created for them by Eliot, they no
longer emboss the irony of contrasts. The opposition between the same situation
played out either pleasing or ugly no longer prevails, the pity and horror of
the reality of life is now common to both versions. Heroic love is not brought
out to enhance its sordid equivalent, nor is sordid love used to ridicule
heroic love. The eternal identity of sexual love in all its manifestations –
whatever dress it may wear – is what evokes pity and terror. The poet has left
the limitations of romanticism behind.<span style="mso-spacerun: yes">\xA0\xA0\xA0
</span></span></p>
<p class="MsoNormal"><span lang="EN-US" style="mso-ansi-language:EN-US"><span style="mso-tab-count:1">\xA0\xA0\xA0\xA0 </span>Humidity and Aridity are the two
fundamental symbols of the cycle which starts with <i style="mso-bidi-font-style:
normal">Gerontion (Ara Vos Prec) </i>and to which <i style="mso-bidi-font-style:
normal">The Waste Land </i><span style="mso-bidi-font-style:italic">is central</span><i style="mso-bidi-font-style:normal">. </i>Humidity, whose principle
manifestations are water and flowers, stands for life, sex, the eternal return
of the seasons, the variety of the carnal and psychic life, and the world of
passion and of feeling. There is certainly ambivalence in Eliot’s attitude
towards Humidity; his stance is not so much one of repulsion, but rather, as
the fine critic Edmund Wilson rightfully points out when comparing <i style="mso-bidi-font-style:normal">Prufrock </i>and <i style="mso-bidi-font-style:
normal">The Waste Land </i>(especially the first and fourth parts), a youthful
renunciation that never again left the poet. We are, however, not interested in
the psychoanalysis of the Eliot’s character, but in the social and historical
range of his sentimental development. And essential from this point of view is
that the nostalgic love dominant in <i style="mso-bidi-font-style:normal">Prufrock
</i>and occasionally surfacing in later works<a href="#_ftn12" name="_ftnref12" style="mso-footnote-id:ftn12" title=""><span style="mso-special-character:footnote"><!--[if !supportFootnotes]-->[12]<!--[endif]--></span></a>
has transformed little by little into a horror of sex and of the vital
functions, a deep phobia of life, turning into what one could perhaps best
describe as ‘complete biological defeatism’. <i style="mso-bidi-font-style:
normal">The Waste Land </i>is built around a skeleton which derives from
comparative religion<a href="#_ftn13" name="_ftnref13" style="mso-footnote-id:ftn13" title=""><span style="mso-special-character:footnote"><!--[if !supportFootnotes]-->[13]<!--[endif]--></span></a>
– the animist idea that the seasonal god of life is eternally resurrected. The
first verse gives the tone of the poem: "April is the cruellest
month", the cruelest because it conceives, gives birth to, and therewith
puts an end to the happy illusion of the absence of death in winter. The poem’s
center is in the third part, at the middle of which we find the synthetic
figure of Tirésias, the man who was woman, who knew <i style="mso-bidi-font-style:
normal">utramque venerem,<a href="#_ftn14" name="_ftnref14" style="mso-footnote-id:ftn14" title=""><span style="mso-special-character:footnote"><!--[if !supportFootnotes]-->[14]<!--[endif]--></span></a>
</i>and has thus “fore-suffered” the horror of and pity for the typist, who,
after a summary meal, sleeps with her young man on a divan which doubles as a
night-time bed<a href="#_ftn15" name="_ftnref15" style="mso-footnote-id:ftn15" title=""><span style="mso-special-character:
footnote"><!--[if !supportFootnotes]-->[15]<!--[endif]--></span></a>, and who is
thus, like all other humans, forced to suffer life and its essential
expression, the sex act. <o:p></o:p></span></p>
<p class="MsoNormal"><span lang="EN-US" style="mso-ansi-language:EN-US"><span style="mso-tab-count:1">\xA0\xA0\xA0\xA0 </span>The poet, decadent and defeatist at heart,
confronts the horror and vulgarity of triumphant Humidity with dryness and
sterility. But the real and concrete dryness and sterility are, unfortunately,
nothing but that same Humidity reduced to a negligible and impotent amount..
The king, whose impotence has sterilized the whole kingdom, remains on the
Waste Land, this deserted ground,<a href="#_ftn16" name="_ftnref16" style="mso-footnote-id:ftn16" title=""><span style="mso-special-character:footnote"><!--[if !supportFootnotes]-->[16]<!--[endif]--></span></a>
as the "Fisher‑king”, whose unwillingness to resign is to the
disgrace of life and all that belongs to it. The foul, half dried-up river, the
authentic symbol of the Laforguian attitude, is even more disgusting than the
large sea in which Phlébas perishes (in part IV). The rats and the dry bones
are the ever returning symbols of this dryness; which, while being very
sterile, very dry, continues to sustain itself on the small quantity of water
it still holds. <i style="mso-bidi-font-style:normal">The hollow men, </i>the
men stuffed with straw, swaying in the wind, exiled in the country of the
cactus, dance around the rickly pear – this least humid of plants – at five
o'clock in morning, the hour at which human vitality is at its lowest. These
figures from pagan culture are not happier than the typist who "smoothes
her hair with automatic hand" or the Highbury girl who "raised her
knees\xA0supine on the floor of a narrow canoe". And the music to which
they dance (1) is hardly more distinguished than the ballad which accompanies
the springtime return of Sweeney (2)<a href="#_ftn17" name="_ftnref17" style="mso-footnote-id:ftn17" title=""><span style="mso-special-character:footnote"><!--[if !supportFootnotes]-->[17]<!--[endif]--></span></a>
– the eternal male prefigured by Theseus and [lines lost in French version
through printing error, see note]<a href="#_ftn18" name="_ftnref18" style="mso-footnote-id:ftn18" title=""><span style="mso-special-character:footnote"><!--[if !supportFootnotes]-->[18]<!--[endif]--></span></a>
there is no choice between this guard of the fig tree and the massive
quantities of water which absorb Phlébas. The world is imprisoned by the saps
of life, and these slight traces<a href="#_ftn19" name="_ftnref19" style="mso-footnote-id:ftn19" title=""><span style="mso-special-character:footnote"><!--[if !supportFootnotes]-->[19]<!--[endif]--></span></a>
makes this world’s condition even more humiliating and torturing. I. A.
Richards recognized this when he praised Eliot for being the only poet who
offers us a world without beliefs, without ideals, a world deserted by, or
sterile from, values. <o:p></o:p></span></p>
<p class="MsoNormal"><span lang="EN-US" style="mso-ansi-language:EN-US"><span style="mso-tab-count:1">\xA0\xA0\xA0\xA0 </span>But what was a <i>tabula rasa </i>for the
humanist and positivist Richards, whose scientific mind was free of the
prejudices of ‘practical reason’,<a href="#_ftn20" name="_ftnref20" style="mso-footnote-id:ftn20" title=""><span style="mso-special-character:footnote"><!--[if !supportFootnotes]-->[20]<!--[endif]--></span></a>
and to whom therefore this process was a source of delight, Eliot saw as a
horrifying and realistic painting of bourgeois civilization, emptied of faith,
of hope, and of vitality. Eliot himself tells us not to read <i style="mso-bidi-font-style:normal">The Waste <span style="mso-bidi-font-style:
italic">Land </span></i>as a personal and subjective poem, but like the report
of a basic experiment, a social experiment, as it were an elegy on the death of
the bourgeoisie. In prose, Eliot does not show himself a political animal, and
his recent love for politics must be considered unfortunate. Even in his
poetry, directly political allusions are <o:p></o:p></span></p>
<p class="MsoNormal"><span lang="EN-US" style="mso-ansi-language:EN-US">\xA0 <o:p></o:p></span></p>
<p class="MsoNormal"><span lang="EN-US" style="mso-ansi-language:EN-US">(1)<span style="mso-tab-count:1">\xA0\xA0\xA0\xA0 </span>Here we go round the prickly pear <o:p></o:p></span></p>
<p class="MsoNormal"><span lang="EN-US" style="mso-ansi-language:EN-US"><span style="mso-tab-count:1">\xA0\xA0\xA0\xA0 </span>Prickly pear prickly pear <o:p></o:p></span></p>
<p class="MsoNormal"><span lang="EN-US" style="mso-ansi-language:EN-US"><span style="mso-tab-count:1">\xA0\xA0\xA0\xA0 </span>Here we go round the prickly pear <o:p></o:p></span></p>
<p class="MsoNormal"><span lang="EN-US" style="mso-ansi-language:EN-US"><span style="mso-tab-count:1">\xA0\xA0\xA0\xA0 </span>At five o'clock in the morning. <o:p></o:p></span></p>
<p class="MsoNormal"><span lang="EN-US" style="mso-ansi-language:EN-US">(2)<span style="mso-tab-count:1">\xA0\xA0\xA0\xA0 </span>O the moon shone bright on Mrs. Porter <o:p></o:p></span></p>
<p class="MsoNormal"><span lang="EN-US" style="mso-ansi-language:EN-US"><span style="mso-tab-count:1">\xA0\xA0\xA0\xA0 </span>And on her daughter. <o:p></o:p></span></p>
<p class="MsoNormal"><span lang="EN-US" style="mso-ansi-language:EN-US"><span style="mso-tab-count:1">\xA0\xA0\xA0\xA0 </span>They wash their feet in soda water <o:p></o:p></span></p>
<p class="MsoNormal"><span lang="EN-US" style="mso-ansi-language:EN-US">\xA0 <o:p></o:p></span></p>
<p class="MsoNormal"><span lang="EN-US" style="mso-ansi-language:EN-US">often quite
foolish, such as the allusion to the Tartar danger in the first version of “The
Hollow Men” (in the Chapbook of 1924), and in the notes to <i>The Waste Land </i>where
he stoops to quote the pompous nonsense of the German <i>Dostoïevskien</i>
(Herman Hess). But that is hardly surprising: esoteric and obscure as a poet,
Eliot is typical of the current state of the bourgeoisie; typical of those who
experience this final disease of the bourgeoisie acutely and immediately at a
subconscious level, but are unable to speak about it intelligently when they
attempt a clear bourgeois rationale. Eliot’s naïve political efforts to fortify
the dissolving middle-class are of the same category as the obscurity of his
poetry. But the poet has already shown that the middle-class man can only speak
ineptitudes: the world to which he has lent his voice is one of the desert
cactus only, dry and sterile, but not yet ready to give up the little life
which it remains.<a href="#_ftn21" name="_ftnref21" style="mso-footnote-id:ftn21" title=""><span style="mso-special-character:footnote"><!--[if !supportFootnotes]-->[21]<!--[endif]--></span></a><o:p></o:p></span></p>
<p class="MsoNormal"><span lang="EN-US" style="mso-ansi-language:EN-US"><span style="mso-tab-count:1">\xA0\xA0\xA0\xA0 </span>But Eliot did not want to waste time on
deserted Earth, nor was he content to remain a hollow man. As heir to the <i>poets
maudits,</i> he wanted to escape from the desert, and, like the Rimbaudian
Claudel, he chose religion to be his guiding star. However, and this emphasized
the superiority of Eliot’s integrity over Claudel’s, what he sought and found
was not a revival of a dead civilization, was not a dressed up positivist
system of rusting symbolism, but an escape from a seasonal vicious circle in an
unreal dimension. What Eliot required of religion was an existence which would
not hold anything of the life here on earth; it had to be a religion of purity,
a spirituality free from any vitality, free from psychology; a purely
pneumatic, mystical religion in the strictest sense of the term and one that
was severely intellectualist besides. Rejecting any symbolism which set out to
sanctify life, Eliot found in Fire the symbol of what he was seeking. He opposed
the flowers which make the evil forces of life seem charming, the Aridity which
only reduces life to a meaningless struggle, with the Fire that terminates any
germ carrying life, smothers any lust whether it is strong or weak, the Fire
which is devoid of any attachment to the floods of the phenomenal and personal.
Arnaud Daniel,<a href="#_ftn22" name="_ftnref22" style="mso-footnote-id:ftn22" title=""><span style="mso-special-character:
footnote"><!--[if !supportFootnotes]-->[22]<!--[endif]--></span></a> “refined”
by the flames of the purgatory\xA0 <span style="mso-bidi-font-weight:bold">becomes
the symbol </span>of the rise towards this Shantih,<a href="#_ftn23" name="_ftnref23" style="mso-footnote-id:
ftn23" title=""><span style="mso-special-character:footnote"><!--[if !supportFootnotes]-->[23]<!--[endif]--></span></a>
of which “peace which passeth understanding” is only a weak translation. <o:p></o:p></span></p>
<p class="MsoNormal"><span lang="EN-US" style="mso-ansi-language:EN-US"><span style="mso-tab-count:1">\xA0\xA0\xA0\xA0 </span>Already in <i style="mso-bidi-font-style:
normal">The Waste Land </i>(in spite of what Richards said of it), the symbol
of Fire is found to be victorious over the symbols of Humidity and Aridity.
Between this poem and the purely religious poems to which Eliot’s poetic output
was reduced from 1927 onwards, are a group of highly important writings,
including the fragments of an unfinished drama (of which <i style="mso-bidi-font-style:
normal">The Hollow Men </i>originally appears to have formed a part) and
writings in prose, the most interesting of which is the essay on the 17<sup>th</sup>
century Anglican preacher Lancelot Andrewes. Andrewes is right up Eliot’s
street, because it allows him to contrast a purely intellectualist mystic with
the carnal and psychological Donne, who confessed himself to be disturbed “by a
memory of the pleasures of yesterday ... , by a strand of straw under the knee,
by a noise in my ear, a light in my eye” at the time of prayer. Donne a very
suitable scapegoat for Eliot’s wish to demonstrate that religion can only be
religious when it is founded, not in the psychological plasma of lust, but in
pure, pneumatic fire. The historical differences between Donne and Eliot which
I discussed earlier surface admirably in the contrast between the active
asceticism of Donne, an exuberant personality with a robust vitality to fight
and overcome, and the bloodless asceticism of Eliot, whose fire has only cacti
to burn. The essay on Andrewes is certainly the most significant of all Eliot’s
prose writings; still more interesting is his remarkable <i style="mso-bidi-font-style:
normal">Fragment <span style="mso-bidi-font-style:italic">of an </span>Agon </i>(<i>Criterion</i>,
1927), where the topic of life is taken up again in an even more realistic and
vulgar tone than before. In <i>Fragment</i>, Eliot finds a formula expressing
the ultimate horror of life with extraordinary force (combining a skilful use
of dissonance with a nauseating vulgarity): “birth, and copulation, and death”
– And to leave little doubt concerning the morality of <i>Fragment</i>, its
epigraph consists of the words of St John of the Cross, on the heart which
cannot unite itself with God because it has not yet “divested itself of the
love of created beings”. <o:p></o:p></span></p>
<p class="MsoNormal"><span lang="EN-US" style="mso-ansi-language:EN-US"><span style="mso-tab-count:1">\xA0\xA0\xA0\xA0 </span>In the religious poems of late, Eliot’s
style narrows and becomes increasingly "small and dry”. The grand
symphonic movements of <i style="mso-bidi-font-style:normal">Gerontion, The
Waste Land, The Hollow Men </i>and <i style="mso-bidi-font-style:normal">Fragment
of an Agon </i>do not return. The poet’s bones are increasingly refined in the
purgatorial fire; the air becomes increasingly empty and strange. The life he
seeks is most certainly divorced from the carnal life and does not resemble its
earthly cousin in any way. He cannot find the values that must save sterile and
dry middle-class man neither in carnal life, nor in historical reality; the
kingdom which he seeks is not of this world. Thus speaks Eliot the poet. Eliot
the publicity agent ostentatiously believes in the possibility of integrating
life with the value of the spiritualist mystic, to make these two the cause of
the ideology to affirm "Classicism in literature, Anglo Catholicism in
religion, and Royalism in politics" (cf. foreword of the single volume
edition of <i style="mso-bidi-font-style:normal">For Lancelot Andrewes</i><span style="mso-bidi-font-style:italic">, 1928</span><i style="mso-bidi-font-style:
normal">). </i>His poetry, however, reveals this ideology to be nothing, and
adds that the nothing of the fire <i>che es gli affina </i>is the better, purer
nothing.<a href="#_ftn24" name="_ftnref24" style="mso-footnote-id:ftn24" title=""><span style="mso-special-character:
footnote"><!--[if !supportFootnotes]-->[24]<!--[endif]--></span></a> <o:p></o:p></span></p>
<p class="omnipage1" style="margin:0cm;margin-bottom:.0001pt"><span lang="EN-US" style='mso-bidi-font-size:10.0pt;font-family:"Times New Roman";mso-fareast-font-family:
"Times New Roman";mso-ansi-language:EN-US'>\xA0 <o:p></o:p></span></p>
<p class="MsoNormal"><span lang="EN-US" style="mso-ansi-language:EN-US">D. S.
MIRSKY. <o:p></o:p></span></p>
<p class="MsoNormal"><span lang="EN-US" style="mso-ansi-language:EN-US"><!--[if !supportEmptyParas]-->\xA0<!--[endif]--><o:p></o:p></span></p>
<div style="mso-element:footnote-list"><!--[if !supportFootnotes]--><br clear="all"/>
<hr/>
<!--[endif]-->
<div id="ftn1" style="mso-element:footnote">
<p class="MsoFootnoteText"><a href="#_ftnref1" name="_ftn1" style="mso-footnote-id:ftn1" title=""><span style="mso-special-character:footnote"><!--[if !supportFootnotes]-->[1]<!--[endif]--></span></a><span lang="EN-GB"> I only speak of French and English bourgeois poetry. In America and
in Germany things are slightly different. In America, a popular element
(petit-bourgeois) is still very much alive and purely bourgeois poetry is only
one school among several. In Germany the decomposition of bourgeois society is
so tangible that the social topic couldn't be ignored even by bourgeois poets.</span></p>
</div>
<div id="ftn2" style="mso-element:footnote">
<p class="MsoFootnoteText"><a href="#_ftnref2" name="_ftn2" style="mso-footnote-id:ftn2" title=""><span style="mso-special-character:footnote"><!--[if !supportFootnotes]-->[2]<!--[endif]--></span></a><span lang="EN-GB"> The decomposition of the bourgeoisie proceeds by opposition. The
tendency to demagnetise language and to turn it into a purely private matter is
distinct from and at the same time complementary to the effort of the detaching
meaning from language, in order to create a logic free of all verbal
associations. Readers of Edith Sitwell are mostly the same as those of Bertand
Russell, whose "Principles of Mathematics" is the gospel of the
logicians.</span></p>
</div>
<div id="ftn3" style="mso-element:footnote">
<p class="MsoFootnoteText"><a href="#_ftnref3" name="_ftn3" style="mso-footnote-id:ftn3" title=""><span style="mso-special-character:footnote"><!--[if !supportFootnotes]-->[3]<!--[endif]--></span></a><span lang="EN-GB"> <i>Translators note – the idea Mirsky implies but does not
formulate further is that the topic a poet chooses is what positively or
negatively charges his work. ‘Demagnetising’, removing positive or negative
charges, used at the end of the previous paragraph, should be understood in
this context.</i> </span></p>
</div>
<div id="ftn4" style="mso-element:footnote">
<p class="MsoFootnoteText"><a href="#_ftnref4" name="_ftn4" style="mso-footnote-id:ftn4" title=""><span style="mso-special-character:footnote"><!--[if !supportFootnotes]-->[4]<!--[endif]--></span></a><span lang="EN-GB"> European; America still had Walt Whitman. As was the case for the
"poetes maudits", his own generation did not understand him, but the
reason for this incomprehension was completely different. The spirit that drove
Whitman was that of the democratic bourgeoisie of the Northern States, adverse
to slavery, “burning the tracks across the continent, and evaluating
California”, but the conscience and the culture of this democracy still
remained so provincial, so much imprisoned by the old English values, that the
absolutely new forms into which Whitman molded his poetry, could not be
assimilated by those of which it expressed the sentiment.</span></p>
</div>
<div id="ftn5" style="mso-element:footnote">
<p class="MsoFootnoteText"><a href="#_ftnref5" name="_ftn5" style="mso-footnote-id:ftn5" title=""><span style="mso-special-character:footnote"><!--[if !supportFootnotes]-->[5]<!--[endif]--></span></a><span lang="EN-GB"> All the more true since the philosophy of <i>l’atto puro</i> [the
Pure Act] by Giovanni Gentile, its content seemingly so well adapted to fascist
needs, still couldn't be adopted by Fascism. As anti-intellectual as his
philosophy may be, by the mere fact of it being a philosophy, that is to say an
intellectual manifestation is incompatible with fascism.</span></p>
</div>
<div id="ftn6" style="mso-element:footnote">
<p class="MsoFootnoteText"><a href="#_ftnref6" name="_ftn6" style="mso-footnote-id:ftn6" title=""><span style="mso-special-character:footnote"><!--[if !supportFootnotes]-->[6]<!--[endif]--></span></a><span lang="EN-GB"> <i>translator’s note – i.e., death.</i></span></p>
</div>
<div id="ftn7" style="mso-element:footnote">
<p class="MsoFootnoteText"><a href="#_ftnref7" name="_ftn7" style="mso-footnote-id:ftn7" title=""><span style="mso-special-character:footnote"><!--[if !supportFootnotes]-->[7]<!--[endif]--></span></a><span lang="EN-GB"> <i>translator’s note – Mirsky uses ‘lesion’, further stressing the
cut.</i></span></p>
</div>
<div id="ftn8" style="mso-element:footnote">
<p class="MsoFootnoteText"><a href="#_ftnref8" name="_ftn8" style="mso-footnote-id:ftn8" title=""><span style="mso-special-character:footnote"><!--[if !supportFootnotes]-->[8]<!--[endif]--></span></a><span lang="EN-GB"> <i>translator’s note – Mirsky’s terms really come down to ‘Wind,
Water, (Earthm) and Fire’, but this terminology is used throughout the text to
support his semantic<span style="mso-spacerun: yes">\xA0 </span>playfulness.</i><span style="mso-spacerun: yes">\xA0 </span></span></p>
</div>
<div id="ftn9" style="mso-element:footnote">
<p class="MsoFootnoteText"><a href="#_ftnref9" name="_ftn9" style="mso-footnote-id:ftn9" title=""><span style="mso-special-character:footnote"><!--[if !supportFootnotes]-->[9]<!--[endif]--></span></a><span lang="EN-GB"> I suggest a comparison between <i>The Waste Land </i>and <i>L'Age
d'or</i>. Such a comparison would reveal how similar the method of composition
employed in these two works really is. Needless to say, surrealist cinema has
not learnt any of this from Eliot. The method is inherent to all art based on
the subconscious</span></p>
</div>
<div id="ftn10" style="mso-element:footnote">
<p class="MsoFootnoteText"><a href="#_ftnref10" name="_ftn10" style="mso-footnote-id:ftn10" title=""><span style="mso-special-character:footnote"><!--[if !supportFootnotes]-->[10]<!--[endif]--></span></a><span lang="EN-GB" style="mso-ansi-language:EN-US"> </span><i><span lang="EN-US" style="mso-ansi-language:EN-US">translator’s note – from </span></i><span lang="IT" style="mso-ansi-language:IT">seicento</span><i><span lang="EN-US" style="mso-ansi-language:EN-US">, Italian for six hundred. It refers in fact to
the literary movement of the seventeenth century, which was the counterpart of
baroque and was a reaction against classicism. It is characterized by a strong
taste for elaborate conceits.</span></i><span lang="EN-US" style="mso-ansi-language:
EN-US"><o:p></o:p></span></p>
</div>
<div id="ftn11" style="mso-element:footnote">
<p class="MsoFootnoteText"><a href="#_ftnref11" name="_ftn11" style="mso-footnote-id:ftn11" title=""><span style="mso-special-character:footnote"><!--[if !supportFootnotes]-->[11]<!--[endif]--></span></a><span lang="EN-GB" style="mso-ansi-language:EN-US"> </span><i><span lang="EN-US" style="mso-ansi-language:EN-US">translator’s note – as yet unidentified quote.</span></i><span lang="EN-US" style="mso-ansi-language:EN-US"><o:p></o:p></span></p>
</div>
<div id="ftn12" style="mso-element:footnote">
<p class="MsoFootnoteText"><a href="#_ftnref12" name="_ftn12" style="mso-footnote-id:ftn12" title=""><span style="mso-special-character:footnote"><!--[if !supportFootnotes]-->[12]<!--[endif]--></span></a><span lang="EN-US" style="mso-ansi-language:EN-US"> the flowers are the principal
symbol of life and continue to charm Eliot even in his last poems. Other
symbols which have the same function, and which he handles with extreme
delicacy, are the birds (the American blackbird of <i style="mso-bidi-font-style:
normal">The Waste Land), </i>the soft and light wind (the zephyr of the
classicist), and women’s hair.<o:p></o:p></span></p>
</div>
<div id="ftn13" style="mso-element:footnote">
<p class="MsoFootnoteText"><a href="#_ftnref13" name="_ftn13" style="mso-footnote-id:ftn13" title=""><span style="mso-special-character:footnote"><!--[if !supportFootnotes]-->[13]<!--[endif]--></span></a><span lang="EN-GB" style="mso-ansi-language:EN-US"> </span><i><span lang="EN-US" style="mso-ansi-language:EN-US">translators note – a method of studying
religion, which compares religions and studies their similarities and
differences. This discipline became widely popular as tension between science
and Christianity increased people’s dissatisfaction with Christianity and made
them more sympathetic towards other systems of belief</span></i><span lang="EN-US" style="mso-ansi-language:EN-US"><o:p></o:p></span></p>
</div>
<div id="ftn14" style="mso-element:footnote">
<p class="MsoFootnoteText"><a href="#_ftnref14" name="_ftn14" style="mso-footnote-id:ftn14" title=""><span style="mso-special-character:footnote"><!--[if !supportFootnotes]-->[14]<!--[endif]--></span></a><span lang="EN-GB" style="mso-ansi-language:EN-US"> </span><i><span lang="EN-US" style="mso-ansi-language:EN-US">translator’s note – ‘both sexes’</span></i><span lang="EN-US" style="mso-ansi-language:EN-US"><o:p></o:p></span></p>
</div>
<div id="ftn15" style="mso-element:footnote">
<p class="MsoFootnoteText"><a href="#_ftnref15" name="_ftn15" style="mso-footnote-id:ftn15" title=""><span style="mso-special-character:footnote"><!--[if !supportFootnotes]-->[15]<!--[endif]--></span></a><span lang="EN-GB" style="mso-ansi-language:EN-US"> </span><i><span lang="EN-US" style="mso-ansi-language:EN-US">translator’s note – cf. TWL, lines 227-8: “On
the divan are piled (at night by her bed)\xA0 / Stockings, slippers,
camisoles, and stays.”\xA0Mirsky interprets “at night by her bed” as
indicating that the divan is her bed at night, but the bracketed comment may as
well refer to the clothes, which would be piled by her bed at night – although
of course the two interpretations are not mutually exclusive.</span></i><span lang="EN-US" style="mso-ansi-language:EN-US"> <o:p></o:p></span></p>
</div>
<div id="ftn16" style="mso-element:footnote">
<p class="MsoFootnoteText"><a href="#_ftnref16" name="_ftn16" style="mso-footnote-id:ftn16" title=""><span style="mso-special-character:footnote"><!--[if !supportFootnotes]-->[16]<!--[endif]--></span></a><span lang="EN-GB" style="mso-ansi-language:EN-US"> </span><span lang="EN-US" style="mso-ansi-language:EN-US;mso-bidi-font-style:italic">I do not think </span><i style="mso-bidi-font-style:normal"><span lang="EN-US" style="mso-ansi-language:
EN-US">le terre Mise a nu, (The earth exposed), </span></i><span lang="EN-US" style="mso-ansi-language:EN-US;mso-bidi-font-style:italic">the title </span><span lang="EN-US" style="mso-ansi-language:EN-US">Jean de Menasce uses in his French
translation, is a satisfying rendition of the English title.<o:p></o:p></span></p>
</div>
<div id="ftn17" style="mso-element:footnote">
<p class="MsoFootnoteText"><a href="#_ftnref17" name="_ftn17" style="mso-footnote-id:ftn17" title=""><span style="mso-special-character:footnote"><!--[if !supportFootnotes]-->[17]<!--[endif]--></span></a><span lang="EN-GB"> <i>The text which we translated did not refer to the Mrs Porter
song here or anywhere else, but </i></span><i><span lang="EN-US" style="mso-ansi-language:EN-US">I am guessing this is where it was supposed to
be – both fragments are based on popular ballads.</span></i></p>
</div>
<div id="ftn18" style="mso-element:footnote">
<p class="MsoFootnoteText"><a href="#_ftnref18" name="_ftn18" style="mso-footnote-id:ftn18" title=""><span style="mso-special-character:footnote"><!--[if !supportFootnotes]-->[18]<!--[endif]--></span></a><span lang="ES-TRAD" style="mso-ansi-language:ES-TRAD"> – cet eternal male prefigure
par Thesee <i>et le peu d’eau que garde emmagasine le figuier de Barbarie il
n’y a pas </i>de salut. Entre les grandes eaux qui engloutissent Phlebas <i>et
le peu d’eau que garde emmagasinee le figuier de Barbarie il n’y a pas</i> a
choisir.<o:p></o:p></span></p>
</div>
<div id="ftn19" style="mso-element:footnote">
<p class="MsoFootnoteText"><a href="#_ftnref19" name="_ftn19" style="mso-footnote-id:ftn19" title=""><span style="mso-special-character:footnote"><!--[if !supportFootnotes]-->[19]<!--[endif]--></span></a><span lang="EN-GB" style="mso-ansi-language:EN-US"> </span><i><span lang="EN-US" style="mso-ansi-language:EN-US">translator’s note –<span style="mso-spacerun:
yes">\xA0 </span>i.e. the stinking river Mirsky mentioned earlier, and also
perhaps the soda water to which Mirsky refers above. <o:p></o:p></span></i></p>
</div>
<div id="ftn20" style="mso-element:footnote">
<p class="MsoFootnoteText"><a href="#_ftnref20" name="_ftn20" style="mso-footnote-id:ftn20" title=""><span style="mso-special-character:footnote"><!--[if !supportFootnotes]-->[20]<!--[endif]--></span></a><span lang="EN-GB"> <i>Translator’s note - cf. Kant’s</i> Critique of Practical Reason</span></p>
</div>
<div id="ftn21" style="mso-element:footnote">
<p class="MsoFootnoteText"><a href="#_ftnref21" name="_ftn21" style="mso-footnote-id:ftn21" title=""><span style="mso-special-character:footnote"><!--[if !supportFootnotes]-->[21]<!--[endif]--></span></a><span lang="EN-GB" style="mso-ansi-language:EN-US"> </span><i><span lang="EN-US" style="mso-ansi-language:EN-US">translator’s note – cf. Mirsky’s comments on
the Fisher King, above.</span></i><span lang="EN-US" style="mso-ansi-language:
EN-US"><o:p></o:p></span></p>
</div>
<div id="ftn22" style="mso-element:footnote">
<p class="MsoFootnoteText"><a href="#_ftnref22" name="_ftn22" style="mso-footnote-id:ftn22" title=""><span style="mso-special-character:footnote"><!--[if !supportFootnotes]-->[22]<!--[endif]--></span></a><span lang="EN-US" style="mso-ansi-language:EN-US"> Already the title (of the 1920
edition), <i>Ara Vos Prec</i>, is an allusion to this speech of the Provencal
poet, who appears in the 26th song of Dante’s Purgatory.<o:p></o:p></span></p>
</div>
<div id="ftn23" style="mso-element:footnote">
<p class="MsoFootnoteText"><a href="#_ftnref23" name="_ftn23" style="mso-footnote-id:ftn23" title=""><span style="mso-special-character:footnote"><!--[if !supportFootnotes]-->[23]<!--[endif]--></span></a><span lang="EN-US" style="mso-ansi-language:EN-US"> Buddhist Term, the repetition of
which finishes <i style="mso-bidi-font-style:normal">The Waste Land.</i><o:p></o:p></span></p>
</div>
<div id="ftn24" style="mso-element:footnote">
<p class="MsoFootnoteText"><a href="#_ftnref24" name="_ftn24" style="mso-footnote-id:ftn24" title=""><span style="mso-special-character:footnote"><!--[if !supportFootnotes]-->[24]<!--[endif]--></span></a><span lang="EN-GB"> <i>translator’s note – the fire which refines.</i></span></p>
</div>
</div>
<p>\xA0</p></td>
</tr>
</table>
</center>
</div>
`,s=`T. S. Eliot and The End of Bourgeois Poetry by D. S. Mirsky (translated by Gunnar Jauch, Annelie Hultén, and Arwin van Arum) I believe T. S. Eliot has no equal among the bourgeois poets of today, in France or in England. I know the regime of the literary society which has established itself now for more than one generation of bourgeois poets makes it all the more difficult to sustain this claim; the glories of poetry are confined to Chapels, and I have not nearly visited all of them. It is quite possible that those which I have not visited may be concealing poets no less remarkable than Eliot. The technical difficulty of paying a visit to all these Chapels is, however, not as great as the difficulty of learning all of the resident languages: a fundamental aspect of these kind of societies is that each has its own exclusive idiom, and they are idioms of a kind that cannot be quickly mastered. Eliot’s own growing fame has contributed more than one example of this linguistic difficulty. Thousands of readers have failed when confronted by the obscurity of his poetic grammar, and even experienced critics (notably I. A. Richards and Edwin Muir) have been careless enough to analyse his work without learning his language first. This obscurity of contemporary poets cannot be reduced to the simple problem of logic, to these almost mandatory elliptical accumulations, which on first sight make contemporary poetry seem a disquieting and indecipherable shorthand. Even worse is that each poet has his own symbolic language, but does not bother to explain this language to the reader so that it becomes intelligible only to experienced psychoanalysts. The poet does not want to be understood. The reader does not want to understand, either. Poetry has ceased to be a means of communication; the poetical forum has become a market of snobbism on which one learns to trade without considering its intrinsic content. Poetic glories have become mere fortuities, linked to poetically insignificant individuals. On the stock exchange of values, poets possess nothing that yields interest to either the literature scholar or the sensibility of the dying bourgeoisie. Nothing is being said about anything the reader likes or understands. Poetry has devaluated to being merely an aspect of social organization, relevant perhaps to sociologists or economists, but to nobody else. But do bourgeois poets deserve any better? Is there anything more to them than their disconcerting displays of originality? Poetry has never been as devoid of meaning and of valid social content [1] as now. The worlds these poets construct are rigorously ‘private’ – they are as arbitrary and exclusive as dreams. Nobody needs this. Watching them pass by has become a mere mind-game. Sentiment (with which I mean all that contains a value judgement) can find nothing to react to. All that remains of these poets’ efforts is their deformation of the language (in the widest sense of the term), emptying it of all social content, ‘demagnetising’ [2] it. Standing out from this core of crossed-word and mixed-image brokers are a small number of poets whose work holds at least some interpersonal interest. And among them, an even smaller number actually has anything truly significant to say. The importance of a poet derives from two variables: his poetic power, and the human and historical relevance of his topic. The poetic power itself has a neutral value, comparable to a cannon whose destructive power does not depend on the cause it is used for. [3] These two elements had a strong tendency to coincide in the grand poets of preceding times: Dante, Milton and Goethe were at once the mightiest voices and the most representative spirits of their respective eras. Victor Hugo was the last of the great poets [4] who were at the same time popular and a representative of the living forces of their era. But bourgeois poetry, emasculated of the last remnants of its revolutionary power, ceased to be fertile even before Hugo’s death. From Tennyson, Longfellow and Sully-Prudhomme onwards poets have become no more than eunuchs detaining the public ear, and the only poetic power left were the "poetes maudits", with Rimbaud as their prime representative. These poets were no longer moved by the hopes and ideals of a vigorous class, but by the tragic contradictions of a society dominated by a class in a stage of latent but incurable decomposition. They were no revolutionaries, but symptoms of a state of affairs where revolution should have been the only issue. Their poetry became a button which set off the bourgeoisie’s festering decomposition at an explosive speed and with likewise power. Being a ‘poete maudit’ was not easy, these were "tragic heroes", scapegoats singled out to be sacrificed for the sins of the tribe. The truest of them perished literally. Their deaths left behind a potent vaccine for posterity, which, after the tragic deaths of Verlaine and Rimbaud, degenerated to a spicy seasoning for the meals of the decomposing middle-class. The contrast between the disgrace of Rimbaud's living conditions and his posthumous glory among today’s elite – a glory so tangible that the most expensive bar of the quartier latin in Paris bears the name of Rimbaud’s most celebrated poem – represents the contrast between a time when the death of bourgeois civilization haunted only the most inspired of Cassandras, and a time when that same death has become an object of daily consumption – after all, one might as well make death consumable when one is forced to consume it anyway. Today, the potent chemicals left us by the "poetes maudits" have been reduced to a harmless goo. For most poets, they have become only more or less dominant ingredients to be added to their bowl of stirred images. Other poets who did imbued the vaccine, have become immune by making the vaccine a springboard, a point of departure from which they can leave a positive value system. But unfortunately, under the current regime of bourgeois civilization, which is itself incapable of producing a value system, they can only produce dummy values, intellectually unacceptable and historically false, borrowed from more fertile eras but profoundly alien to ours. Such is the nature of Claudel's Catholicism. Asked who was the greatest poet in France, Andre Gide answered: "Victor Hugo, alas", which is a respectable answer from one the last members of the bourgeois decadence, who finds the robust self-sufficiency of a less corrupt age ridiculous and vulgar; an answer worthy enough of an intelligent critic who knows how to appreciate without liking. One ought to answer the question who is currently our greatest French poet in the manner of Gide: "Paul Claudel, alas". There can be no doubt that Claudel's voice is the ablest among the French authors of today. But this poetic ability serves an ideology, the acceptance of which only demonstrates the extent of the bourgeois poets’ moral and intellectual disintegration. Hugo's democratic vitality was a religion that lived for its time; Claudel's Catholicism is a hole in the sand in which the ostrich-like poet believes to be sheltered from sad, sad reality, a refuge where the shirker of history tries to shelter himself from the approaching future. Morally it is a flight, a cowardice; intellectually an abdication, for only by blinding one’s intelligence can such a fantastic and unreal system be accepted. Claudel's poetry is not empty in the way typical decadent bourgeois poetry is; it is worse. He has inflated his poetry with negative matter, invested it with a power that serves an unreal and negative goal – all too typical of the dying bourgeois civilization: Claudel's poetry is not unlike the immense amount of negative energy that was shed in the Great War. What distinguishes Eliot from all these poets is that in him, an exceptional poetic power has allied itself to a truly important social theme, indeed, the only historically valid and sincere theme that remains a bourgeois poet in our time. Where his contemporaries are themselves nothing but manifestations of the death of bourgeois civilization, he alone has been able to create a poetry of death. Eliot's theme is the only one available for a poet of the decadent bourgeoisie. For a true poet is a true poet also for having an understanding, an 'intuition' if you will, of the historical reality that his understanding has to be more or less self-conscious. One could object that there is another possibility, that the fight against the past by a class dedicated to death could well be the source of inspiration for a poet of bourgeois imperialism. But Lucain's Caton, the typical militant of this condemned class, is a figure devoid of high poetry. Why could fascism not inspire a poet of Eliot's size? Because long before its physical and military defeat bourgeoisie lost everything justifying, even to itself, its struggle against the class that will superannuate it. The bourgeoisie is devoid of values and all the living values are on the side of the working class. If a bourgeois poet, or ideologist, wants to confront the revolution with something positive and convincing (convincing to himself also), he has no other option but to rely on the resurrection of some medieval ghost – such is Claudel's Catholicism – with the consequence that inevitably he will become irrelevant to his contemporaries. The fight of the bourgeoisie against the revolution is ideologically sterile. Fascism is merely an atto puro , an action without rational aim or justification beyond the action itself. [5] Fascism is a mere binge, a drinking-bout that blinds all reason and intelligence and reduces mankind to a system of reactions, sterile from conscience. Like Dr. Watson's rats, the system constitutes of behaviour only and of the hypothesis that conscience is superfluous to explain its movements. Fascism cannot have its own poet, and for today's bourgeois poet Fascism cannot be a topic: the only one left to him is Death. Death is a very interpersonal theme, since it is firmly grounded in both history and society. But it is hardly a popular theme. The poet who takes it as the leitmotif of his oeuvre by definition lacks popular elements, in every sense of the word ‘popular’. Besides, the ‘private’ and exclusive style developed by the bourgeois poets of recent decades serves excellently for poker-facing a lost game, and insisting on that to which one can but resign oneself. [6] Taken from that point of view, Eliot's obscurity becomes very interesting. Eliot is obscure. He is so consciously, aggressively – obscure with a vengeance. One might even call him a champion of obscurity, of the poet's right not to be understood. But his complexity is different from that of most of his contemporaries. The latter go to great lengths to be incomprehensible simply because they have nothing to say worth understanding. For Eliot, obscurity is a weapon with which he defend defends himself; it allows him to speak of secret things the populace was never meant to understand. Yet the content of his poetry is not in the least obscure. It is not a private world of hybrid images expressed by means of symbols that were carefully sifted from the most perplexing bunch that a troubled and putrescent subconscious could come up with. Eliot’s poetry is essentially based on a social and universal experience, an experience which on the level of the individual manages to encompass a full perspective of the death of a civilization. To be explicit about this would, however, have been lacking in refinement, it would have been a betrayal to revered simplicity. Strong inhibitions (due in part, as has been too often insisted upon, to a Puritan upbringing and to the inferiority complex of American highbrows, for whom not having been born an Englishman hurts like an incurable wound [7] ) have come to Eliot's aid and simplified the task of obscuring that which might otherwise have become too obvious. A closer analysis of his poetry shows that his obscurity is all superficial, superimposed, created out of ellipses and silences. The content, the system of symbols with which he works, is remarkably transparent and there is nothing affected or arbitrary about it. Its order and logic are so rigorous that one might classify Eliot's oeuvre as allegory. The Waste Land is wholly structured around three fundamental symbols: Humidity, Aridity, and Fire. [8] These symbols are predominant throughout almost his entire oeuvre. His obscurity is superimposed onto this clear and simple drama. It is above all to be found in the sequence of the images, in this ingenious and confusing poetic 'montage' which brings Eliot close to surrealism – especially to surrealist cinema, of which he is the unacknowledged precursor. [9] Eliot's poetry is, like all great decadent poetry, at once violently innovative and solidly traditional, retrospective even. One might call the tradition to which he attaches himself that of the English secentismo , [10] that influential school which begins with Shakespeare and Chapman, finds its most individual expression in Donne and Webster, and, then, after a long period of decline, is briefly revived in the works of Pope. Laforgue chiselled his light irony onto this strong and heavy pillar, and Eliot keeps much of this incongruous juxtaposition of secentist sonorities placed under the ironic damper of French decadence in his own style – the Eliotic ‘montage’ owes many of its best effects to these paragraphs of blank verse which are easily mistaken to be Elizabethan at first, but then suddenly broken off by a vulgar modern dissonance. The power that the English secentism has over Eliot is the result of a complex play of attraction and repugnance. Since he is the last poet of the English bourgeoisie, it is only natural he should be drawn to this Golden Age of English poetry. But there is more to it. This golden age had its element of decadence too, and this adds to the attraction. It was a time of transition during which a young bourgeois civilization was still caught up in the last forms of medieval decadence. Alongside a truly modern elite, whose most notable names were Bacon and Hobbes, persisted an elite still attached to the Church, the feudal system, and whom still considered scholasticism, astrology, and alchemy to be relevant disciplines; the most influential and characteristic poet representative of this elite is Donne. Eliot’s current position is in several respects similar to that of Donne three hundred years ago. Donne represents something which has been fairly uncommon in the past: a real poet endowed with great poetic power, whose theme is historically viable, but who is nevertheless esoteric rather than popular – which is quite common for poets who belong to a superannuated elite. But Donne’s class was not under threat of the kind of complete extinction that the class which Eliot descends from is under. Donne's class would survive for a while yet, needing only to reject certain outmoded values to be able to adapt itself to a new era with relative ease. And so, while Donne’s effort to remain obscure mainly reveals his attachment to everything his class had to abandon in order to survive, Donne introduces the theme of death under very different auspices than Eliot does. These similarities and differences betwixt the two poets are reflected in Eliot's attitude towards Donne, an attitude marked by complexity and ambivalence. Drawn to him by an affinity too great to be ignored, Eliot at the same time fights against that which he finds alien and hostile in the older poet – his disciplined yet ever living flesh, his soul, and his psyche, which cannot detach itself from the flesh to become pure spirit, pneuma . The affinity between Eliot and Laforgue is more direct and immediate. In the poetic family-tree, this poet is Eliot’s true father: the ties which bind them together manifest themselves above all in Eliot's early poems (those collected in Prufrock and Other Observations (1917) and Ara Vos Prec (1920)) only to disappear almost completely in his mature works. Laforgue was not a poète maudit . He was only an epigone of Romanticism. In other words, his soul was not laid bare by the crumbling of bourgeois values, but rather directed towards a ‘green paradise' to be created after the inferno of capitalism. The true romantic, however, is the petty, degraded bourgeois who still cherishes memories of an idyllic order, still hoping to recover his paradise through a utopian revolution (Baudelaire in 1848), through faith (Baudelaire on his death-bed), through dreams (like the great opium smokers of English Romanticism), or through a dream-like death. If the romantic tries to escape the bourgeois world, then not because he can see its corruption and has fore-suffered its death. On the contrary, he wishes to escape because he sees that the world is strong and stable, and he neither can nor wants to adapt to it, finds it inhospitable. If we compare the decadent romantics of the fin de siècle with the first generation of romantics, we find that the former differ from the latter mainly in that they have much less faith in the reality of a romantic paradise and put far more emphasis on the cult of disease. The first romantics lived in an era when the “dark Satanic Mills” had only just begun invading “England's green & pleasant Land” (Blake). The pre-capitalist idyll was still a reality for them; they believed in something tangible. Besides, their inability to adapt to the capitalist struggle for life was not put down to defects, personal insufficiencies, it was still the sign of a class which would not admit defeat and was full of life, energy. A hundred years later, this ideal remained only in the form of dreams, and the inability to adapt was increasingly associated with personal failure, with illness and physical weakness. Romantic irony was attracted to death as the only possible route of escape to a paradise “where all is but order and beauty”, [11] but which is more likely to be a useless “all-inclusive sinecure”, such as permeates Laforgue's poetry (this irony also becomes the point of departure for the clownery which is the poet's revenge on the philistine, and which also the young Eliot practised, not without success). In Laforgue, the irony is associated with the characteristic behaviour of someone suffering from tuberculosis, not willing to resign himself to death and desperately trying to hold onto life as it slips away from him. There is, in his poetry, an atmosphere of impurity, a permanent itch linked to sexual impotence, and an ironic sentimentality which makes fun of that which it cowardly adores in secret. This Laforguian atmosphere permeates Eliot's early poems and only little by little can one see a completely different kind of poetry stand out against this background, a poetry liberated from the decadent poet's wavering ambiguities, a poetry where irony is slowly eclipsed by tragedy, and the consumptive artist’s sexual ambivalence is slowly being replaced with the renunciation of the ascetic. Eliot's critics tend to make much of his romantic irony, these contrasts which repeat the action in two different keys – one sublime, the other sordid. This is the kind of irony which prevails in the satiric poems of Ara Vos Prec : in “Sweeney Erect”, the banal scene of a man shaving himself peacefully, not paying any attention to the hysterical convulsions of the girl he has just made love to, is compared to the story of Theseus and Ariadne in sublimely declamatory lines; in "Sweeney Among the Nightingales", the shoddy machinations of a Montmartre bar owner and a whore who plan to cheat a customer, evoke images of Clytemnestra's conspiracy against Agamemnon. Even later, in the famous third part of The Waste Land , we find the splendour of Queen Elizabeth and her lover, the Earl of Leicester, sailing down the Thames, and the image is juxtaposed with the sordidly tragic loves of the “Thames daughters” who live among “trams and dusty trees” and die among the oil slicks polluting the river and among the tins which litter the popular beaches. All these episodes should probably be connected to Laforgue and the romanticism of the decadent poets. But in the new context created for them by Eliot, they no longer emboss the irony of contrasts. The opposition between the same situation played out either pleasing or ugly no longer prevails, the pity and horror of the reality of life is now common to both versions. Heroic love is not brought out to enhance its sordid equivalent, nor is sordid love used to ridicule heroic love. The eternal identity of sexual love in all its manifestations – whatever dress it may wear – is what evokes pity and terror. The poet has left the limitations of romanticism behind. Humidity and Aridity are the two fundamental symbols of the cycle which starts with Gerontion (Ara Vos Prec) and to which The Waste Land is central . Humidity, whose principle manifestations are water and flowers, stands for life, sex, the eternal return of the seasons, the variety of the carnal and psychic life, and the world of passion and of feeling. There is certainly ambivalence in Eliot’s attitude towards Humidity; his stance is not so much one of repulsion, but rather, as the fine critic Edmund Wilson rightfully points out when comparing Prufrock and The Waste Land (especially the first and fourth parts), a youthful renunciation that never again left the poet. We are, however, not interested in the psychoanalysis of the Eliot’s character, but in the social and historical range of his sentimental development. And essential from this point of view is that the nostalgic love dominant in Prufrock and occasionally surfacing in later works [12] has transformed little by little into a horror of sex and of the vital functions, a deep phobia of life, turning into what one could perhaps best describe as ‘complete biological defeatism’. The Waste Land is built around a skeleton which derives from comparative religion [13] – the animist idea that the seasonal god of life is eternally resurrected. The first verse gives the tone of the poem: "April is the cruellest month", the cruelest because it conceives, gives birth to, and therewith puts an end to the happy illusion of the absence of death in winter. The poem’s center is in the third part, at the middle of which we find the synthetic figure of Tirésias, the man who was woman, who knew utramque venerem, [14] and has thus “fore-suffered” the horror of and pity for the typist, who, after a summary meal, sleeps with her young man on a divan which doubles as a night-time bed [15] , and who is thus, like all other humans, forced to suffer life and its essential expression, the sex act. The poet, decadent and defeatist at heart, confronts the horror and vulgarity of triumphant Humidity with dryness and sterility. But the real and concrete dryness and sterility are, unfortunately, nothing but that same Humidity reduced to a negligible and impotent amount.. The king, whose impotence has sterilized the whole kingdom, remains on the Waste Land, this deserted ground, [16] as the "Fisher‑king”, whose unwillingness to resign is to the disgrace of life and all that belongs to it. The foul, half dried-up river, the authentic symbol of the Laforguian attitude, is even more disgusting than the large sea in which Phlébas perishes (in part IV). The rats and the dry bones are the ever returning symbols of this dryness; which, while being very sterile, very dry, continues to sustain itself on the small quantity of water it still holds. The hollow men, the men stuffed with straw, swaying in the wind, exiled in the country of the cactus, dance around the rickly pear – this least humid of plants – at five o'clock in morning, the hour at which human vitality is at its lowest. These figures from pagan culture are not happier than the typist who "smoothes her hair with automatic hand" or the Highbury girl who "raised her knees supine on the floor of a narrow canoe". And the music to which they dance (1) is hardly more distinguished than the ballad which accompanies the springtime return of Sweeney (2) [17] – the eternal male prefigured by Theseus and [lines lost in French version through printing error, see note] [18] there is no choice between this guard of the fig tree and the massive quantities of water which absorb Phlébas. The world is imprisoned by the saps of life, and these slight traces [19] makes this world’s condition even more humiliating and torturing. I. A. Richards recognized this when he praised Eliot for being the only poet who offers us a world without beliefs, without ideals, a world deserted by, or sterile from, values. But what was a tabula rasa for the humanist and positivist Richards, whose scientific mind was free of the prejudices of ‘practical reason’, [20] and to whom therefore this process was a source of delight, Eliot saw as a horrifying and realistic painting of bourgeois civilization, emptied of faith, of hope, and of vitality. Eliot himself tells us not to read The Waste Land as a personal and subjective poem, but like the report of a basic experiment, a social experiment, as it were an elegy on the death of the bourgeoisie. In prose, Eliot does not show himself a political animal, and his recent love for politics must be considered unfortunate. Even in his poetry, directly political allusions are (1) Here we go round the prickly pear Prickly pear prickly pear Here we go round the prickly pear At five o'clock in the morning. (2) O the moon shone bright on Mrs. Porter And on her daughter. They wash their feet in soda water often quite foolish, such as the allusion to the Tartar danger in the first version of “The Hollow Men” (in the Chapbook of 1924), and in the notes to The Waste Land where he stoops to quote the pompous nonsense of the German Dostoïevskien (Herman Hess). But that is hardly surprising: esoteric and obscure as a poet, Eliot is typical of the current state of the bourgeoisie; typical of those who experience this final disease of the bourgeoisie acutely and immediately at a subconscious level, but are unable to speak about it intelligently when they attempt a clear bourgeois rationale. Eliot’s naïve political efforts to fortify the dissolving middle-class are of the same category as the obscurity of his poetry. But the poet has already shown that the middle-class man can only speak ineptitudes: the world to which he has lent his voice is one of the desert cactus only, dry and sterile, but not yet ready to give up the little life which it remains. [21] But Eliot did not want to waste time on deserted Earth, nor was he content to remain a hollow man. As heir to the poets maudits, he wanted to escape from the desert, and, like the Rimbaudian Claudel, he chose religion to be his guiding star. However, and this emphasized the superiority of Eliot’s integrity over Claudel’s, what he sought and found was not a revival of a dead civilization, was not a dressed up positivist system of rusting symbolism, but an escape from a seasonal vicious circle in an unreal dimension. What Eliot required of religion was an existence which would not hold anything of the life here on earth; it had to be a religion of purity, a spirituality free from any vitality, free from psychology; a purely pneumatic, mystical religion in the strictest sense of the term and one that was severely intellectualist besides. Rejecting any symbolism which set out to sanctify life, Eliot found in Fire the symbol of what he was seeking. He opposed the flowers which make the evil forces of life seem charming, the Aridity which only reduces life to a meaningless struggle, with the Fire that terminates any germ carrying life, smothers any lust whether it is strong or weak, the Fire which is devoid of any attachment to the floods of the phenomenal and personal. Arnaud Daniel, [22] “refined” by the flames of the purgatory becomes the symbol of the rise towards this Shantih, [23] of which “peace which passeth understanding” is only a weak translation. Already in The Waste Land (in spite of what Richards said of it), the symbol of Fire is found to be victorious over the symbols of Humidity and Aridity. Between this poem and the purely religious poems to which Eliot’s poetic output was reduced from 1927 onwards, are a group of highly important writings, including the fragments of an unfinished drama (of which The Hollow Men originally appears to have formed a part) and writings in prose, the most interesting of which is the essay on the 17 th century Anglican preacher Lancelot Andrewes. Andrewes is right up Eliot’s street, because it allows him to contrast a purely intellectualist mystic with the carnal and psychological Donne, who confessed himself to be disturbed “by a memory of the pleasures of yesterday ... , by a strand of straw under the knee, by a noise in my ear, a light in my eye” at the time of prayer. Donne a very suitable scapegoat for Eliot’s wish to demonstrate that religion can only be religious when it is founded, not in the psychological plasma of lust, but in pure, pneumatic fire. The historical differences between Donne and Eliot which I discussed earlier surface admirably in the contrast between the active asceticism of Donne, an exuberant personality with a robust vitality to fight and overcome, and the bloodless asceticism of Eliot, whose fire has only cacti to burn. The essay on Andrewes is certainly the most significant of all Eliot’s prose writings; still more interesting is his remarkable Fragment of an Agon ( Criterion , 1927), where the topic of life is taken up again in an even more realistic and vulgar tone than before. In Fragment , Eliot finds a formula expressing the ultimate horror of life with extraordinary force (combining a skilful use of dissonance with a nauseating vulgarity): “birth, and copulation, and death” – And to leave little doubt concerning the morality of Fragment , its epigraph consists of the words of St John of the Cross, on the heart which cannot unite itself with God because it has not yet “divested itself of the love of created beings”. In the religious poems of late, Eliot’s style narrows and becomes increasingly "small and dry”. The grand symphonic movements of Gerontion, The Waste Land, The Hollow Men and Fragment of an Agon do not return. The poet’s bones are increasingly refined in the purgatorial fire; the air becomes increasingly empty and strange. The life he seeks is most certainly divorced from the carnal life and does not resemble its earthly cousin in any way. He cannot find the values that must save sterile and dry middle-class man neither in carnal life, nor in historical reality; the kingdom which he seeks is not of this world. Thus speaks Eliot the poet. Eliot the publicity agent ostentatiously believes in the possibility of integrating life with the value of the spiritualist mystic, to make these two the cause of the ideology to affirm "Classicism in literature, Anglo Catholicism in religion, and Royalism in politics" (cf. foreword of the single volume edition of For Lancelot Andrewes , 1928 ). His poetry, however, reveals this ideology to be nothing, and adds that the nothing of the fire che es gli affina is the better, purer nothing. [24] D. S. MIRSKY. [1] I only speak of French and English bourgeois poetry. In America and in Germany things are slightly different. In America, a popular element (petit-bourgeois) is still very much alive and purely bourgeois poetry is only one school among several. In Germany the decomposition of bourgeois society is so tangible that the social topic couldn't be ignored even by bourgeois poets. [2] The decomposition of the bourgeoisie proceeds by opposition. The tendency to demagnetise language and to turn it into a purely private matter is distinct from and at the same time complementary to the effort of the detaching meaning from language, in order to create a logic free of all verbal associations. Readers of Edith Sitwell are mostly the same as those of Bertand Russell, whose "Principles of Mathematics" is the gospel of the logicians. [3] Translators note – the idea Mirsky implies but does not formulate further is that the topic a poet chooses is what positively or negatively charges his work. ‘Demagnetising’, removing positive or negative charges, used at the end of the previous paragraph, should be understood in this context. [4] European; America still had Walt Whitman. As was the case for the "poetes maudits", his own generation did not understand him, but the reason for this incomprehension was completely different. The spirit that drove Whitman was that of the democratic bourgeoisie of the Northern States, adverse to slavery, “burning the tracks across the continent, and evaluating California”, but the conscience and the culture of this democracy still remained so provincial, so much imprisoned by the old English values, that the absolutely new forms into which Whitman molded his poetry, could not be assimilated by those of which it expressed the sentiment. [5] All the more true since the philosophy of l’atto puro [the Pure Act] by Giovanni Gentile, its content seemingly so well adapted to fascist needs, still couldn't be adopted by Fascism. As anti-intellectual as his philosophy may be, by the mere fact of it being a philosophy, that is to say an intellectual manifestation is incompatible with fascism. [6] translator’s note – i.e., death. [7] translator’s note – Mirsky uses ‘lesion’, further stressing the cut. [8] translator’s note – Mirsky’s terms really come down to ‘Wind, Water, (Earthm) and Fire’, but this terminology is used throughout the text to support his semantic playfulness. [9] I suggest a comparison between The Waste Land and L'Age d'or . Such a comparison would reveal how similar the method of composition employed in these two works really is. Needless to say, surrealist cinema has not learnt any of this from Eliot. The method is inherent to all art based on the subconscious [10] translator’s note – from seicento , Italian for six hundred. It refers in fact to the literary movement of the seventeenth century, which was the counterpart of baroque and was a reaction against classicism. It is characterized by a strong taste for elaborate conceits. [11] translator’s note – as yet unidentified quote. [12] the flowers are the principal symbol of life and continue to charm Eliot even in his last poems. Other symbols which have the same function, and which he handles with extreme delicacy, are the birds (the American blackbird of The Waste Land), the soft and light wind (the zephyr of the classicist), and women’s hair. [13] translators note – a method of studying religion, which compares religions and studies their similarities and differences. This discipline became widely popular as tension between science and Christianity increased people’s dissatisfaction with Christianity and made them more sympathetic towards other systems of belief [14] translator’s note – ‘both sexes’ [15] translator’s note – cf. TWL, lines 227-8: “On the divan are piled (at night by her bed) / Stockings, slippers, camisoles, and stays.” Mirsky interprets “at night by her bed” as indicating that the divan is her bed at night, but the bracketed comment may as well refer to the clothes, which would be piled by her bed at night – although of course the two interpretations are not mutually exclusive. [16] I do not think le terre Mise a nu, (The earth exposed), the title Jean de Menasce uses in his French translation, is a satisfying rendition of the English title. [17] The text which we translated did not refer to the Mrs Porter song here or anywhere else, but I am guessing this is where it was supposed to be – both fragments are based on popular ballads. [18] – cet eternal male prefigure par Thesee et le peu d’eau que garde emmagasine le figuier de Barbarie il n’y a pas de salut. Entre les grandes eaux qui engloutissent Phlebas et le peu d’eau que garde emmagasinee le figuier de Barbarie il n’y a pas a choisir. [19] translator’s note – i.e. the stinking river Mirsky mentioned earlier, and also perhaps the soda water to which Mirsky refers above. [20] Translator’s note - cf. Kant’s Critique of Practical Reason [21] translator’s note – cf. Mirsky’s comments on the Fisher King, above. [22] Already the title (of the 1920 edition), Ara Vos Prec , is an allusion to this speech of the Provencal poet, who appears in the 26th song of Dante’s Purgatory. [23] Buddhist Term, the repetition of which finishes The Waste Land. [24] translator’s note – the fire which refines.`,c=[],l=[],u={edition:`preserved`,sourceFile:`Essays/Mirsky.htm`},d=[`eliot-articles`],f={id:e,slug:t,type:n,title:r,sourceFile:i,encoding:a,html:o,text:s,links:c,images:l,provenance:u,backlinks:d};export{d as backlinks,f as default,a as encoding,o as html,e as id,l as images,c as links,u as provenance,t as slug,i as sourceFile,s as text,r as title,n as type};