var e=`burbank-notes-title-a`,t=`title`,n=`annotation`,r=`Title of “Burbank with a Baedeker: Bleistein with a Cigar”`,i=`Burbank_notes/title_A.htm`,a=`windows-1252`,o=`
<div><center>
<table>
<tr>
<td><a name="Burbank"></a><strong>Title<br/>
</strong>of "Burbank with a Baedeker: Bleistein with
        a Cigar"<p><em>linguistic analysis</em></p>
<p>The syntactic parallelism of the title is striking,
        and in that particularly the presence of a colon. The
        syntactic structures of the title's two constituents are
        exactly the same - NP / PP, of one and four words
        respectively. We can interpret this in a number of ways:
        the structure of the title may suggests some form of
        similarity, equivalence, contrast, balance, or any
        combination of these. From this follows that Burbank may
        be contrasted or compared with Bleistein, and a Baedeker
        may be contrasted or compared with a Cigar. The two
        objects are first a consituent of their respective
        phrases, and there they are used to define the two
        characters introduced in the title. This holds with the
        history of the title of this poem, which was first only
        Bleistein with a Cigar. (q.v.) What the second object
        means is less clear. </p>
<p><em>textual/poetic analysis</em></p>
<p>The name Bleistein is German, and means 'lead-stone'.
        The name Burbank sounds American and can, like Bleistein,
        be torn apart into two: <em>bur </em>and <em>bank</em>. A
        <em>bur </em>is a clinging seed-vessel or flower, and by
        analogy also a person who is hard to shake off; a bank
        is, apart from the place where Eliot worked, "a
        raised shelf of ground, slope, or elevation in sea or
        river bed." These two names imply a contrast - there
        is something recent and temporary in Burbank's name,
        something which implies youth and change, like a young
        seed in new earth, whereas Bleistein's name makes him
        sound hard and lasting, like a vein of lead in an old
        rock. The best known such contrast is perhaps in Blake's
        The Clod and the Pebble, and I suggest we are meant to
        think of a similar complementary contrast here: two views
        on life, one 'innocent/naive' the other
        'experienced/cynical'. </p>
<p>Besides by their names, the two characters are
        identified by two props: Burbank by a Baedeker, Bleistein
        by a cigar. What can we make out of these two items and
        acts in terms of similarity and contrast? A Baedeker is a
        guidebook to popular holiday resorts, which seems to make
        Burbank a tourist. Smoking a cigar suggests an act of
        contemplation, which, if we combine it with Burbank
        reading a Baedeker, might be of the same object or place
        - Venice. A cigar also suggests a kind of luxury or
        wealth, although it is at this time not certain if this
        was believed to be so at that time - people of many
        different classes smoked cigars. A contrast in that
        respect cannot altogether be evoked either, because if
        Burbank can afford being a tourist in Venice in the early
        1900s this generally implied a certain kind of wealth.
        Hence the contrast between independent contemplation, and
        the studying of Venice through a Baedeker seems to be the
        one implied by Eliot. </p>
<p>This fits in with the similarity we noticed earlier
        between the names Burbank and Bleistein, and Blake's Clod
        and Pebble - the contemplator is experienced, thinks. The
        tourist looks to his guidebook for information about what
        he sees before him, of which he knows little to nothing
        himself. Later in the poem we receive a number of
        suggestions that appear to confirm this hypothysis. </p>
<p><em>historical/biographical analysis</em></p>
<p>The poem was first published under the title Bleistein
        with a Cigar, in <em>Arts and Letters</em>, summer 1919.
        The latest recorded reference to the poem as
        "Bleistein" is in July 1919, in a letter to
        Mary Hutchinson and in the context of its publication in <em>Arts
        and Letters</em>. One of the first things this suggests
        is that initially and for a very considerable period of
        time, i.e. from its conception probably late 1918 till
        July 1919, Eliot considered Bleistein the poem's
        principal character. Only by late September 1919, in a
        letter to John Quinn, Eliot refers to the poem as
        "Burbank" and it is since then that the poem
        also changes perminantly to its currently known title.
        This suggests that Eliot's perception of the poem, and
        particularly the weight of the two characters in the
        poem, changed considerably: by September 1919 Eliot
        considered the two characters equivalent, equally
        important, hence also the choice of the colon. Presumably
        he wrote the Bleistein section first, and then wrote the
        Burbank section around it to provide Bleistein with a
        contrasting background. Eventually the added Burbank
        section became as weighty and important as the Bleistein
        section, and a balanced whole turned up. Eliot then
        apparently decided to reflect that balance in the title,
        amongst others with the use of the colon. </p>
<p>\xA0</p>
<div><table>
<tr>
<td><font><strong>sources</strong></font></td>
</tr>
<tr>
<td>\xA0</td>
</tr>
</table>
</div></td>
</tr>
</table>
</center></div>
`,s=`Title of "Burbank with a Baedeker: Bleistein with a Cigar" linguistic analysis The syntactic parallelism of the title is striking, and in that particularly the presence of a colon. The syntactic structures of the title's two constituents are exactly the same - NP / PP, of one and four words respectively. We can interpret this in a number of ways: the structure of the title may suggests some form of similarity, equivalence, contrast, balance, or any combination of these. From this follows that Burbank may be contrasted or compared with Bleistein, and a Baedeker may be contrasted or compared with a Cigar. The two objects are first a consituent of their respective phrases, and there they are used to define the two characters introduced in the title. This holds with the history of the title of this poem, which was first only Bleistein with a Cigar. (q.v.) What the second object means is less clear. textual/poetic analysis The name Bleistein is German, and means 'lead-stone'. The name Burbank sounds American and can, like Bleistein, be torn apart into two: bur and bank . A bur is a clinging seed-vessel or flower, and by analogy also a person who is hard to shake off; a bank is, apart from the place where Eliot worked, "a raised shelf of ground, slope, or elevation in sea or river bed." These two names imply a contrast - there is something recent and temporary in Burbank's name, something which implies youth and change, like a young seed in new earth, whereas Bleistein's name makes him sound hard and lasting, like a vein of lead in an old rock. The best known such contrast is perhaps in Blake's The Clod and the Pebble, and I suggest we are meant to think of a similar complementary contrast here: two views on life, one 'innocent/naive' the other 'experienced/cynical'. Besides by their names, the two characters are identified by two props: Burbank by a Baedeker, Bleistein by a cigar. What can we make out of these two items and acts in terms of similarity and contrast? A Baedeker is a guidebook to popular holiday resorts, which seems to make Burbank a tourist. Smoking a cigar suggests an act of contemplation, which, if we combine it with Burbank reading a Baedeker, might be of the same object or place - Venice. A cigar also suggests a kind of luxury or wealth, although it is at this time not certain if this was believed to be so at that time - people of many different classes smoked cigars. A contrast in that respect cannot altogether be evoked either, because if Burbank can afford being a tourist in Venice in the early 1900s this generally implied a certain kind of wealth. Hence the contrast between independent contemplation, and the studying of Venice through a Baedeker seems to be the one implied by Eliot. This fits in with the similarity we noticed earlier between the names Burbank and Bleistein, and Blake's Clod and Pebble - the contemplator is experienced, thinks. The tourist looks to his guidebook for information about what he sees before him, of which he knows little to nothing himself. Later in the poem we receive a number of suggestions that appear to confirm this hypothysis. historical/biographical analysis The poem was first published under the title Bleistein with a Cigar, in Arts and Letters , summer 1919. The latest recorded reference to the poem as "Bleistein" is in July 1919, in a letter to Mary Hutchinson and in the context of its publication in Arts and Letters . One of the first things this suggests is that initially and for a very considerable period of time, i.e. from its conception probably late 1918 till July 1919, Eliot considered Bleistein the poem's principal character. Only by late September 1919, in a letter to John Quinn, Eliot refers to the poem as "Burbank" and it is since then that the poem also changes perminantly to its currently known title. This suggests that Eliot's perception of the poem, and particularly the weight of the two characters in the poem, changed considerably: by September 1919 Eliot considered the two characters equivalent, equally important, hence also the choice of the colon. Presumably he wrote the Bleistein section first, and then wrote the Burbank section around it to provide Bleistein with a contrasting background. Eventually the added Burbank section became as weighty and important as the Bleistein section, and a balanced whole turned up. Eliot then apparently decided to reflect that balance in the title, amongst others with the use of the colon. sources`,c=[],l=[],u={edition:`preserved`,sourceFile:`Burbank_notes/title_A.htm`},d=`burbank-notes-title-n.waste-notes-agameof-n.waste-notes-belladonna-n.waste-notes-benefice-n.waste-notes-blazing-t.waste-notes-bradford-n.waste-notes-brings-n.waste-notes-burning-n.waste-notes-butatmy-n.waste-notes-butatmyb-n.waste-notes-bythewaters-n.waste-notes-cannon-n.waste-notes-carbuncu-w.waste-notes-chair-n.waste-notes-cicada-w.waste-notes-cif-n.waste-notes-cocorico-n.waste-notes-coirolan-n.waste-notes-datta-n.waste-notes-deadsoun-n.waste-notes-deadtree-n.waste-notes-deathby-n.waste-notes-demobbed-w.waste-notes-demotic-w.waste-notes-elizabeth-n.waste-notes-emptychapel-n.waste-notes-etoces-n.waste-notes-fabbro-n.waste-notes-fireserm-n.waste-notes-fishing-n.waste-notes-flung-n.waste-notes-fourmill-t.waste-notes-gammon-n.waste-notes-goodnigh-n.waste-notes-greenwic-w.waste-notes-hanged-n.waste-notes-hewhowas-n.waste-notes-highbury-n.waste-notes-hurryup-n.waste-notes-ihadnot-n.waste-notes-jugjug-n.waste-notes-keepthedog-n.waste-notes-ladyofro-n.waste-notes-latourab-n.waste-notes-leman-w.waste-notes-londonbridge-n.waste-notes-magnus-n.waste-notes-margate-n.waste-notes-moorgate-w.waste-notes-mountains-n.waste-notes-mylae-n.waste-notes-olordthou-n.waste-notes-oneeye-n.waste-notes-ontheking-n.waste-notes-packof-n.waste-notes-pearls-n.waste-notes-philomel-n.waste-notes-phoenici-n.waste-notes-poisascose-n.waste-notes-pound-n.waste-notes-quandofi-n.waste-notes-quivi-t.waste-notes-ratsalle-n.waste-notes-riversweats-n.waste-notes-rudely-n.waste-notes-saintmar-n.waste-notes-shakespehe-n.waste-notes-shalliat-n.waste-notes-shantih-n.waste-notes-sighs-n.waste-notes-smyrna-n.waste-notes-sonofman-n.waste-notes-sosostri-n.waste-notes-soundof-n.waste-notes-summer-n.waste-notes-swallow-n.waste-notes-sweetthames-n.waste-notes-sybil-n.waste-notes-sybil-t.waste-notes-sylvan-n.waste-notes-tempest1-2-487-n.waste-notes-tereu-n.waste-notes-thatcorp-n.waste-notes-thekey-n.waste-notes-thereisshad-n.waste-notes-thesefragments-n.waste-notes-theywash-n.waste-notes-thismusic-n.waste-notes-threestaves-n.waste-notes-tiresias-n.waste-notes-title-n.waste-notes-tobring-w.waste-notes-tocarthage-n.waste-notes-unreal-n.waste-notes-wagner-3.waste-notes-wagner3-24-t.waste-notes-wagner5-8-t.waste-notes-weshallplay-n.waste-notes-whatisthatsound-n.waste-notes-whatthethunder-n.waste-notes-wheel-n.waste-notes-whenlovely-n.waste-notes-whenthehermit-n.waste-notes-whoisthethird-n.waste-notes-whythen-n.waste-notes-windunde-n.waste-notes-youhypocrite-n`.split(`.`),f={id:e,slug:t,type:n,title:r,sourceFile:i,encoding:a,html:o,text:s,links:c,images:l,provenance:u,backlinks:d};export{d as backlinks,f as default,a as encoding,o as html,e as id,l as images,c as links,u as provenance,t as slug,i as sourceFile,s as text,r as title,n as type};