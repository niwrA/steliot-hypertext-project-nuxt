var e=`essays-swtradition`,t=`swtradition`,n=`source-page`,r=`Eliot, T. S. 1920. The Sacred Wood: Tradition and the Individual Talent.`,i=`Essays/swtradition.htm`,a=`windows-1252`,o=`
<p><font><b>Tradition and the Individual
Talent</b></font></p>
<table>
<tr>
<td>"I was dealing then with the artist, and the
        sense of tradition which, it seemed to me, the artist
        should have; but it was generally a problem of order; and
        the function of criticism seems to be essentially a
        problem of order too."<blockquote>
<p>T.S. Eliot, "The Function of
            Criticism" (1923)</p>
</blockquote>
</td>
</tr>
</table>
<div><center>
<table>
<tr>
<td rowspan="2"><p><font>I</font>
</p>
<p>I<font>N</font> English writing we seldom
        speak of tradition, though we occasionally apply its name
        in deploring its absence. We cannot refer to "the
        tradition" or to "a tradition"; at most,
        we employ the adjective in saying that the poetry of
        So-and-so is "traditional" or even "too
        traditional." Seldom, perhaps, does the word appear
        except in a phrase of censure. If otherwise, it is
        vaguely approbative, with the implication, as to the work
        approved, of some pleasing archæological reconstruction.
        You can hardly make the word agreeable to English ears
        without this comfortable reference to the reassuring
        science of archæology.</p>
<p>\xA0\xA0Certainly the word is not likely to appear
        in our appreciations of living or dead writers. Every
        nation, every race, has not only its own creative, but
        its own critical turn of mind; and is even more oblivious
        of the shortcomings and limitations of its critical
        habits than of those of its creative genius. We know, or
        think we know, from the enormous mass of critical writing
        that has appeared in the French language the critical
        method or habit of the French; we only conclude (we are
        such unconscious people) that the French are "more
        critical" than we, and sometimes even plume
        ourselves a little with the fact, as if the French were
        the less spontaneous. Perhaps they are; but we might
        remind ourselves that criticism is as inevitable as
        breathing, and that we should be none the worse for
        articulating what passes in our minds when we read a book
        and feel an emotion about it, for criticizing our own
        minds in their work of criticism. One of the facts that
        might come to light in this process is our tendency to
        insist, when we praise a poet, upon those aspects of his
        work in which he least resembles anyone else. In these
        aspects or parts of his work we pretend to find what is
        individual, what is the peculiar essence of the man. We
        dwell with satisfaction upon the poet's difference from
        his predecessors, especially his immediate predecessors;
        we endeavour to find something that can be isolated in
        order to be enjoyed. Whereas if we approach a poet
        without this prejudice we shall often find that not only
        the best, but the most individual parts of his work may
        be those in which the dead poets, his ancestors, assert
        their immortality most vigorously. And I do not mean the
        impressionable period of adolescence, but the period of
        full maturity.</p>
<p>\xA0\xA0Yet if the only form of tradition, of
        handing down, consisted in following the ways of the
        immediate generation before us in a blind or timid
        adherence to its successes, "tradition" should
        positively be discouraged. We have seen many such simple
        currents soon lost in the sand; and novelty is better
        than repetition. Tradition is a matter of much wider
        significance. It cannot be inherited, and if you want it
        you must obtain it by great labour. It involves, in the
        first place, the historical sense, which we may call
        nearly indispensable to anyone who would continue to be a
        poet beyond his twenty-fifth year; and the historical
        sense involves a perception, not only of the pastness of
        the past, but of its presence; the historical sense
        compels a man to write not merely with his own generation
        in his bones, but with a feeling that the whole of the
        literature of Europe from Homer and within it the whole
        of the literature of his own country has a simultaneous
        existence and composes a simultaneous order. This
        historical sense, which is a sense of the timeless as
        well as of the temporal and of the timeless and of the
        temporal together, is what makes a writer traditional.
        And it is at the same time what makes a writer most
        acutely conscious of his place in time, of his
        contemporaneity.</p>
<p>\xA0\xA0No poet, no artist of any art, has his
        complete meaning alone. His significance, his
        appreciation is the appreciation of his relation to the
        dead poets and artists. You cannot value him alone; you
        must set him, for contrast and comparison, among the
        dead. I mean this as a principle of æsthetic, not merely
        historical, criticism. The necessity that he shall
        conform, that he shall cohere, is not one-sided; what
        happens when a new work of art is created is something
        that happens simultaneously to all the works of art which
        preceded it. The existing monuments form an ideal order
        among themselves, which is modified by the introduction
        of the new (the really new) work of art among them. The
        existing order is complete before the new work arrives;
        for order to persist after the supervention of novelty,
        the <i>whole</i> existing order must be, if ever so
        slightly, altered; and so the relations, proportions,
        values of each work of art toward the whole are
        readjusted; and this is conformity between the old and
        the new. Whoever has approved this idea of order, of the
        form of European, of English literature, will not find it
        preposterous that the past should be altered by the
        present as much as the present is directed by the past.
        And the poet who is aware of this will be aware of great
        difficulties and responsibilities.</p>
<p>\xA0\xA0In a peculiar sense he will be aware also
        that he must inevitably be judged by the standards of the
        past. I say judged, not amputated, by them; not judged to
        be as good as, or worse or better than, the dead; and
        certainly not judged by the canons of dead critics. It is
        a judgment, a comparison, in which two things are
        measured by each other. To conform merely would be for
        the new work not really to conform at all; it would not
        be new, and would therefore not be a work of art. And we
        do not quite say that the new is more valuable because it
        fits in; but its fitting in is a test of its value—a
        test, it is true, which can only be slowly and cautiously
        applied, for we are none of us infallible judges of
        conformity. We say: it appears to conform, and is perhaps
        individual, or it appears individual, and may conform;
        but we are hardly likely to find that it is one and not
        the other.</p>
<p>\xA0\xA0To proceed to a more intelligible
        exposition of the relation of the poet to the past: he
        can neither take the past as a lump, an indiscriminate
        bolus, nor can he form himself wholly on one or two
        private admirations, nor can he form himself wholly upon
        one preferred period. The first course is inadmissible,
        the second is an important experience of youth, and the
        third is a pleasant and highly desirable supplement. The
        poet must be very conscious of the main current, which
        does not at all flow invariably through the most
        distinguished reputations. He must be quite aware of the
        obvious fact that art never improves, but that the
        material of art is never quite the same. He must be aware
        that the mind of Europe—the mind of his own
        country—a mind which he learns in time to be much
        more important than his own private mind—is a mind
        which changes, and that this change is a development
        which abandons nothing <i>en route,</i> which does not
        superannuate either Shakespeare, or Homer, or the rock
        drawing of the Magdalenian draughtsmen. That this
        development, refinement perhaps, complication certainly,
        is not, from the point of view of the artist, any
        improvement. Perhaps not even an improvement from the
        point of view of the psychologist or not to the extent
        which we imagine; perhaps only in the end based upon a
        complication in economics and machinery. But the
        difference between the present and the past is that the
        conscious present is an awareness of the past in a way
        and to an extent which the past's awareness of itself
        cannot show.</p>
<p>\xA0\xA0Some one said: "The dead writers are
        remote from us because we <i>know</i> so much more than
        they did." Precisely, and they are that which we
        know.</p>
<p>\xA0\xA0I am alive to a usual objection to what is
        clearly part of my programme for the <i>métier</i> of
        poetry. The objection is that the doctrine requires a
        ridiculous amount of erudition (pedantry), a claim which
        can be rejected by appeal to the lives of poets in any
        pantheon. It will even be affirmed that much learning
        deadens or perverts poetic sensibility. While, however,
        we persist in believing that a poet ought to know as much
        as will not encroach upon his necessary receptivity and
        necessary laziness, it is not desirable to confine
        knowledge to whatever can be put into a useful shape for
        examinations, drawing-rooms, or the still more
        pretentious modes of publicity. Some can absorb
        knowledge, the more tardy must sweat for it. Shakespeare
        acquired more essential history from Plutarch than most
        men could from the whole British Museum. What is to be
        insisted upon is that the poet must develop or procure
        the consciousness of the past and that he should continue
        to develop this consciousness throughout his career.</p>
<p>\xA0\xA0What happens is a continual surrender of
        himself as he is at the moment to something which is more
        valuable. The progress of an artist is a continual
        self-sacrifice, a continual extinction of personality.</p>
<p>\xA0\xA0There remains to define this process of
        depersonalization and its relation to the sense of
        tradition. It is in this depersonalization that art may
        be said to approach the condition of science. I shall,
        therefore, invite you to consider, as a suggestive
        analogy, the action which takes place when a bit of
        finely filiated platinum is introduced into a chamber
        containing oxygen and sulphur dioxide.</p>
<p><br/>
<font>II</font> </p>
<p>\xA0\xA0Honest criticism and sensitive
        appreciation is directed not upon the poet but upon the
        poetry. If we attend to the confused cries of the
        newspaper critics and the susurrus of popular repetition
        that follows, we shall hear the names of poets in great
        numbers; if we seek not Blue-book knowledge but the
        enjoyment of poetry, and ask for a poem, we shall seldom
        find it. In the last article I tried to point out the
        importance of the relation of the poem to other poems by
        other authors, and suggested the conception of poetry as
        a living whole of all the poetry that has ever been
        written. The other aspect of this Impersonal theory of
        poetry is the relation of the poem to its author. And I
        hinted, by an analogy, that the mind of the mature poet
        differs from that of the immature one not precisely in
        any valuation of "personality," not being
        necessarily more interesting, or having "more to
        say," but rather by being a more finely perfected
        medium in which special, or very varied, feelings are at
        liberty to enter into new combinations.</p>
<p>\xA0\xA0The analogy was that of the catalyst. When
        the two gases previously mentioned are mixed in the
        presence of a filament of platinum, they form sulphurous
        acid. This combination takes place only if the platinum
        is present; nevertheless the newly formed acid contains
        no trace of platinum, and the platinum itself is
        apparently unaffected; has remained inert, neutral, and
        unchanged. The mind of the poet is the shred of platinum.
        It may partly or exclusively operate upon the experience
        of the man himself; but, the more perfect the artist, the
        more completely separate in him will be the man who
        suffers and the mind which creates; the more perfectly
        will the mind digest and transmute the passions which are
        its material.</p>
<p>\xA0\xA0The experience, you will notice, the
        elements which enter the presence of the transforming
        catalyst, are of two kinds: emotions and feelings. The
        effect of a work of art upon the person who enjoys it is
        an experience different in kind from any experience not
        of art. It may be formed out of one emotion, or may be a
        combination of several; and various feelings, inhering
        for the writer in particular words or phrases or images,
        may be added to compose the final result. Or great poetry
        may be made without the direct use of any emotion
        whatever: composed out of feelings solely. Canto XV of
        the <i>Inferno</i> (Brunetto Latini) is a working up of
        the emotion evident in the situation; but the effect,
        though single as that of any work of art, is obtained by
        considerable complexity of detail. The last quatrain
        gives an image, a feeling attaching to an image, which
        "came," which did not develop simply out of
        what precedes, but which was probably in suspension in
        the poet's mind until the proper combination arrived for
        it to add itself to. The poet's mind is in fact a
        receptacle for seizing and storing up numberless
        feelings, phrases, images, which remain there until all
        the particles which can unite to form a new compound are
        present together.</p>
<p>\xA0\xA0If you compare several representative
        passages of the greatest poetry you see how great is the
        variety of types of combination, and also how completely
        any semi-ethical criterion of "sublimity"
        misses the mark. For it is not the "greatness,"
        the intensity, of the emotions, the components, but the
        intensity of the artistic process, the pressure, so to
        speak, under which the fusion takes place, that counts.
        The episode of Paolo and Francesca employs a definite
        emotion, but the intensity of the poetry is something
        quite different from whatever intensity in the supposed
        experience it may give the impression of. It is no more
        intense, furthermore, than Canto XXVI, the voyage of
        Ulysses, which has not the direct dependence upon an
        emotion. Great variety is possible in the process of
        transmution of emotion: the murder of Agamemnon, or the
        agony of Othello, gives an artistic effect apparently
        closer to a possible original than the scenes from Dante.
        In the <i>Agamemnon,</i> the artistic emotion
        approximates to the emotion of an actual spectator; in <i>Othello</i>
        to the emotion of the protagonist himself. But the
        difference between art and the event is always absolute;
        the combination which is the murder of Agamemnon is
        probably as complex as that which is the voyage of
        Ulysses. In either case there has been a fusion of
        elements. The ode of Keats contains a number of feelings
        which have nothing particular to do with the nightingale,
        but which the nightingale, partly, perhaps, because of
        its attractive name, and partly because of its
        reputation, served to bring together.</p>
<p>\xA0\xA0The point of view which I am struggling to
        attack is perhaps related to the metaphysical theory of
        the substantial unity of the soul: for my meaning is,
        that the poet has, not a "personality" to
        express, but a particular medium, which is only a medium
        and not a personality, in which impressions and
        experiences combine in peculiar and unexpected ways.
        Impressions and experiences which are important for the
        man may take no place in the poetry, and those which
        become important in the poetry may play quite a
        negligible part in the man, the personality.</p>
<p>\xA0\xA0I will quote a passage which is unfamiliar
        enough to be regarded with fresh attention in the
        light—or darkness—of these observations: </p>
<blockquote>
<p>And now methinks I could e'en chide myself <br/>
            For doating on her beauty, though her death <br/>
            Shall be revenged after no common action. <br/>
            Does the silkworm expend her yellow labours <br/>
            For thee? For thee does she undo herself? <br/>
            Are lordships sold to maintain ladyships <br/>
            For the poor benefit of a bewildering minute? <br/>
            Why does yon fellow falsify highways, <br/>
            And put his life between the judge's lips, <br/>
            To refine such a thing—keeps horse and men <br/>
            To beat their valours for her?...</p>
</blockquote>
<p>In this passage (as is evident if it is taken in its
        context) there is a combination of positive and negative
        emotions: an intensely strong attraction toward beauty
        and an equally intense fascination by the ugliness which
        is contrasted with it and which destroys it. This balance
        of contrasted emotion is in the dramatic situation to
        which the speech is pertinent, but that situation alone
        is inadequate to it. This is, so to speak, the structural
        emotion, provided by the drama. But the whole effect, the
        dominant tone, is due to the fact that a number of
        floating feelings, having an affinity to this emotion by
        no means superficially evident, have combined with it to
        give us a new art emotion.</p>
<p>\xA0\xA0It is not in his personal emotions, the
        emotions provoked by particular events in his life, that
        the poet is in any way remarkable or interesting. His
        particular emotions may be simple, or crude, or flat. The
        emotion in his poetry will be a very complex thing, but
        not with the complexity of the emotions of people who
        have very complex or unusual emotions in life. One error,
        in fact, of eccentricity in poetry is to seek for new
        human emotions to express; and in this search for novelty
        in the wrong place it discovers the perverse. The
        business of the poet is not to find new emotions, but to
        use the ordinary ones and, in working them up into
        poetry, to express feelings which are not in actual
        emotions at all. And emotions which he has never
        experienced will serve his turn as well as those familiar
        to him. Consequently, we must believe that "emotion
        recollected in tranquillity" is an inexact formula.
        For it is neither emotion, nor recollection, nor, without
        distortion of meaning, tranquillity. It is a
        concentration, and a new thing resulting from the
        concentration, of a very great number of experiences
        which to the practical and active person would not seem
        to be experiences at all; it is a concentration which
        does not happen consciously or of deliberation. These
        experiences are not "recollected," and they
        finally unite in an atmosphere which is
        "tranquil" only in that it is a passive
        attending upon the event. Of course this is not quite the
        whole story. There is a great deal, in the writing of
        poetry, which must be conscious and deliberate. In fact,
        the bad poet is usually unconscious where he ought to be
        conscious, and conscious where he ought to be
        unconscious. Both errors tend to make him
        "personal." Poetry is not a turning loose of
        emotion, but an escape from emotion; it is not the
        expression of personality, but an escape from
        personality. But, of course, only those who have
        personality and emotions know what it means to want to
        escape from these things.</p>
<p><br/>
<font>III</font> </p>
<p><img src="greek1.gif"/> </p>
<p>\xA0\xA0This essay proposes to halt at the
        frontier of metaphysics or mysticism, and confine itself
        to such practical conclusions as can be applied by the
        responsible person interested in poetry. To divert
        interest from the poet to the poetry is a laudable aim:
        for it would conduce to a juster estimation of actual
        poetry, good and bad. There are many people who
        appreciate the expression of sincere emotion in verse,
        and there is a smaller number of people who can
        appreciate technical excellence. But very few know when
        there is expression of <i>significant</i> emotion,
        emotion which has its life in the poem and not in the
        history of the poet. The emotion of art is impersonal.
        And the poet cannot reach this impersonality without
        surrendering himself wholly to the work to be done. And
        he is not likely to know what is to be done unless he
        lives in what is not merely the present, but the present
        moment of the past, unless he is conscious, not of what
        is dead, but of what is already living. </p>
</td>
</tr>
</table>
</center></div>
<p>\xA0</p>
`,s=`Tradition and the Individual Talent "I was dealing then with the artist, and the sense of tradition which, it seemed to me, the artist should have; but it was generally a problem of order; and the function of criticism seems to be essentially a problem of order too." T.S. Eliot, "The Function of Criticism" (1923) I I N English writing we seldom speak of tradition, though we occasionally apply its name in deploring its absence. We cannot refer to "the tradition" or to "a tradition"; at most, we employ the adjective in saying that the poetry of So-and-so is "traditional" or even "too traditional." Seldom, perhaps, does the word appear except in a phrase of censure. If otherwise, it is vaguely approbative, with the implication, as to the work approved, of some pleasing archæological reconstruction. You can hardly make the word agreeable to English ears without this comfortable reference to the reassuring science of archæology. Certainly the word is not likely to appear in our appreciations of living or dead writers. Every nation, every race, has not only its own creative, but its own critical turn of mind; and is even more oblivious of the shortcomings and limitations of its critical habits than of those of its creative genius. We know, or think we know, from the enormous mass of critical writing that has appeared in the French language the critical method or habit of the French; we only conclude (we are such unconscious people) that the French are "more critical" than we, and sometimes even plume ourselves a little with the fact, as if the French were the less spontaneous. Perhaps they are; but we might remind ourselves that criticism is as inevitable as breathing, and that we should be none the worse for articulating what passes in our minds when we read a book and feel an emotion about it, for criticizing our own minds in their work of criticism. One of the facts that might come to light in this process is our tendency to insist, when we praise a poet, upon those aspects of his work in which he least resembles anyone else. In these aspects or parts of his work we pretend to find what is individual, what is the peculiar essence of the man. We dwell with satisfaction upon the poet's difference from his predecessors, especially his immediate predecessors; we endeavour to find something that can be isolated in order to be enjoyed. Whereas if we approach a poet without this prejudice we shall often find that not only the best, but the most individual parts of his work may be those in which the dead poets, his ancestors, assert their immortality most vigorously. And I do not mean the impressionable period of adolescence, but the period of full maturity. Yet if the only form of tradition, of handing down, consisted in following the ways of the immediate generation before us in a blind or timid adherence to its successes, "tradition" should positively be discouraged. We have seen many such simple currents soon lost in the sand; and novelty is better than repetition. Tradition is a matter of much wider significance. It cannot be inherited, and if you want it you must obtain it by great labour. It involves, in the first place, the historical sense, which we may call nearly indispensable to anyone who would continue to be a poet beyond his twenty-fifth year; and the historical sense involves a perception, not only of the pastness of the past, but of its presence; the historical sense compels a man to write not merely with his own generation in his bones, but with a feeling that the whole of the literature of Europe from Homer and within it the whole of the literature of his own country has a simultaneous existence and composes a simultaneous order. This historical sense, which is a sense of the timeless as well as of the temporal and of the timeless and of the temporal together, is what makes a writer traditional. And it is at the same time what makes a writer most acutely conscious of his place in time, of his contemporaneity. No poet, no artist of any art, has his complete meaning alone. His significance, his appreciation is the appreciation of his relation to the dead poets and artists. You cannot value him alone; you must set him, for contrast and comparison, among the dead. I mean this as a principle of æsthetic, not merely historical, criticism. The necessity that he shall conform, that he shall cohere, is not one-sided; what happens when a new work of art is created is something that happens simultaneously to all the works of art which preceded it. The existing monuments form an ideal order among themselves, which is modified by the introduction of the new (the really new) work of art among them. The existing order is complete before the new work arrives; for order to persist after the supervention of novelty, the whole existing order must be, if ever so slightly, altered; and so the relations, proportions, values of each work of art toward the whole are readjusted; and this is conformity between the old and the new. Whoever has approved this idea of order, of the form of European, of English literature, will not find it preposterous that the past should be altered by the present as much as the present is directed by the past. And the poet who is aware of this will be aware of great difficulties and responsibilities. In a peculiar sense he will be aware also that he must inevitably be judged by the standards of the past. I say judged, not amputated, by them; not judged to be as good as, or worse or better than, the dead; and certainly not judged by the canons of dead critics. It is a judgment, a comparison, in which two things are measured by each other. To conform merely would be for the new work not really to conform at all; it would not be new, and would therefore not be a work of art. And we do not quite say that the new is more valuable because it fits in; but its fitting in is a test of its value—a test, it is true, which can only be slowly and cautiously applied, for we are none of us infallible judges of conformity. We say: it appears to conform, and is perhaps individual, or it appears individual, and may conform; but we are hardly likely to find that it is one and not the other. To proceed to a more intelligible exposition of the relation of the poet to the past: he can neither take the past as a lump, an indiscriminate bolus, nor can he form himself wholly on one or two private admirations, nor can he form himself wholly upon one preferred period. The first course is inadmissible, the second is an important experience of youth, and the third is a pleasant and highly desirable supplement. The poet must be very conscious of the main current, which does not at all flow invariably through the most distinguished reputations. He must be quite aware of the obvious fact that art never improves, but that the material of art is never quite the same. He must be aware that the mind of Europe—the mind of his own country—a mind which he learns in time to be much more important than his own private mind—is a mind which changes, and that this change is a development which abandons nothing en route, which does not superannuate either Shakespeare, or Homer, or the rock drawing of the Magdalenian draughtsmen. That this development, refinement perhaps, complication certainly, is not, from the point of view of the artist, any improvement. Perhaps not even an improvement from the point of view of the psychologist or not to the extent which we imagine; perhaps only in the end based upon a complication in economics and machinery. But the difference between the present and the past is that the conscious present is an awareness of the past in a way and to an extent which the past's awareness of itself cannot show. Some one said: "The dead writers are remote from us because we know so much more than they did." Precisely, and they are that which we know. I am alive to a usual objection to what is clearly part of my programme for the métier of poetry. The objection is that the doctrine requires a ridiculous amount of erudition (pedantry), a claim which can be rejected by appeal to the lives of poets in any pantheon. It will even be affirmed that much learning deadens or perverts poetic sensibility. While, however, we persist in believing that a poet ought to know as much as will not encroach upon his necessary receptivity and necessary laziness, it is not desirable to confine knowledge to whatever can be put into a useful shape for examinations, drawing-rooms, or the still more pretentious modes of publicity. Some can absorb knowledge, the more tardy must sweat for it. Shakespeare acquired more essential history from Plutarch than most men could from the whole British Museum. What is to be insisted upon is that the poet must develop or procure the consciousness of the past and that he should continue to develop this consciousness throughout his career. What happens is a continual surrender of himself as he is at the moment to something which is more valuable. The progress of an artist is a continual self-sacrifice, a continual extinction of personality. There remains to define this process of depersonalization and its relation to the sense of tradition. It is in this depersonalization that art may be said to approach the condition of science. I shall, therefore, invite you to consider, as a suggestive analogy, the action which takes place when a bit of finely filiated platinum is introduced into a chamber containing oxygen and sulphur dioxide. II Honest criticism and sensitive appreciation is directed not upon the poet but upon the poetry. If we attend to the confused cries of the newspaper critics and the susurrus of popular repetition that follows, we shall hear the names of poets in great numbers; if we seek not Blue-book knowledge but the enjoyment of poetry, and ask for a poem, we shall seldom find it. In the last article I tried to point out the importance of the relation of the poem to other poems by other authors, and suggested the conception of poetry as a living whole of all the poetry that has ever been written. The other aspect of this Impersonal theory of poetry is the relation of the poem to its author. And I hinted, by an analogy, that the mind of the mature poet differs from that of the immature one not precisely in any valuation of "personality," not being necessarily more interesting, or having "more to say," but rather by being a more finely perfected medium in which special, or very varied, feelings are at liberty to enter into new combinations. The analogy was that of the catalyst. When the two gases previously mentioned are mixed in the presence of a filament of platinum, they form sulphurous acid. This combination takes place only if the platinum is present; nevertheless the newly formed acid contains no trace of platinum, and the platinum itself is apparently unaffected; has remained inert, neutral, and unchanged. The mind of the poet is the shred of platinum. It may partly or exclusively operate upon the experience of the man himself; but, the more perfect the artist, the more completely separate in him will be the man who suffers and the mind which creates; the more perfectly will the mind digest and transmute the passions which are its material. The experience, you will notice, the elements which enter the presence of the transforming catalyst, are of two kinds: emotions and feelings. The effect of a work of art upon the person who enjoys it is an experience different in kind from any experience not of art. It may be formed out of one emotion, or may be a combination of several; and various feelings, inhering for the writer in particular words or phrases or images, may be added to compose the final result. Or great poetry may be made without the direct use of any emotion whatever: composed out of feelings solely. Canto XV of the Inferno (Brunetto Latini) is a working up of the emotion evident in the situation; but the effect, though single as that of any work of art, is obtained by considerable complexity of detail. The last quatrain gives an image, a feeling attaching to an image, which "came," which did not develop simply out of what precedes, but which was probably in suspension in the poet's mind until the proper combination arrived for it to add itself to. The poet's mind is in fact a receptacle for seizing and storing up numberless feelings, phrases, images, which remain there until all the particles which can unite to form a new compound are present together. If you compare several representative passages of the greatest poetry you see how great is the variety of types of combination, and also how completely any semi-ethical criterion of "sublimity" misses the mark. For it is not the "greatness," the intensity, of the emotions, the components, but the intensity of the artistic process, the pressure, so to speak, under which the fusion takes place, that counts. The episode of Paolo and Francesca employs a definite emotion, but the intensity of the poetry is something quite different from whatever intensity in the supposed experience it may give the impression of. It is no more intense, furthermore, than Canto XXVI, the voyage of Ulysses, which has not the direct dependence upon an emotion. Great variety is possible in the process of transmution of emotion: the murder of Agamemnon, or the agony of Othello, gives an artistic effect apparently closer to a possible original than the scenes from Dante. In the Agamemnon, the artistic emotion approximates to the emotion of an actual spectator; in Othello to the emotion of the protagonist himself. But the difference between art and the event is always absolute; the combination which is the murder of Agamemnon is probably as complex as that which is the voyage of Ulysses. In either case there has been a fusion of elements. The ode of Keats contains a number of feelings which have nothing particular to do with the nightingale, but which the nightingale, partly, perhaps, because of its attractive name, and partly because of its reputation, served to bring together. The point of view which I am struggling to attack is perhaps related to the metaphysical theory of the substantial unity of the soul: for my meaning is, that the poet has, not a "personality" to express, but a particular medium, which is only a medium and not a personality, in which impressions and experiences combine in peculiar and unexpected ways. Impressions and experiences which are important for the man may take no place in the poetry, and those which become important in the poetry may play quite a negligible part in the man, the personality. I will quote a passage which is unfamiliar enough to be regarded with fresh attention in the light—or darkness—of these observations: And now methinks I could e'en chide myself For doating on her beauty, though her death Shall be revenged after no common action. Does the silkworm expend her yellow labours For thee? For thee does she undo herself? Are lordships sold to maintain ladyships For the poor benefit of a bewildering minute? Why does yon fellow falsify highways, And put his life between the judge's lips, To refine such a thing—keeps horse and men To beat their valours for her?... In this passage (as is evident if it is taken in its context) there is a combination of positive and negative emotions: an intensely strong attraction toward beauty and an equally intense fascination by the ugliness which is contrasted with it and which destroys it. This balance of contrasted emotion is in the dramatic situation to which the speech is pertinent, but that situation alone is inadequate to it. This is, so to speak, the structural emotion, provided by the drama. But the whole effect, the dominant tone, is due to the fact that a number of floating feelings, having an affinity to this emotion by no means superficially evident, have combined with it to give us a new art emotion. It is not in his personal emotions, the emotions provoked by particular events in his life, that the poet is in any way remarkable or interesting. His particular emotions may be simple, or crude, or flat. The emotion in his poetry will be a very complex thing, but not with the complexity of the emotions of people who have very complex or unusual emotions in life. One error, in fact, of eccentricity in poetry is to seek for new human emotions to express; and in this search for novelty in the wrong place it discovers the perverse. The business of the poet is not to find new emotions, but to use the ordinary ones and, in working them up into poetry, to express feelings which are not in actual emotions at all. And emotions which he has never experienced will serve his turn as well as those familiar to him. Consequently, we must believe that "emotion recollected in tranquillity" is an inexact formula. For it is neither emotion, nor recollection, nor, without distortion of meaning, tranquillity. It is a concentration, and a new thing resulting from the concentration, of a very great number of experiences which to the practical and active person would not seem to be experiences at all; it is a concentration which does not happen consciously or of deliberation. These experiences are not "recollected," and they finally unite in an atmosphere which is "tranquil" only in that it is a passive attending upon the event. Of course this is not quite the whole story. There is a great deal, in the writing of poetry, which must be conscious and deliberate. In fact, the bad poet is usually unconscious where he ought to be conscious, and conscious where he ought to be unconscious. Both errors tend to make him "personal." Poetry is not a turning loose of emotion, but an escape from emotion; it is not the expression of personality, but an escape from personality. But, of course, only those who have personality and emotions know what it means to want to escape from these things. III This essay proposes to halt at the frontier of metaphysics or mysticism, and confine itself to such practical conclusions as can be applied by the responsible person interested in poetry. To divert interest from the poet to the poetry is a laudable aim: for it would conduce to a juster estimation of actual poetry, good and bad. There are many people who appreciate the expression of sincere emotion in verse, and there is a smaller number of people who can appreciate technical excellence. But very few know when there is expression of significant emotion, emotion which has its life in the poem and not in the history of the poet. The emotion of art is impersonal. And the poet cannot reach this impersonality without surrendering himself wholly to the work to be done. And he is not likely to know what is to be done unless he lives in what is not merely the present, but the present moment of the past, unless he is conscious, not of what is dead, but of what is already living.`,c=[],l=[{kind:`internal`,path:`Essays/greek1.gif`,fragment:null,alt:``}],u={edition:`preserved`,sourceFile:`Essays/swtradition.htm`},d=[`thesacredwood`],f={id:e,slug:t,type:n,title:r,sourceFile:i,encoding:a,html:o,text:s,links:c,images:l,provenance:u,backlinks:d};export{d as backlinks,f as default,a as encoding,o as html,e as id,l as images,c as links,u as provenance,t as slug,i as sourceFile,s as text,r as title,n as type};